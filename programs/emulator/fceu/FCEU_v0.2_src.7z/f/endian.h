int write16(uint16 b, FILE *fp);
int write32(uint32 b, FILE *fp);
int writelower8of16(uint16 b, FILE *fp);
int writeupper8of16(uint16 b, FILE *fp);
