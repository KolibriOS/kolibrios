void GetFileBase(char *f);
extern char TempArray[2048];
#define MSG_ERRAM       marray[0]
extern char *marray[];
