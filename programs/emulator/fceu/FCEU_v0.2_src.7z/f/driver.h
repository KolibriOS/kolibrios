#include "types.h"
/* Prototypes for platform interface functions follow: */


void UpdateDriver(void); // called regularly when a null pointer is passed to fceumain

/* Video interface */
void SetPalette(uint8 index, uint8 r, uint8 g, uint8 b);
void GetPalette(uint8 i,uint8 *r, unsigned char *g, unsigned char *b);
void BlitScreen(unsigned char *XBuf, int maxline);
void WaitForVBlank(void);
int LockConsole(void);
int UnlockConsole(void);

/* Keyboard interface */
int KeyboardUpdate(void);
char *KeyboardGetstate(void);

/* Joystick interface */
uint32 GetJSOr(void);

/* Sound interface */
void FillSoundBuffer(unsigned char *Buf);

void PrintFatalError(char *s);
int fceumain(char *file);


#ifdef NETWORK
/* Network interface */

int NetworkConnect(void);
int NetworkRecvByte(unsigned char *Value);
int NetworkSendByte(unsigned char *Value);
void NetworkClose(void);
#endif

#define DES_DEFAULT     0
#define DES_VIDSYS      1
#define DES_NTSCCOL     2
#define DES_NETPLAY     3

#define DES_JOYSTICK    5
#define DES_SOUND       6
#define DES_GENIE       7
#define DES_BASEDIR     8

#define DES_RESET       0x10
#define DES_POWER       0x11
#define DES_EXIT        0x12
#define DES_LOADGAME	0x13

#define DES_GETNTSCHUE  0x20
#define DES_GETNTSCTINT  0x21
#define DES_SETNTSCHUE  0x22
#define DES_SETNTSCTINT  0x23
#define DES_GETDESIREDFPS 0x24

void DriverInterface(int w, void *d);
int DriverInitialize(void);
void DriverKill(void);          // This can be called when DriverInitialize isn't called if something such as memory allocation fails during initialization

#include "version.h"
