/****************************************************************/
/*			FCE Ultra				*/
/*								*/
/*	This file contains routines for reading/writing the     */
/*	configuration file, and for getting arguments		*/
/*	  							*/
/****************************************************************/

#define DRS_SOUND 0
#define DRS_NTSCCOL 1
//static char netplayhost[256];
//static int netskip;
//static int netplay=0;

int driversettings[2];
void GetValue(FILE *fp, char *str, int *v)
{
	char buf[256],buf2[32];
	while(fgets(buf,256,fp))
	{
		int v2;
		sscanf(buf,"%[^=] %*[=] %d",buf2,&v2);
		if(!strcmp(str,buf2)) *v=v2;
	}
	rewind(fp);
}

void GetValueString(FILE *fp, char *str, char *v)
{
	char buf[256],buf2[32];
	while(fgets(buf,256,fp))
	{
		char v2[1024];
		sscanf(buf,"%[^=] %*[=] %s",buf2,v2);
		if(!strcmp(str,buf2)) {strcpy(v,v2);}
	}
	rewind(fp);
}


void SetValue(FILE *fp, char *str, int v)
{
	fprintf(fp,"%s=%d\n",str,v);
}

void SetValueString(FILE *fp, char *str, char *str2)
{
	fprintf(fp,"%s=%s\n",str,str2);
}

extern int soundo;
void SaveConfig(char *filename)
{
	FILE *fp;
	int x;
	
	char gorf[16];
	fp=fopen(filename,"wb");
	if(fp==NULL) return;
	SetValue(fp,"vgamode",vmode);
	SetValue(fp,"sound",driversettings[DRS_SOUND]);
	//SetValue(fp,"sound",1);
	SetValue(fp,"joy1",joy[0]);
	SetValue(fp,"joy2",joy[1]);
	SetValue(fp,"joy3",joy[2]);
	SetValue(fp,"joy4",joy[3]);
	for(x=0;x<32;x++)
	{
		sprintf(gorf,"joyvar%d",x);
		SetValue(fp,gorf,joyvar[x]);
	}
	DriverInterface(DES_GETNTSCTINT,&x);
	SetValue(fp,"ntsctint",x);
	DriverInterface(DES_GETNTSCHUE,&x);
	SetValue(fp,"ntschue",x);
	SetValue(fp,"ntsccol",driversettings[DRS_NTSCCOL]);
	SetValue(fp,"ssync",sasync&1);
	SetValue(fp,"dowait",dowait);
	fclose(fp);
}

void LoadConfig(char *filename)
{
	FILE *fp;
	char gorf[16];
	int x;
	
	driversettings[DRS_NTSCCOL]=0;
	driversettings[DRS_SOUND]=1;
	
	fp=fopen(filename,"rb");
	if(fp==NULL) return;
	
	GetValue(fp,"vgamode",&vmode);
	GetValue(fp,"sound",&driversettings[DRS_SOUND]);
	GetValue(fp,"joy1",&joy[0]);
	GetValue(fp,"joy2",&joy[1]);
	GetValue(fp,"joy3",&joy[2]);
	GetValue(fp,"joy4",&joy[3]);
	for(x=0;x<32;x++)
	{
		joyvar[x]=0;
		sprintf(gorf,"joyvar%d",x);
		GetValue(fp,gorf,joyvar+x);
	}
	GetValue(fp,"ntsccol",&driversettings[DRS_NTSCCOL]);
	GetValue(fp,"ntsctint",&x);
	DriverInterface(DES_SETNTSCTINT,&x);
	GetValue(fp,"ntschue",&x);
	DriverInterface(DES_SETNTSCHUE,&x);
	
	GetValue(fp,"ssync",&sasync);
	GetValue(fp,"dowait",&dowait);
	fclose(fp);
}

void CheckArgs(void)
{
	printf("\nUsage is as follows:\nfceu <options> filename\n\n");
	puts("Options: \
	-vmode x        Select video mode(all are 8 bpp). \
	1 = 256x240                 4 = 640x480(with scanlines) \
	2 = 256x256                 5 = 640x480(T.V. emulation) \
	3 = 256x256(with scanlines) 6 = 256x224(with scanlines) \
	-ntsccol x      Emulate an NTSC's TV's colors. \
	0 = Disabled. \
	1 = Enabled. \
	-pal            Emulate a PAL NES. \
	-novsync x      Disable speed limiting. \
	0 = Disabled(speed limiting). \
	1 = Enabled(no speed limiting). \
	-ssync x        Synchronize video refreshes to internal sound timer. \
	0 = Disabled. \
	1 = Enabled. \
	-sound x	Sound. \
	0 = Disabled. \
	1 = Enabled. \
	-joyx y 	Joystick mapped to virtual joystick x[1-4]. \
	0 = Disabled, reset configuration. \
	Otherwise, y[1-inf) = joystick number. \
	-gg             Enable Game Genie emulation.");
	
#ifdef NETWORK
	puts("-connect   s	Connect to server 's' for TCP/IP network play. \
	-server    x    Be a host/server for TCP/IP network play. \
	\"x\" is an integer that specifies how many frames should be \
	between virtual joystick refreshes.  Default is 3.  It is \
	not required.");
#endif
}

void DoArgs(int argc, char *argv[])
{
	int argctemp,x,t;
	char *ppoint;

	for(argctemp=1;argctemp<argc-1;argctemp++)
	{
	/*
	#ifdef NETWORK
	ppoint =(char *)strstr(argv[argctemp],"-server");
	if(ppoint!=NULL && (argctemp+1<argc))
	{
		t=3;
		if(argctemp!=(argc-2))
		sscanf(argv[argctemp+1],"%d",&t);
		netskip=t;
		netplay=1;
		//DriverInterface(DES_NETSERV,&t);
	}
	ppoint =(char *)strstr(argv[argctemp],"-connect");
	if(ppoint!=NULL && (argctemp+1<argc))
	{strcpy(netplayhost,argv[argctemp+1]);netplay=2;}
	//DriverInterface(DES_NETCONN,argv[argctemp+1]);
	#endif
	*/
	ppoint =(char *)strstr(argv[argctemp],"-vgamode");
	if(!ppoint) ppoint =(char *)strstr(argv[argctemp],"-vmode");
	if(ppoint!=NULL && (argctemp+1<argc))
		vmode=*argv[argctemp+1]-48;
	ppoint =(char *)strstr(argv[argctemp],"-ntsccol");
	if(ppoint!=NULL && (argctemp+1<argc))
		{driversettings[DRS_NTSCCOL]=*argv[argctemp+1]-48;}
	ppoint =(char *)strstr(argv[argctemp],"-sound");
	if(ppoint!=NULL && (argctemp+1<argc))
		{driversettings[DRS_SOUND]=*argv[argctemp+1]-48;}
	ppoint =(char *)strstr(argv[argctemp],"-gg");
	if(ppoint!=NULL) 
		{t=1;DriverInterface(DES_GENIE,&t);}
	ppoint =(char *)strstr(argv[argctemp],"-novsync");
	if(ppoint!=NULL && (argctemp+1<argc))
		dowait=((*argv[argctemp+1]-48)&1)^1;
	ppoint =(char *)strstr(argv[argctemp],"-ssync");
	if(ppoint!=NULL && (argctemp+1<argc))
		{sasync=(*argv[argctemp+1]-48)&1;}
		
	for(x=0;x<4;x++)
	{
		char t[6];
		sprintf(t,"-joy%d",x+1);
		ppoint =(char *)strstr(argv[argctemp],t);
		if(ppoint!=NULL && (argctemp+1<argc))
		{
			sscanf(argv[argctemp+1],"%d",&joy[x]);
			if(!joy[x]) memset(&joyvar[x*8],0,8*sizeof(int));
		}
	}
	ppoint=(char *)strstr(argv[argctemp],"-pal");
	if(ppoint!=NULL) 
		{t=1;DriverInterface(DES_VIDSYS,&t);}
	}
	DriverInterface(DES_NTSCCOL,&driversettings[DRS_NTSCCOL]);
	soundo=driversettings[DRS_SOUND];
	if(netplay)
	{
		t=netplay|(netskip<<8);
		DriverInterface(DES_NETPLAY,&t);
	}
}
