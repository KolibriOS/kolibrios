#include "D:/OS/menuetos/include/menuet/os.h" //
//#include<menuet/os.h>
#include "vgavblank.h"
#include "../../driver.h"

static char * Title="FCEU\0";
static char FileNES[150]="/hd0/2/";
static char KeyMap[128];

extern byte BaseDirectory[2048];
static unsigned char WinSizeX=2,WinSizeY=2;
int winwidth=265, winheight=295;

extern int GameLoaded;

void ProcessEvent(int event);

char * LoadNESFile()
{
	int i=0,j=0;
	char Error[50]="";
	for(;;)
	{
		__menuet__bar(5,25,winwidth-10,15,0);
		__menuet__write_text(10,30,0xFFFFFF,FileNES,strlen(FileNES));
		for(;;)
		{	i =__menuet__wait_for_event();
			if (i==2) break;
			ProcessEvent(i);			
		}
		j=__menuet__getkey();
		if (j==1) return FileNES; //Esc
		if (j==28) //Enter
		{ 
			if(LoadGame(FileNES)) 
			{
				if (!InitMachine()) {TrashMachine();return FileNES;}
				Run6502();
				TrashFCE();
				TrashMachine();
			}
			else 
			{
				sprintf(Error,"Can't load file: %s",FileNES);
				PrintFatalError(Error);
			}
			return FileNES;
		}		
		//__kolibri__getasciimap(KeyMap);		
		if (j==15 || j==29 || j==42) continue; //Tab || Left_Control || Left_Shift
		if (j==14) FileNES[strlen(FileNES)-1]='\0'; //BackSpace
		if ((j>1 && j<54 && j!=14) || j==57)
		{
			FileNES[strlen(FileNES)]=KeyMap[j];
			FileNES[strlen(FileNES)+1]='\0';
		}
	}
}

void __kolibri__winresize(__u16 xsize, __u16 ysize)
{
	__asm__ __volatile__("int $0x40"::"a"(67),"b"(-1),"c"(-1),"d"(xsize),"S"(ysize));
}

void SetWinSize()
{
	char tmp[10]="";
	int winx=1,i=0,j=0;
	__menuet__bar(5,20,winwidth-10,20,0);
	__menuet__write_text(5,30,0xFFFFFF,"WinSizeX : ",12);
	__menuet__write_text(100,30,0xFFFFFF,"WinSizeY : ",12);
	for(;;)
	{
		for(;;)
		{	i =__menuet__wait_for_event();
			if (i==2) break;
			ProcessEvent(i);			
		}
		j=__menuet__getkey();		
		if (j==28) //Enter
		{
			if (winx) {WinSizeX=atoi(tmp); winx=0; tmp[0]='\0';}
			else {WinSizeY=atoi(tmp); break;}
		}
		if (j>1&&j<12) 
		{
			tmp[strlen(tmp)]=KeyMap[j];
			tmp[strlen(tmp)+1]='\0';
			if (winx)
				__menuet__write_text(70,30,0xFFFFFF,tmp,strlen(tmp));
			else
				__menuet__write_text(167,30,0xFFFFFF,tmp,strlen(tmp));
		}
	}
	__kolibri__winresize(256*WinSizeX+9, 240*WinSizeY+55);
}

// Video interface 
static unsigned char *ScreenLoc;
static unsigned char keybuf[256]="";

void __kolibri__setkbmode(__u8 mode)
{
	__asm__ __volatile__("int $0x40"::"a"(66),"b"(1),"c"(mode));
}

void __kolibri__getasciimap(char* map)
{
	__asm__ __volatile__("int $0x40"::"a"(26),"b"(2),"c"(1),"d"((__u32)map));
}

static int PaletteChanged=0;
static unsigned char paldbr[256],paldbg[256],paldbb[256];

void GetPalette(unsigned char index, unsigned char *r, unsigned char *g, unsigned char *b) // +
{
 *r=paldbr[index];
 *g=paldbg[index];
 *b=paldbb[index];
 PaletteChanged=1;
}

void SetPalette(unsigned char index, unsigned char r, unsigned char g, unsigned char b) // +
{
  paldbr[index]=r;
  paldbg[index]=g;
  paldbb[index]=b;
}

int vretrace=1;
int ssync=0;
int dowait=1;

void WaitForVBlank(void) // + 
{
	if(dowait)
	{
		if(ssync)
		{
		  wackyer:
			if (vretrace) vretrace--;
			else goto wackyer;
		}
		else if(!ssync)
			WaitVBlank();
	}
}

void __kolibri__draw_title(char* Title)
{
	__asm__ __volatile__("int $0x40"::"a"(71),"b"(1),"c"(Title));
}

void paint(void) // +
{
	__menuet__window_redraw(1);
	winwidth=256*WinSizeX+9;
	winheight=240*WinSizeY+55;
	__menuet__define_window(100,100,winwidth,winheight,0x03000000,0x800000FF,0x000080);
	//__menuet__bar(5,40,winwidth-10,winheight-55,0);
	__kolibri__draw_title(Title);
	__menuet__window_redraw(2);
}

void ProcessEvent(int event)
{
	switch(event)
	{
		case 1:
			paint();
		break;
		/*case 2:
			__menuet__getkey();
		break;*/
		case 3:	
			if(__menuet__get_button_id()==1) 
			{
				DriverInterface(DES_EXIT,0);
				__menuet__sys_exit();
			}
		break;
	}
}

void UpdateFCEUWindow() // +
{
	int	i =__menuet__check_for_event();
	ProcessEvent(i);
}

void BlitScreenWindow(unsigned char *tXBuf, int maxline);

void BlitScreen(unsigned char *tXBuf, int maxline) // -
{
 //int vmode=1;
	if (!ScreenLoc) {PrintFatalError("SCREEN = NULL !!!"); __menuet__delay100(300);}
 UpdateFCEUWindow();
 /*if(fullscreen)
  BlitScreenFull(XBuf,maxline);
 else if(!windowedfailed)*/
  BlitScreenWindow(tXBuf,maxline);

}

void BlitScreenWindow(unsigned char *tXBuf, int maxline) // +
{
	int x,y,j;
	uint32 i;
	int W=WinSizeX*256*3;
	i=0;
	for(y=maxline;y;y--)
	{
		for(x=256;x;x--)
		{
			for (j=0;j<WinSizeX;j++)
			{
				*(uint8 *)(ScreenLoc+(i*3))=paldbb[(uint8)*tXBuf];
				*(uint8 *)(ScreenLoc+(i*3+1))=paldbg[(uint8)*tXBuf];
				*(uint8 *)(ScreenLoc+(i*3+2))=paldbr[(uint8)*tXBuf];			
				i++;
			}
			tXBuf++;
		}
		tXBuf+=16;
		for (j=1;j<WinSizeY;j++)
		{
			memcpy(ScreenLoc+i*3, ScreenLoc+i*3-W, W);
			i+=256*WinSizeX;
		}	
	}
	__menuet__putimage(5,40,256*WinSizeX,240*WinSizeY,ScreenLoc);
}

int LockConsole(void) //ZAGLUSHKA
{ return 1; }

int UnlockConsole(void) //ZAGLUSHKA
{ return 1; }


// Keyboard interface

int KeyboardUpdate(void) //ZAGLUSHKA Win
{	
	KeyboardGetstate();	
	return 1;
}

char *KeyboardGetstate(void) // +
{
	int	j=0,i=__menuet__check_for_event();
	ProcessEvent(i);	
	if (i==2) j=__menuet__getkey();
	if (j==0) return keybuf;
	if (j==224) j=__menuet__getkey();
	switch(j)
	{			
		//Arrow key pressed
		case 72:  keybuf[200]=1;  break;   // Up
		case 80:  keybuf[208]=1;  break;   // Down
		case 75:  keybuf[203]=1;  break;   // Left
		case 77:  keybuf[205]=1;  break;   // Right
		//Arrow key unpressed	
		case 200:  keybuf[200]=0;  break;   // Up
		case 208:  keybuf[208]=0;  break;   // Down
		case 203:  keybuf[203]=0;  break;   // Left
		case 205:  keybuf[205]=0;  break;   // Right
		//F2 pressed
		case 60:  SetWinSize();  break;
		//F3 pressed
		case 61:  LoadNESFile();  break;
		default:
			if (j>0x7F) keybuf[j&0x7F] = 0;
			else keybuf[j]=1;
		break;
	}
	return keybuf;
}

int KeyboardInitialize(void) // +
{
	//Init to send scancode 
	int i;
	for(i=0;i<256;i++) keybuf[i]=0;
	__kolibri__setkbmode(1);
	__kolibri__getasciimap(KeyMap);
	return 1;
}

// Joystick interface 
unsigned long GetJSOr() //ZAGLUSHKA
{return 0;}

// Sound interface 
//void FillSoundBuffer(unsigned char *Buf){} //ZAGLUSHKA 
/*
int __kolibri__getcurdir(char* CurDir)
{
	int len=0;
	__asm__ __volatile__("int $0x40":"=a"(len):"a"(30),"b"(2),"c"((__u32)CurDir),"d"(2048));
	return len;
}
*/
int __kolibri__mkdir(char* CurDir)
{
	struct systree_info finf;
	int ret=0;

	finf.command = 9;
	finf.file_offset_low = 0;
	finf.file_offset_high = 0;
	finf.size = 0;
	finf.data_pointer = 0;
	finf._zero = 0;
	finf.nameptr = CurDir;
	return __kolibri__system_tree_access(&finf);
}

void GetBaseDirectory(void)
{
	//int x;
	//BaseDirectory[0]=0;
	sprintf(BaseDirectory,"/tmp0/1");
	//__kolibri__getcurdir(BaseDirectory);
	//sprintf(BaseDirectory,"%s",__get_curdir());
}

void CreateDirs(void)
{
	char TempArray[2048]="";
	int  error=0;

	sprintf(TempArray,"%s/fcs",BaseDirectory);
	error=__kolibri__mkdir(TempArray);
	if (error) { sprintf(TempArray,"e_%d Can't create directory for saves",error);  PrintFatalError(TempArray); return; }

	sprintf(TempArray,"%s/snaps",BaseDirectory);
	error=__kolibri__mkdir(TempArray);
	if (error) { sprintf(TempArray,"e_%d Can't create directory for snaps",error); PrintFatalError(TempArray); return; }

	PrintFatalError("Directories created");
}

void PrintFatalError(char *s)
{
	__menuet__bar(5,winheight-15,winwidth-10,12,0);
	__menuet__write_text(10,winheight-15,0x0000FF00,s,70);
}


int DriverInitialize(void) // +
{
	KeyboardInitialize();
	//ScreenLoc=(char *)malloc(100*240);
	ScreenLoc=(char *)malloc(100*240*2);
	return 1;
}

void DriverKill(void) //ZAGLUSHKA
{
	//sprintf(TempArray,"%s/fceu.cfg",BaseDirectory);
	//SaveConfig(TempArray);
	//KeyboardClose();
}

void UpdateDriver(void) // +
{
	UpdateFCEUWindow();
}

extern char __menuet__app_param_area[1024];

void app_main(void) // +
{
	paint();
	GetBaseDirectory();
	CreateDirs();
	__menuet__delay100(10);
	/*if(argc<=1) {CheckArgs();return 1;}
	sprintf(TempArray,"%s/fceu.cfg",BaseDirectory);
	LoadConfig(TempArray);
	DoArgs(argc, argv);
	return fceumain(argv[argc-1]);
	*/
	DriverInitialize();
	if (strlen(__menuet__app_param_area)<1) LoadNESFile();
	else sprintf(FileNES,"%s",__menuet__app_param_area);
	fceumain(FileNES); 
	__menuet__delay100(300);
}
