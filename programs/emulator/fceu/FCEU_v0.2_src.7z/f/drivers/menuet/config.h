void SaveConfig(char *filename);
void LoadConfig(char *filename);
void CheckArgs(void);
void DoArgs(int argc, char *argv[]);
extern int joyvar[32];
extern int joy[4];
