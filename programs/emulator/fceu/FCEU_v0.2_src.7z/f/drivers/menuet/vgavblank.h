//#define IfVBlank() while(!(inportb(0x3DA)&0x08));
//#define WaitVBlank() while(inportb(0x3DA)&0x08);while(!(inportb(0x3DA)&0x08));

//#include <SDL/SDL_timer.h>
#include "D:/OS/menuetos/include/SDL/SDL_timer.h"

void WaitVBlank()
{
    SDL_Delay((1000)/70);
}
