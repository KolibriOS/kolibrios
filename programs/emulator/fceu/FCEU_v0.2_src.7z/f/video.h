byte InitVirtualVideo(void);
void writepcx(void);
extern uint8 *XBuf;
