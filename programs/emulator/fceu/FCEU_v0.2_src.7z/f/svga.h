void SetNESDeemph(byte d, byte f);
#ifndef DrawText
void DrawText(byte *dest, word width, byte *textmsg, byte fgcolor, byte bgcolor);
#endif
void DrawTextTrans(byte *dest, word width, byte *textmsg, byte fgcolor);
void PutImage(void);
void TrashMachine(void);
void ProtFaultBefore(void);
void CloseStuff(int signum);
int InitMachine(void);
uint32 Joysticks(void);

extern byte Exit;
extern byte howlong;
extern byte errmsg[];
extern byte pale;
char SaveStateStatus[10];

void SetNESPalette(void);
void DrawTextTrans(byte *dest, word width, byte *textmsg, byte fgcolor);

#define JOY_A   1
#define JOY_B   2
#define JOY_SELECT      4
#define JOY_START       8
#define JOY_UP  0x10
#define JOY_DOWN        0x20
#define JOY_LEFT        0x40
#define JOY_RIGHT       0x80

extern int ntsccol;
extern int ntsctint;
extern int ntschue;

extern int soundon;

void DoCommand(byte c);
//byte CommandQueue;
#include "driver.h"
void ResetPalette(void);
