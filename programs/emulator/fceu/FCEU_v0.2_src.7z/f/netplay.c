#ifdef NETWORK

#include <stdio.h>
#include <stdlib.h>

#include "types.h"
#include "svga.h"
#include "netplay.h"

uint8 netplay=0;        /*      1 if we are a server */
                        /*      2 if we need a host  */

uint8 netskip=3;

static void NetError(void);
static int SendCommand(byte c)
{
  byte x;

  x=0xFF;

  if(!NetworkSendByte(&x)) {NetError();return 0;};
  if(!NetworkSendByte(&c)) {NetError();return 0;}
  return 1;
}



static void NetError(void)
{
 sprintf(errmsg,"Network error/connection lost!");
 howlong=255;
 netplay=0;
 NetworkClose();
}

int InitNetplay(void)
{
         if(NetworkConnect()==-1)
          return 0;
         if(netplay==1)
         {
          if(!NetworkSendByte(&netskip)) {NetError();return 0;}
         }
         else if(netplay==2)
         {
          if(!NetworkRecvByte(&netskip)) {NetError();return 0;}
         }
 return 1;
}

static uint8 netcount=0;
static uint8 netlast=0;
static uint8 netlastremote=0;

void NetplayUpdate(uint32 *JS)
{
 if(netplay==1)         // We're a server
 {
  if(!netcount)
   {
    netlast=(*JS&0xFF)|((*JS>>8)&0xFF)|((*JS>>16)&0xFF)|((*JS>>24)&0xFF);    // Combine joysticks on this end

    if(CommandQueue)
    {
     if(!SendCommand(CommandQueue)) return;
    }
    if(netlast==0xFF) netlast&=0x7F;
    if(!NetworkSendByte(&netlast)) {NetError();return;}
    if(!NetworkRecvByte(&netlastremote)) {NetError();return;}

    if(CommandQueue)
    {
     DoCommand(CommandQueue);     
     CommandQueue=0;
    }

   }
  *JS=netlast;
  *JS|=netlastremote<<8;
 }
 else if(netplay==2)    // We're connected to a host (we're second player)
 {
  byte temp;
  if(!netcount)
   {
   netlast=(*JS&0xFF)|((*JS>>8)&0xFF)|((*JS>>16)&0xFF)|((*JS>>24)&0xFF);    // Combine joysticks on this end

   if(netlast==0xFF) netlast&=0x7F;
   if(!NetworkSendByte(&netlast)) {NetError();return;}

   refetch:
   if(!NetworkRecvByte(&temp)) {NetError();return;}

   if(temp==0xFF)
    {
    if(!NetworkRecvByte(&temp)) {NetError();return;}
    DoCommand(temp);
    goto refetch;
    }

   netlastremote=temp;
   }
  *JS=netlast<<8;
  *JS|=netlastremote;
 }
 if(netskip) netcount=(netcount+1)%netskip;
}
#endif
