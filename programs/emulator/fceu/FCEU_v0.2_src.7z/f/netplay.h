#ifdef NETWORK
int InitNetplay(void);
void NetplayUpdate(uint32 *JS);

extern uint8 netplay;
extern uint8 netskip;
#endif
