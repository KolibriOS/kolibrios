#include <stdio.h>
#include <stdlib.h>
#include "mapinc.h"
#include "fmopl.h"
#include "vrc7q.h"

FM_OPL *fmob=0;
static void initopl(int how);

void writeopl(byte A, byte V)
{
 MapperExRAM[A]=V;
 if(fmob>0) {OPLWrite(fmob,0,A);OPLWrite(fmob,1,V);}
}


void vrc7translate(byte A, byte V)
{
 if(!fmob) initopl(0);
 AddQueue(VRC7_dosound,A,V);
}


void LoadOPL(void)
{
 int x;
 int y;
 for(x=y=0;x<0xF6;x++)
  y|=MapperExRAM[x];
 if(y)
 { 
  initopl(1); 
  for(x=0;x<0xF6;x++)
   writeopl(x,MapperExRAM[x]);
 }
}

void UpdateOPL(int32 *d)
{
if(fmob>0) YM3812UpdateOne(fmob, d, 256);
}

void trashopl(void)
{
int x;
for(x=0x1;x<0xF6;x++)
 writeopl(x,0);
}

static void initopl(int how)
{
int x;

fmob=OPLCreate(OPL_TYPE_WAVESEL,1789772*2,SndRate);
if(!fmob ) return;

OPLResetChip(fmob);

if(!how)
{
 for(x=0x1;x<0xF6;x++)
  {writeopl(x,0);}

  writeopl(0xBD,0xC0);
  writeopl(1,0x20);      // Enable waveform type manipulation
 }
}

#define u8 uint8
#include "vrc7q.c"
