#include "mapinc.h"

//M1

#define MMC1_reg mapbyte1
#define MMC1_buf mapbyte2[0]
#define MMC1_sft mapbyte3[0]
#define lastn    mapbyte2[1]

static void MMC1CHR(void)
{
    if(MMC1_reg[0]&0x10)
    {
     VROM_BANK4(0x0000,MMC1_reg[1]);
     VROM_BANK4(0x1000,MMC1_reg[2]);
    }
    else
    {
     VROM_BANK4(0x0000,MMC1_reg[1]);
     VROM_BANK4(0x1000,(MMC1_reg[1]+1));
    }
}

static void MMC1PRG(void)
{
        uint8 offs;

        offs=MMC1_reg[1]&0x10;
        switch(MMC1_reg[0]&0xC)
        {
          case 0xC: ROM_BANK16(0x8000,(MMC1_reg[3]+offs));
                    ROM_BANK16(0xC000,((pmask16&0xF)+offs));
                    break;
          case 0x8: ROM_BANK16(0xC000,(MMC1_reg[3]+offs));
                    ROM_BANK16(0x8000,offs);
                    break;
          case 0x0:
          case 0x4:
                    ROM_BANK16(0x8000,(MMC1_reg[3]+offs));
                    ROM_BANK16(0xc000,(MMC1_reg[3]+offs+1));
                    break;
        }
}

void Mapper1_write(uint16 A,uint8 V)
{
        int n=(A>>13)-4;

        if (V&0x80) {
         MMC1_sft=MMC1_buf=0;
//         if(n==0) MMC1_reg[0]|=0xC;
         return;
        }

        if(lastn!=n)
        {
         MMC1_sft=MMC1_buf=0;
        }
        lastn=n;

        MMC1_buf|=(V&1)<<(MMC1_sft++);

  if (MMC1_sft==5) {
        if(n==3) V&=0xF;
        else     V&=0x1F;

        MMC1_reg[n]=V=MMC1_buf;
        MMC1_sft = MMC1_buf=0;
        switch(n){
        case 0:
                switch(V&3)
                {
                 case 2: MIRROR_SET(0);break;
                 case 3: MIRROR_SET(1);break;
                 case 0: onemir(0);break;
                 case 1: onemir(2);break;
                }
                MMC1CHR();
                MMC1PRG();
                break;
        case 1:
                MMC1CHR();
                MMC1PRG();
                break;
        case 2:
                MMC1CHR();
                break;
        case 3:
                MMC1PRG();
                break;
        }
  }
}


void Mapper1_init(void)
{
        int i;
        for(i=0;i<4;i++) MMC1_reg[i]=0;
        MMC1_sft = MMC1_buf =0;
        MMC1_reg[0]=0xC;
        ROM_BANK16(0xC000,(pmask16&15)); /* last 16K */
	SetWriteHandler(0x8000,0xFFFF,(void *)Mapper1_write);
}

//M2
void Mapper2_write(uint16 A,uint8 V)
{
        ROM_BANK16(0x8000,V);
}

void Mapper2_init(void)
{
  SetWriteHandler(0x8000,0xFFFF,(void *)Mapper2_write);
}

//M3
void Mapper3_write(uint16 A,uint8 V)
{
        VROM_BANK8(V);
}

void Mapper3_init(void)
{
SetWriteHandler(0x8000,0xFFFF,(void *)Mapper3_write);
}

//M4
void Mapper4_write(uint16 A,uint8 V)
{
        switch(A&0xE001){
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {byte swa;swa=PRGBankList[0];ROM_BANK8(0x8000,PRGBankList[2]);
          ROM_BANK8(0xc000,swa);}
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            byte swa;
            swa=CHRBankList[4];
            VROM_BANK1(0x1000,CHRBankList[0]);
            VROM_BANK1(0x0000,swa);
            swa=CHRBankList[5];
            VROM_BANK1(0x1400,CHRBankList[1]);
            VROM_BANK1(0x0400,swa);
            swa=CHRBankList[6];
            VROM_BANK1(0x1800,CHRBankList[2]);
            VROM_BANK1(0x0800,swa);
            swa=CHRBankList[7];
            VROM_BANK1(0x1c00,CHRBankList[3]);
            VROM_BANK1(0x0c00,swa);
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0: V>>=1;VROM_BANK2((cbase^0x1000),V);break;
                case 1: V>>=1;VROM_BANK2((cbase^0x1800),V);break;
                case 2: VROM_BANK1(cbase^0x000,V); break;
                case 3: VROM_BANK1(cbase^0x400,V); break;
                case 4: VROM_BANK1(cbase^0x800,V); break;
                case 5: VROM_BANK1(cbase^0xC00,V); break;
                case 6: if (MMC3_cmd&0x40) ROM_BANK8(0xC000,V);
                        else ROM_BANK8(0x8000,V);
                        break;
                case 7: ROM_BANK8(0xA000,V);
                        break;
               }
               break;

        case 0xA000:
        MIRROR_SET(V&1);
        break;
        case 0xA001:break;
	#include "mmc3irq.h"
 }
}

void MMC3_hb(void)
{
     if((ScreenON || SpriteON)&& (scanline<241))
     {
      if(IRQCount>=0)
      {
       IRQCount--;resetmode=0;
	if(IRQCount<0)
        {
         if(IRQa)
         {
         resetmode=1;TriggerIRQSync();IRQlow|=1;
         }
        }
      }
     }
}
void Mapper4_StateRestore(int version)
{
if(version<=19)
 {
  if(PRGBankList[2]!=(pmask8-1))
   {
    mapbyte1[1]|=0x40;
   }
  if(mapword1[0]==0x0000)
   mapbyte1[1]|=0x80;
 }
}

void Mapper4_init(void)
{
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper4_write);
 MapHBIRQHook=(void *)MMC3_hb;
 MapStateRestore=(void *)Mapper4_StateRestore;
}

//M5
void WriteMMC5PSG(word A,byte V);

static inline void MMC5SPRVROM_BANK1(uint32 A,uint32 V) 
{
 if(VROM_size)
 {
  V&=vmask1;
  MMC5SPRVPage[(A)>>10]=&VROM[(V)<<10]-(A);
 }
}

static inline void MMC5BGVROM_BANK1(uint32 A,uint32 V) {if(VROM_size){V&=vmask1;MMC5BGVPage[(A)>>10]=&VROM[(V)<<10]-(A);}}

static inline void MMC5SPRVROM_BANK2(uint32 A,uint32 V) {if(VROM_size){V&=vmask2;MMC5SPRVPage[(A)>>10]=MMC5SPRVPage[((A)>>10)+1]=&VROM[(V)<<11]-(A);}}
static inline void MMC5BGVROM_BANK2(uint32 A,uint32 V) {if(VROM_size){V&=vmask2;MMC5BGVPage[(A)>>10]=MMC5BGVPage[((A)>>10)+1]=&VROM[(V)<<11]-(A);}}

static inline void MMC5SPRVROM_BANK4(uint32 A,uint32 V) {if(VROM_size){V&=vmask4;MMC5SPRVPage[(A)>>10]=MMC5SPRVPage[((A)>>10)+1]= MMC5SPRVPage[((A)>>10)+2]=MMC5SPRVPage[((A)>>10)+3]=&VROM[(V)<<12]-(A);}}
static inline void MMC5BGVROM_BANK4(uint32 A,uint32 V) {if(VROM_size){V&=vmask4;MMC5BGVPage[(A)>>10]=MMC5BGVPage[((A)>>10)+1]=MMC5BGVPage[((A)>>10)+2]=MMC5BGVPage[((A)>>10)+3]=&VROM[(V)<<12]-(A);}}

static inline void MMC5SPRVROM_BANK8(uint32 V) {if(VROM_size){V&=vmask;MMC5SPRVPage[0]=MMC5SPRVPage[1]=MMC5SPRVPage[2]=MMC5SPRVPage[3]=MMC5SPRVPage[4]=MMC5SPRVPage[5]=MMC5SPRVPage[6]=MMC5SPRVPage[7]=&VROM[(V)<<13];}}
static inline void MMC5BGVROM_BANK8(uint32 V) {if(VROM_size){V&=vmask;MMC5BGVPage[0]=MMC5BGVPage[1]=MMC5BGVPage[2]=MMC5BGVPage[3]=MMC5BGVPage[4]=MMC5BGVPage[5]=MMC5BGVPage[6]=MMC5BGVPage[7]=&VROM[(V)<<13];}}

static int32 inc;
byte MMC5fill[0x400];

#define MMC5IRQR        mapbyte3[4]
#define MMC5LineCounter mapbyte3[5]
#define mmc5psize mapbyte1[0]
#define mmc5vsize mapbyte1[1]

byte MMC5WRAMsize=1;
byte MMC5WRAMIndex[8];

byte MMC5ROMWrProtect[4];
static void MMC5CHRA(void);
static void MMC5CHRB(void);

#include "crc32.h"

typedef struct __cartdata {
        unsigned long crc32;
        unsigned char size;
} cartdata;
#define MMC5_NOCARTS 13
cartdata MMC5CartList[]=
{
 {0x9c18762b,2},         /* L'Empereur */
 {0x26533405,2},
 {0x6396b988,2},

 {0xaca15643,2},        /* Uncharted Waters */
 {0xfe3488d1,2},        /* Dai Koukai Jidai */

 {0x15fe6d0f,2},        /* BKAC             */
 {0x39f2ce4b,2},        /* Suikoden              */

 {0x8ce478db,2},        /* Nobunaga's Ambition 2 */
 {0xeee9a682,2},

 {0xf540677b,4},        /* Nobunaga...Bushou Fuuun Roku */

 {0x6f4e4312,4},        /* Aoki Ookami..Genchou */

 {0xf011e490,4},        /* Romance of the 3 Kingdoms 2 */
 {0x184c2124,4},        /* Sangokushi 2 */
};

void DetectMMC5WRAMSize(void)
{
 int x;
 unsigned long accum;

 gen_crc_table();

 MMC5WRAMsize=1;

 accum=0xFFFFFFFF;

 accum=update_crc(accum,ROM,ROM_size<<14);
 if(VROM_size)
  accum=update_crc(accum,VROM,VROM_size<<13);

 accum=~accum;
 for(x=0;x<MMC5_NOCARTS;x++)
  if(accum==MMC5CartList[x].crc32)
   {
   MMC5WRAMsize=MMC5CartList[x].size;
   break;
   }
 for(x=0;x<8;x++)
 {
  switch(MMC5WRAMsize)
  {
    default:
    case 1:MMC5WRAMIndex[x]=(x>3)?255:0;break;
    case 2:MMC5WRAMIndex[x]=(x&4)>>2;break;
    case 4:MMC5WRAMIndex[x]=(x>3)?255:(x&3);break;
    //case 8:MMC5WRAMIndex[x]=x;break;
  }
 }
}


static void MMC5CHRA(void)
{
int x;
switch(mapbyte1[1]&3)
 {
 case 0:MMC5SPRVROM_BANK8(mapbyte2[7]);
        VROM_BANK8(mapbyte2[7]);
        break;
 case 1:
        MMC5SPRVROM_BANK4(0x0000,mapbyte2[3]);
        MMC5SPRVROM_BANK4(0x1000,mapbyte2[7]);
        VROM_BANK4(0x0000,mapbyte2[3]);
        VROM_BANK4(0x1000,mapbyte2[7]);
        break;
 case 2:MMC5SPRVROM_BANK2(0x0000,mapbyte2[1]);
        MMC5SPRVROM_BANK2(0x0800,mapbyte2[3]);
        MMC5SPRVROM_BANK2(0x1000,mapbyte2[5]);
        MMC5SPRVROM_BANK2(0x1800,mapbyte2[7]);
        VROM_BANK2(0x0000,mapbyte2[1]);
        VROM_BANK2(0x0800,mapbyte2[3]);
        VROM_BANK2(0x1000,mapbyte2[5]);
        VROM_BANK2(0x1800,mapbyte2[7]);
        break;
 case 3:
        {
	 for(x=0;x<8;x++)VROM_BANK1(x<<10,mapbyte2[x]);}
         for(x=0;x<8;x++)
          MMC5SPRVROM_BANK1(x<<10,mapbyte2[x]);
        break;
 }
}
static void MMC5CHRB(void)
{
int x;
switch(mapbyte1[1]&3)
 {
 case 0:MMC5BGVROM_BANK8(mapbyte3[3]);
        VROM_BANK8(mapbyte3[3]);
        break;
 case 1:
        MMC5BGVROM_BANK4(0x0000,mapbyte3[3]);
        MMC5BGVROM_BANK4(0x1000,mapbyte3[3]);
        VROM_BANK4(0x0000,mapbyte3[3]);
        VROM_BANK4(0x1000,mapbyte3[3]);
        break;
 case 2:MMC5SPRVROM_BANK2(0x0000,mapbyte3[1]);
        MMC5SPRVROM_BANK2(0x0800,mapbyte3[3]);
        MMC5SPRVROM_BANK2(0x1000,mapbyte3[1]);
        MMC5SPRVROM_BANK2(0x1800,mapbyte3[3]);
        VROM_BANK2(0x0000,mapbyte3[1]);
        VROM_BANK2(0x0800,mapbyte3[3]);
        VROM_BANK2(0x1000,mapbyte3[1]);
        VROM_BANK2(0x1800,mapbyte3[3]);
        break;
 case 3:
        {for(x=0;x<8;x++)VROM_BANK1(x<<10,mapbyte3[x&3]);}
        for(x=0;x<8;x++)
         MMC5BGVROM_BANK1(x<<10,mapbyte3[x&3]);
        break;
 }
}
void MMC5WRAM(word A, byte V)
{
   V=MMC5WRAMIndex[V&7];
   if(V==255)
   {
    Page[A>>13]=nothing-A;
   }
   else
   {
    if(V)
    {
     Page[A>>13]=MapperExRAM+(V<<13)-A;
    }
    else
     Page[A>>13]=WRAM-A;
    }
}

void MMC5PRG(void)
{
 switch(mapbyte1[0]&3)
  {
  case 0:
         if(mapbyte1[5]&0x80)
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=
           MMC5ROMWrProtect[2]=MMC5ROMWrProtect[3]=1;
           ROM_BANK16(0x8000,((mapbyte1[5]&0x7F)>>2));
           ROM_BANK16(0xC000,(((mapbyte1[5]&0x7F)>>2)+1));
          }
         else
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=
           MMC5ROMWrProtect[2]=MMC5ROMWrProtect[3]=0;
           MMC5WRAM(0x8000,mapbyte1[5]&7&0xFC);
           MMC5WRAM(0xA000,(mapbyte1[5]&7&0xFC)+1);
           MMC5WRAM(0xC000,(mapbyte1[5]&7&0xFC)+2);
           MMC5WRAM(0xE000,(mapbyte1[5]&7&0xFC)+3);
          }
          break;
  case 1:
         if(mapbyte1[5]&0x80)
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=1;
           ROM_BANK16(0x8000,(mapbyte1[5]>>1));
          }
         else
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=0;
           MMC5WRAM(0x8000,mapbyte1[5]&7&0xFE);
           MMC5WRAM(0xA000,(mapbyte1[5]&7&0xFE)+1);
          }
         if(mapbyte1[7]&0x80)
          {
           MMC5ROMWrProtect[2]=MMC5ROMWrProtect[3]=1;
           ROM_BANK16(0xC000,(mapbyte1[7]&0x7F)>>1);
          }
         else
          {
           MMC5ROMWrProtect[2]=MMC5ROMWrProtect[3]=0;
           MMC5WRAM(0xC000,mapbyte1[7]&7&0xFE);
           MMC5WRAM(0xE000,(mapbyte1[7]&7&0xFE)+1);
          }
         break;
  case 2:
         if(mapbyte1[5]&0x80)
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=1;
           ROM_BANK16(0x8000,(mapbyte1[5]&0x7F)>>1);
          }
         else
          {
           MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=0;
           MMC5WRAM(0x8000,mapbyte1[5]&7&0xFE);
           MMC5WRAM(0xA000,(mapbyte1[5]&7&0xFE)+1);
          }
         if(mapbyte1[6]&0x80)
          {MMC5ROMWrProtect[2]=1;ROM_BANK8(0xC000,mapbyte1[6]&0x7F);}
         else
          {MMC5ROMWrProtect[2]=0;MMC5WRAM(0xC000,mapbyte1[6]&7);}
         MMC5ROMWrProtect[3]=1;
         ROM_BANK8(0xE000,mapbyte1[7]&0x7F);
         break;
  case 3:
         if(mapbyte1[4]&0x80)
          {MMC5ROMWrProtect[0]=1;ROM_BANK8(0x8000,mapbyte1[4]&0x7F);}
         else
          {MMC5ROMWrProtect[0]=0;MMC5WRAM(0x8000,mapbyte1[4]&7);}
         if(mapbyte1[5]&0x80)
          {MMC5ROMWrProtect[1]=1;ROM_BANK8(0xA000,mapbyte1[5]&0x7F);}
         else
          {MMC5ROMWrProtect[1]=0;MMC5WRAM(0xA000,mapbyte1[5]&7);}
         if(mapbyte1[6]&0x80)
          {MMC5ROMWrProtect[2]=1;ROM_BANK8(0xC000,mapbyte1[6]&0x7F);}
         else
          {MMC5ROMWrProtect[2]=0;MMC5WRAM(0xC000,mapbyte1[6]&7);}
         MMC5ROMWrProtect[3]=1;
         ROM_BANK8(0xE000,mapbyte1[7]&0x7F);
         break;
  }
}

#define mul1 mapbyte3[6]
#define mul2 mapbyte3[7]


void Mapper5_write(uint16 A,uint8 V)
{
 switch(A)
  {
   default:break;
   case 0x5105:
                {
                int x;
                for(x=0;x<4;x++)
                {
                 switch((V>>(x<<1))&3)
                 {
                 case 0:VPAL2[x]=0x8000;vnapage[x]=VRAM+0x2000;break;
                 case 1:VPAL2[x]=0x8002;vnapage[x]=VRAM+0x2800;break;
                 case 2:VPAL2[x]=0x8001;vnapage[x]=MapperExRAM;break;
                 case 3:VPAL2[x]=0x8800;vnapage[x]=MMC5fill;break;
                 }
                }
               }
               mapbyte4[3]=V;
               break;
   case 0x5000:
   case 0x5001:
   case 0x5002:
   case 0x5003:
   case 0x5004:
   case 0x5005:
   case 0x5006:
   case 0x5007:
   case 0x5010:
   case 0x5011:
   case 0x5015:WriteMMC5PSG(A,V);break;

   case 0x5113:mapbyte4[6]=V;MMC5WRAM(0x6000,V&7);break;
   case 0x5100:mapbyte1[0]=V;MMC5PRG();break;
   case 0x5101:mapbyte1[1]=V;
               if(!mapbyte4[7])
                {MMC5CHRB();MMC5CHRA();}
               else
                {MMC5CHRB();MMC5CHRA();}
               break;

   case 0x5114:
   case 0x5115:
   case 0x5116:
   case 0x5117:
               mapbyte1[A&7]=V;MMC5PRG();break;

   case 0x5120:
   case 0x5121:
   case 0x5122:
   case 0x5123:
   case 0x5124:
   case 0x5125:
   case 0x5126:
   case 0x5127:mapbyte4[7]=0;
               mapbyte2[A&7]=V;MMC5CHRA();break;
   case 0x5128:
   case 0x5129:
   case 0x512a:
   case 0x512b:mapbyte4[7]=1;
               mapbyte3[A&3]=V;MMC5CHRB();break;
   case 0x5102:mapbyte4[0]=V;break;
   case 0x5103:mapbyte4[1]=V;break;
   case 0x5104:mapbyte4[2]=V;break;
   case 0x5106:if(V!=mapbyte4[4])
               {
		uint32 t;
		t=V|(V<<8)|(V<<16)|(V<<24);
                dwmemset(MMC5fill,t,0x3c0);
               }
               mapbyte4[4]=V;
               break;
   case 0x5107:if(V!=mapbyte4[5])
               {
                unsigned char moop;
                uint32 t;
                moop=V|(V<<2)|(V<<4)|(V<<6);
		t=moop|(moop<<8)|(moop<<16)|(moop<<24);
                dwmemset(MMC5fill+0x3c0,t,0x40);
               }
               mapbyte4[5]=V;
               break;
   case 0x5203:IRQlow&=~1;IRQCount=(byte)V;break;
   case 0x5204:IRQlow&=~1;IRQa=V&0x80;break;
   case 0x5205:mul1=V;break;
   case 0x5206:mul2=V;break;
  }
}

byte MMC5_ReadROMRAM(word A)
{
         return Page[A>>13][A];
}

void MMC5_WriteROMRAM(word A, byte V)
{
       if(A>=0x8000)
        if(MMC5ROMWrProtect[(A-0x8000)>>13])
         return;
       Page[A>>13][A]=V;
}

void MMC5_ExRAMWr(word A, byte V)
{
 MapperExRAM[A&0x3ff]=V;
}

byte MMC5_ExRAMRd(word A)
{
 return MapperExRAM[A&0x3ff];
}

byte MMC5_read(word A)
{
 switch(A)
 {
  default:break;
  case 0x5204:IRQlow&=~1;
              {byte x;x=MMC5IRQR;MMC5IRQR&=0x40;if(!IRQa)MMC5IRQR&=0; return x;}
  case 0x5205:return (byte)((byte)mul1*(byte)mul2);
  case 0x5206:return ((word)(mul1*mul2))>>8;
 }
 return 0xFF;
}
void MMC5_restore(void)
{
 int x;
 MMC5PRG();
 for(x=0;x<4;x++)
 {
  switch((mapbyte4[3]>>(x<<1))&3)
   {
    case 0:VPAL2[x]=0x8000;vnapage[x]=VRAM+0x2000;break;
    case 1:VPAL2[x]=0x8002;vnapage[x]=VRAM+0x2800;break;
    case 2:VPAL2[x]=0x8001;vnapage[x]=MapperExRAM;break;
    case 3:VPAL2[x]=0x8800;vnapage[x]=MMC5fill;break;
   }
 }
 MMC5WRAM(0x6000,mapbyte4[6]&7);
 if(!mapbyte4[7])
  {
  MMC5CHRB();
  MMC5CHRA();
  }
  else
  {
   MMC5CHRB();
   MMC5CHRA();
  }
  {
    uint32 t;
    t=mapbyte4[4]|(mapbyte4[4]<<8)|(mapbyte4[4]<<16)|(mapbyte4[4]<<24);
    dwmemset(MMC5fill,t,0x3c0);
  }
  {
   unsigned char moop;
   uint32 t;
   moop=mapbyte4[5]|(mapbyte4[5]<<2)|(mapbyte4[5]<<4)|(mapbyte4[5]<<6);
   t=moop|(moop<<8)|(moop<<16)|(moop<<24);
   dwmemset(MMC5fill+0x3c0,t,0x40);
  }
  IRQlow&=~1;
}

void MMC5_hb(void)
{
  if(scanline==0 && (ScreenON || SpriteON)) {MMC5LineCounter=0;}
  if(MMC5LineCounter<245)
  {
   if(MMC5LineCounter==IRQCount) MMC5IRQR|=0x80;
   if((MMC5LineCounter==IRQCount && IRQa&0x80))
    {TriggerIRQ();IRQlow|=1;}
   if(ScreenON || SpriteON)
        MMC5LineCounter++;
  }
  if(MMC5LineCounter>=245) 
    MMC5IRQR|=0x40;
}

void Mapper5_StateRestore(int version)
{
 MMC5_restore();
}

static uint32 MMC5slengthtable[0x20]=
 {
 0x5,0x7f,0xA,0x1,0x14,0x2,0x28,0x3,0x50,0x4,0x1E,0x5,0x7,0x6,0x0E,0x7,
 0x6,0x08,0xC,0x9,0x18,0xa,0x30,0xb,0x60,0xc,0x24,0xd,0x8,0xe,0x10,0xf
 };
static int32 dectab[32];
static uint32 MMC5lengthtable[0x20];

#define MMC5deccount(x)    (*(int32 *)&MapperExRAM[0x400+((x)<<2)])
#define MMC5decvolume(x)   (*(uint8 *)&MapperExRAM[0x408+(x)])
#define MMC5sqnon          (*(uint8 *)&MapperExRAM[0x40A])
#define MMC5lengthcount(x) (*(int32 *)&MapperExRAM[0x40B+((x)<<2)])
#define MMC5PSG(x)         (*(uint8 *)&MapperExRAM[0x40B+8+(x)])

void WriteMMC5PSG(word A,byte V)
{
 A&=0x1f;
 switch(A)
 {
  case 0x3:
          if(MMC5PSG(0x15)&1)
          {
          MMC5decvolume(0)=15;
          MMC5lengthcount(0)=MMC5lengthtable[(V>>3)&0x1f];
          MMC5sqnon|=1;
          MMC5deccount(0)=1<<29;
          }
          break;
  case 0x7:
          if(MMC5PSG(0x15)&2)
          {
          MMC5decvolume(1)=15;
          MMC5lengthcount(1)=MMC5lengthtable[(V>>3)&0x1f];
          MMC5sqnon|=2;
          MMC5deccount(1)=1<<29;
          }
          break;
 case 0x15:
          MMC5sqnon&=V;
          break;
 }
 MMC5PSG(A)=V;
}


int MMC5Sound(int32 *Wave)
{
 int P,V;
 int32 freq;
   for(P=0;P<2;P++)
   {
    if(MMC5PSG(0x15)&(P+1) && MMC5sqnon&(P+1))
    {
     unsigned long dcycs;
     unsigned char amplitude;
     long vcoo;

     freq=(((MMC5PSG((P<<2)+0x2)|((MMC5PSG((P<<2)+0x3)&7)<<8))));

     if(freq<8) goto mmc5enda;
     freq+=1;
     inc=(long double)((unsigned long)((SndRate OVERSAMPLE)<<12))/
((long double)PSG_base/freq);

     switch(MMC5PSG(P<<2)&0xC0)
     {
     default:
     case 0x00:dcycs=inc>>3;break;
     case 0x40:dcycs=inc>>2;break;
     case 0x80:dcycs=inc>>1;break;
     case 0xC0:dcycs=(inc+inc+inc)>>2;break;
     }
      if(MMC5PSG(P<<2)&0x10)
       amplitude=MMC5PSG(P<<2)&15;
      else
       amplitude=MMC5decvolume(P);
      vcoo=vcount[P];
             for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
              {
               if(vcoo>=dcycs)
                Wave[V>>4]-=amplitude;
               else
                Wave[V>>4]+=amplitude;
               vcoo+=0x1000;
               if(vcoo>=inc) vcoo-=inc;
               }
      vcount[P]=vcoo;
    }

  mmc5enda:

  if(!(MMC5PSG(P<<2)&0x20))
   {
    if(MMC5lengthcount(P)>0)
    {
     MMC5lengthcount(P)-=0x100000;
     if(MMC5lengthcount(P)<=0) MMC5sqnon&=~(P+1);
    }
   }

   MMC5deccount(P)-=dectab[(MMC5PSG(P<<2)&0xF) | ((MMC5PSG(P<<2)&0x20)>>1)];
   if(MMC5deccount(P)<=0)
    {
     if(MMC5decvolume(P) || MMC5PSG(P<<2)&0x20)
     {
      MMC5decvolume(P)--;
      MMC5decvolume(P)&=15;
      MMC5deccount(P)+=1<<29;
     }
    }
 }
 return 0;
}

void Mapper5_init(void)
{
int x;

for(x=0;x<0x20;x++) 
 {
  long double temp;
  temp=(long double)SndRate/SND_BUFSIZE;
  if(PAL)
   temp=(long double)temp/50;
  else
   temp=(long double)temp/60;
  temp*=0x100000;
  MMC5lengthtable[x]=(long double)MMC5slengthtable[x]*temp;
 }
  for(x=0;x<32;x++)
  {
   dectab[x]=(long double)0x20000000*256/((long double)SndRate/SND_BUFSIZE)/((x&15)+1+(x>>4));
  }

mapbyte1[4]=mapbyte1[5]=mapbyte1[6]=mapbyte1[7]=pmask8;
ROM_BANK8(0x8000,pmask8);
ROM_BANK8(0xa000,pmask8);
ROM_BANK8(0xc000,pmask8);
ROM_BANK8(0xe000,pmask8);
mapbyte1[0]=mapbyte1[1]=3;
MMC5ROMWrProtect[0]=MMC5ROMWrProtect[1]=
MMC5ROMWrProtect[2]=MMC5ROMWrProtect[3]=1;
MMC5CHRA();
MMC5CHRB();
DetectMMC5WRAMSize();
IRQlow&=~1;

SetWriteHandler(0x4020,0x5bff,(void *)Mapper5_write);
SetReadHandler(0x4020,0x5bff,(void *)MMC5_read);

SetWriteHandler(0x5c00,0x5fff,(void *)MMC5_ExRAMWr);
SetReadHandler(0x5c00,0x5fff,(void *)MMC5_ExRAMRd);

SetWriteHandler(0x6000,0xFFFF,(void *)MMC5_WriteROMRAM);
SetReadHandler(0x6000,0xFFFF,(void *)MMC5_ReadROMRAM);

MapHBIRQHook=(void *)MMC5_hb;
MapStateRestore=(void *)Mapper5_StateRestore;
MapExpSound=(void *)MMC5Sound;
}

//M6
#define FVRAM_BANK8(A,V) {VPage[0]=VPage[1]=VPage[2]=VPage[3]=VPage[4]=VPage[5]=VPage[6]=VPage[7]=V?&MapperExRAM[(V)<<13]-(A):&VRAM[(V)<<13]-(A);CHRBankList[0]=((V)<<3);CHRBankList[1]=((V)<<3)+1;CHRBankList[2]=((V)<<3)+2;CHRBankList[3]=((V)<<3)+3;CHRBankList[4]=((V)<<3)+4;CHRBankList[5]=((V)<<3)+5;CHRBankList[6]=((V)<<3)+6;CHRBankList[7]=((V)<<3)+7;VPAL[0]=VPAL[1]=VPAL[2]=VPAL[3]=VPAL[4]=VPAL[5]=VPAL[6]=VPAL[7]=1;}

static void FFEIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount+=a;
   if(IRQCount>=0x10000)
   {
    TriggerIRQ();
    IRQa=0;
    IRQCount=0;
   }
  }
}

void Mapper6_write(uint16 A,uint8 V)
{
        if(A<0x8000)
        {
                switch(A){
                case 0x42FF:MIRROR_SET((V>>4)&1);break;
                case 0x42FE:onemir((V>>3)&2);break;
                case 0x4501:IRQa=0;break;
                case 0x4502:IRQCount&=0xFF00;IRQCount|=V;break;
                case 0x4503:IRQCount&=0xFF;IRQCount|=V<<8;IRQa=1;break;
                }
        } else {
        ROM_BANK16(0x8000,(V>>2)&pmask16);
        FVRAM_BANK8(0x0000,V&3);
        }
}
void Mapper6_StateRestore(int version)
{
 int x;
 for(x=0;x<8;x++)
  if(VPAL[x])
  {
   if(CHRBankList[x]>7)
    VPage[x]=&MapperExRAM[(CHRBankList[x]&31)*0x400]-(x*0x400);
   else VPage[x]=&VRAM[(CHRBankList[x]&7)*0x400]-(x*0x400);
  }
}
void Mapper6_init(void)
{
MapIRQHook=FFEIRQHook;
ROM_BANK16(0xc000,7);

SetWriteHandler(0x4020,0x5fff,(void *)Mapper6_write);
SetWriteHandler(0x8000,0xffff,(void *)Mapper6_write);
MapStateRestore=(void *)Mapper6_StateRestore;
}

//M7
void Mapper7_write(uint16 A,uint8 V)
{
      ROM_BANK32(0x8000,V&0xF);
      onemir((V>>4)&1);
}

void Mapper7_init(void)
{
        onemir(0);
        SetWriteHandler(0x8000,0xFFFF,(void *)Mapper7_write);
}

//M8
void Mapper8_write(uint16 A,uint8 V)
{
        ROM_BANK16(0x8000,V>>3);
        VROM_BANK8(V&7);
}

void Mapper8_init(void)
{
	ROM_BANK32(0x8000,0);
        SetWriteHandler(0x8000,0xFFFF,(void *)Mapper8_write);
}

//M9
static void latchcheck1(uint32 VAddra)
{
 pair vap;
 vap.W=VAddra;

if(vap.B.h>=0x20 || ((vap.B.h&0xF)!=0xf)) return;
else if(vap.B.h<0x10)
     {
        if((vap.B.l&0xF0)==0xD0)
         {
         VROM_BANK4(0x0000,MMC4reg[0]);
         latcha1=0xFD;
         }
        else if((vap.B.l&0xF0)==0xE0)
         {
         VROM_BANK4(0x0000,MMC4reg[1]);
         latcha1=0xFE;
         }
     }
else
     {
        if((vap.B.l&0xF0)==0xD0)
         {
         VROM_BANK4(0x1000,MMC4reg[2]);
         latcha2=0xFD;
         }
        else if((vap.B.l&0xF0)==0xE0)
         {
         VROM_BANK4(0x1000,MMC4reg[3]);
         latcha2=0xFE;
         }
     }
}

void Mapper9_write(uint16 A,uint8 V)
{
        switch(A&0xF000){
        case 0xA000:
                ROM_BANK8(0x8000,V);
                break;
        case 0xB000:
                V&=vmask4;
                if (latcha1==0xFD) { VROM_BANK4(0x0000,V);}
                MMC4reg[0]=V;
                break;
        case 0xC000:
                V&=vmask4;
                if (latcha1==0xFE) {VROM_BANK4(0x0000,V);}
                MMC4reg[1]=V;
                break;
        case 0xD000:
                V&=vmask4;
                if (latcha2==0xFD) {VROM_BANK4(0x1000,V);}
                MMC4reg[2]=V;
                break;
        case 0xE000:
                V&=vmask4;
                if (latcha2==0xFE) {VROM_BANK4(0x1000,V);}
                MMC4reg[3]=V;
                break;
        case 0xF000:
                MIRROR_SET(V&1);
                break;
        }
}

void Mapper9_init(void)
{
        latcha1=0xFE;
        latcha2=0xFE;
        ROM_BANK8(0xA000,pmask8&~2);
        ROM_BANK8(0x8000,0);
        SetWriteHandler(0x8000,0xFFFF,(void *)Mapper9_write);
        PPU_hook=(void *)latchcheck1;
}

//M10
static void latchcheck2(uint32 VAddra)
{
 pair vap;

 vap.W=VAddra;
 if(vap.B.h>=0x20 || ((vap.B.h&0xF)!=0xf)) return; 
 else if(vap.B.h<0x10)
     {
        if((vap.B.l&0xF0)==0xD0)
         {
         VROM_BANK4(0x0000,MMC4reg[0]);
         latcha1=0xFD;
         }
        else if((vap.B.l&0xF0)==0xE0)
         {
         VROM_BANK4(0x0000,MMC4reg[1]);
         latcha1=0xFE;
         }
     }
else
     {
        if((vap.B.l&0xF0)==0xD0)
         {
         VROM_BANK4(0x1000,MMC4reg[2]);
         latcha2=0xFD;
         }
        else if((vap.B.l&0xF0)==0xE0)
         {
         VROM_BANK4(0x1000,MMC4reg[3]);
         latcha2=0xFE;
         }
     }
}


void Mapper10_write(uint16 A,uint8 V)
{
        switch(A&0xF000){
        case 0xA000:
                ROM_BANK16(0x8000,V);
                break;
        case 0xB000:
                V&=vmask4;
                if (latcha1==0xFD) {VROM_BANK4(0x0000,V);}
                MMC4reg[0]=V;
                break;
        case 0xC000:
                V&=vmask4;
                if (latcha1==0xFE) {VROM_BANK4(0x0000,V);}
                MMC4reg[1]=V;
                break;
        case 0xD000:
                V&=vmask4;
                if (latcha2==0xFD) {VROM_BANK4(0x1000,V);}
                MMC4reg[2]=V;
                break;
        case 0xE000:
                V&=vmask4;
                if (latcha2==0xFE) {VROM_BANK4(0x1000,V);}
                MMC4reg[3]=V;
                break;
        case 0xF000:
                MIRROR_SET(V&1);
                break;
        }
}
void Mapper10_init(void)
{
        latcha1=latcha2=0xFE;
        SetWriteHandler(0x8000,0xFFFF,(void *)Mapper10_write);
        PPU_hook=(void *)latchcheck2;
}

//M11
void Mapper11_write(uint16 A,uint8 V)
{
        ROM_BANK32(0x8000,V);
        VROM_BANK8(V>>4);
}

void Mapper11_init(void)
{
        ROM_BANK32(0x8000,0);
	SetWriteHandler(0x8000,0xFFFF,(void *)Mapper11_write);
}

//M13
static inline void VRAM_BANK4(uint32 A,uint32 V)
{
VPage[(A)>>10]=VPage[((A)>>10)+1]=VPage[((A)>>10)+2]=VPage[((A)>>10)+3]=&MapperExRAM[(V)<<12]-(A);
CHRBankList[(A)>>10]=((V)<<2);
CHRBankList[((A)>>10)+1]=((V)<<2)+1;
CHRBankList[((A)>>10)+2]=((V)<<2)+2;CHRBankList[((A)>>10)+3]=((V)<<2)+3;
}


void Mapper13_write(uint16 A,uint8 V)
{
VRAM_BANK4(0x1000,V&3);
ROM_BANK32(0x8000,(((V>>4)&3)));
}
void Mapper13_StateRestore(int version)
{
int x;
 for(x=0;x<8;x++)
  if(VPAL[x])
   VPage[x]=&MapperExRAM[(CHRBankList[x]&15)*0x400]-(x*0x400);
}
void Mapper13_init(void)
{
VRAM_BANK4(0,0);VRAM_BANK4(0x1000,1);
SetWriteHandler(0x8000,0xFFFF,(void *)Mapper13_write);
MapStateRestore=(void *)Mapper13_StateRestore;
}

//M15
void Mapper15_write(uint16 A,uint8 V)
{
switch(A)
 {
  case 0x8000:
        if(V&0x80)
        {
        ROM_BANK8(0x8000,(V<<1)+1);
        ROM_BANK8(0xA000,(V<<1));
        ROM_BANK8(0xC000,(V<<1)+2);
        ROM_BANK8(0xE000,(V<<1)+1);
        }
        else
        {
        ROM_BANK16(0x8000,V&pmask16);
        ROM_BANK16(0xC000,(V+1)&pmask16);
        }
        MIRROR_SET((V>>6)&1);
        break;
  case 0x8001:
        //break;
        //if(V&0x80)
        //{
        //ROM_BANK8(0xC000,(V<<1)+1);
        //ROM_BANK8(0xE000,V<<1);
        //}
        //else
        //{
        //ROM_BANK16(0xC000,V);
        //}
        MIRROR_SET(0);
        ROM_BANK16(0x8000,V);
        ROM_BANK16(0xc000,pmask16);
        break;
  case 0x8002:
        if(V&0x80)
        {
        ROM_BANK8(0x8000,((V<<1)+1));
        ROM_BANK8(0xA000,((V<<1)+1));
        ROM_BANK8(0xC000,((V<<1)+1));
        ROM_BANK8(0xE000,((V<<1)+1));
        }
        else
        {
        ROM_BANK8(0x8000,(V<<1));
        ROM_BANK8(0xA000,(V<<1));
        ROM_BANK8(0xC000,(V<<1));
        ROM_BANK8(0xE000,(V<<1));
        }
        break;
  case 0x8003:
        MIRROR_SET((V>>6)&1);
        if(V&0x80)
        {
        ROM_BANK8(0xC000,(V<<1)+1);
        ROM_BANK8(0xE000,(V<<1));
        }
        else
        {
        ROM_BANK16(0xC000,V);
        }
        break;
 }
}

void Mapper15_init(void)
{
        ROM_BANK32(0x8000,0);
SetWriteHandler(0x8000,0xFFFF,(void *)Mapper15_write);
}

//M16
void BandaiIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount-=a;
   if(IRQCount<0)
   {
    TriggerIRQ();
    IRQa=0;
    IRQCount=0xFFFF;
   }
  }
}


void Mapper16_write(uint16 A,uint8 V)
{
        switch(A&0xF){
        case 0x0: VROM_BANK1(0x0000,V);break;
        case 0x1: VROM_BANK1(0x0400,V);break;
        case 0x2: VROM_BANK1(0x0800,V);break;
        case 0x3: VROM_BANK1(0x0C00,V);break;
        case 0x4: VROM_BANK1(0x1000,V);break;
        case 0x5: VROM_BANK1(0x1400,V);break;
        case 0x6: VROM_BANK1(0x1800,V);break;
        case 0x7: VROM_BANK1(0x1C00,V);break;
        case 0x8: ROM_BANK16(0x8000,V);break;
        case 0x9: switch(V&3){
                  case 0x00:MIRROR_SET2(1);break;
                  case 0x01:MIRROR_SET2(0);break;
                  case 0x02:onemir(0);break;
                  case 0x03:onemir(2);break;
                  }
                  break;
        case 0xA:IRQa=V&1;break;
        case 0xB:
                 {IRQCount&=0xFF00;IRQCount|=V;}break;
        case 0xC:
                 {IRQCount&=0xFF;IRQCount|=V<<8;}break;
        case 0xD:break;/* EEPROM control port */
        }
}

void Mapper16_init(void)
{
MapIRQHook=(void *)BandaiIRQHook;
SetWriteHandler(0x4020,0xFFFF,(void *)Mapper16_write);
}

//M17
/*static void FFEIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount+=a;
   if(IRQCount>=0x10000)
   {
    TriggerIRQ();
    IRQa=0;
    IRQCount=0;
   }
  }
}
*/

void Mapper17_write(uint16 A,uint8 V)
{
        switch(A){
        default:
              break;
        case 0x42FE:
                   onemir((V>>3)&2);
                   break;
        case 0x42FF:
                   MIRROR_SET((V>>4)&1);
        break;
        case 0x4501:IRQa=V;break;
        case 0x4502:IRQCount&=0xFF00;IRQCount|=V;break;
        case 0x4503:IRQCount&=0x00FF;IRQCount|=V<<8;IRQa=1;break;
        case 0x4504: ROM_BANK8(0x8000,V);break;
        case 0x4505: ROM_BANK8(0xA000,V);break;
        case 0x4506: ROM_BANK8(0xC000,V);break;
        case 0x4507: ROM_BANK8(0xE000,V);break;
        case 0x4510: VROM_BANK1(0x0000,V);break;
        case 0x4511: VROM_BANK1(0x0400,V);break;
        case 0x4512: VROM_BANK1(0x0800,V);break;
        case 0x4513: VROM_BANK1(0x0C00,V);break;
        case 0x4514: VROM_BANK1(0x1000,V);break;
        case 0x4515: VROM_BANK1(0x1400,V);break;
        case 0x4516: VROM_BANK1(0x1800,V);break;
        case 0x4517: VROM_BANK1(0x1C00,V);break;
        }
}

void Mapper17_init(void)
{
MapIRQHook=(void *)FFEIRQHook;
SetWriteHandler(0x4020,0x5fff,(void *)Mapper17_write);
}

//M18
#define K4buf mapbyte2
#define K4buf2 mapbyte3


void JalecoIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount-=a;
   if(IRQCount<=-8)
   {
    TriggerIRQ();
    IRQCount=IRQLatch;
   }
  }
}

void Mapper18_write(uint16 A,uint8 V)
{
        switch(A)
        {
case 0x8000:K4buf2[0]&=0xF0;K4buf2[0]|=V&0x0f;ROM_BANK8(0x8000,K4buf2[0]);break;
case 0x8001:K4buf2[0]&=0x0F;K4buf2[0]|=(V<<4);ROM_BANK8(0x8000,K4buf2[0]);break;
case 0x8002:K4buf2[1]&=0xF0;K4buf2[1]|=V&0x0f;ROM_BANK8(0xa000,K4buf2[1]);break;
case 0x8003:K4buf2[1]&=0x0F;K4buf2[1]|=(V<<4);ROM_BANK8(0xa000,K4buf2[1]);break;
case 0x9000:K4buf2[2]&=0xF0;K4buf2[2]|=V&0x0f;ROM_BANK8(0xc000,K4buf2[2]);break;
case 0x9001:K4buf2[2]&=0x0F;K4buf2[2]|=(V<<4);ROM_BANK8(0xc000,K4buf2[2]);break;
case 0xa000:K4buf[0]&=0xF0;K4buf[0]|=V&0x0f;VROM_BANK1(0x0,K4buf[0]);break;
case 0xa001:K4buf[0]&=0x0F;K4buf[0]=K4buf[0]|(V<<4);VROM_BANK1(0x0,K4buf[0]);break;
case 0xa002:K4buf[1]&=0xF0;K4buf[1]|=V&0x0f;VROM_BANK1(0x400,K4buf[1]);break;
case 0xa003:K4buf[1]&=0x0F;K4buf[1]=K4buf[1]|(V<<4);VROM_BANK1(0x400,K4buf[1]);break;
case 0xb000:K4buf[2]&=0xF0;K4buf[2]|=V&0x0f;VROM_BANK1(0x800,K4buf[2]);break;
case 0xb001:K4buf[2]&=0x0F;K4buf[2]=K4buf[2]|(V<<4);VROM_BANK1(0x800,K4buf[2]);break;
case 0xb002:K4buf[3]&=0xF0;K4buf[3]|=V&0x0f;VROM_BANK1(0xc00,K4buf[3]);break;
case 0xb003:K4buf[3]&=0x0F;K4buf[3]=K4buf[3]|(V<<4);VROM_BANK1(0xc00,K4buf[3]);break;
case 0xc000:K4buf[4]&=0xF0;K4buf[4]|=V&0x0f;VROM_BANK1(0x1000,K4buf[4]);break;
case 0xc001:K4buf[4]&=0x0F;K4buf[4]=K4buf[4]|(V<<4);VROM_BANK1(0x1000,K4buf[4]);break;
case 0xc002:K4buf[5]&=0xF0;K4buf[5]|=V&0x0f;VROM_BANK1(0x1400,K4buf[5]);break;
case 0xc003:K4buf[5]&=0x0F;K4buf[5]=K4buf[5]|(V<<4);VROM_BANK1(0x1400,K4buf[5]);break;
case 0xd000:K4buf[6]&=0xF0;K4buf[6]|=V&0x0f;VROM_BANK1(0x1800,K4buf[6]);break;
case 0xd001:K4buf[6]&=0x0F;K4buf[6]=K4buf[6]|(V<<4);VROM_BANK1(0x1800,K4buf[6]);break;
case 0xd002:K4buf[7]&=0xF0;K4buf[7]|=V&0x0f;VROM_BANK1(0x1c00,K4buf[7]);break;
case 0xd003:K4buf[7]&=0x0F;K4buf[7]=K4buf[7]|(V<<4);VROM_BANK1(0x1c00,K4buf[7]);break;

case 0xe000:IRQLatch&=0xF0;IRQLatch|=V&0x0f;break;
case 0xe001:IRQLatch&=0x0F;IRQLatch|=V<<4;break;
case 0xe002:IRQLatch&=0xF0FF;IRQLatch|=(V&0x0f)<<8;break;
case 0xe003:IRQLatch&=0x0FFF;IRQLatch|=V<<12;break;

case 0xf000:if(V&1)IRQCount=IRQLatch;break;
case 0xf001://IRQCount=IRQLatch;
            IRQa=V&1;break;

case 0xf002:MIRROR_SET2(V&1);
            if(V&2) onemir(0);
            break;
        }
}

void Mapper18_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper18_write);
MapIRQHook=(void *)JalecoIRQHook;
}

//M19
#define dopol mapbyte1[0]
byte gorfus=0xFF;
static int32 inc;
void NamcoIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount+=a;
   if(IRQCount>=0x10000+8)
   {
    TriggerIRQ();
    IRQlow|=1;
    IRQa=0;
    IRQCount=0xFFFF;
   }
  }
}


byte Namco_Read(word A)
{
byte ret=0;
switch(A&0xF800){
        case 0x4800:ret=MapperExRAM[dopol&0x7f];
        if(dopol&0x80)
         dopol=(dopol&0x80)|((dopol++)&0x7f);
        break;
        case 0x5000:ret=IRQCount&0xFF;break;
        case 0x5800:ret=IRQCount>>8;break;
        }
return ret;
}


void Mapper19_write(uint16 A,uint8 V)
{
        switch(A&0xF800){
        case 0x4800:MapperExRAM[dopol&0x7f]=V;
		    if(dopol&0x40) MapExpSound=(void *)NamcoSound;
                    if(dopol&0x80)
                     dopol=(dopol&0x80)|((dopol++)&0x7f);
                    break;
        case 0xf800:dopol=V;break;
        case 0x5000: IRQCount&=0xFF00;IRQCount|=V;IRQlow&=~1;break;
        case 0x5800: IRQCount&=0x00ff;IRQCount|=V<<8;
                     IRQa=V&0x80;
                     //IRQCount=IRQLatch;
                     IRQlow&=~1;
                     break;
        case 0x8000:
                     if(!(gorfus&0x40) && (V&0xE0)) VRAM_BANK1(0x0000,V&7);
                     else{VROM_BANK1(0x0000,V);}
                     break;
        case 0x8800:
                     if(!(gorfus&0x40) && (V&0xE0)) VRAM_BANK1(0x0400,V&7);
                     else{VROM_BANK1(0x0400,V);}
                     break;
        case 0x9000:
                     if(!(gorfus&0x40) && (V&0xE0)) VRAM_BANK1(0x0800,V&7);
                     else{VROM_BANK1(0x0800,V);}
                     break;
        case 0x9800:
                     if(!(gorfus&0x40) && (V&0xE0)) VRAM_BANK1(0x0C00,V&7);
                     else{VROM_BANK1(0x0C00,V);}
                     break;
        case 0xa000:
                     if(!(gorfus&0x80) && (V&0xE0)) VRAM_BANK1(0x1000,V&7);
                     else{VROM_BANK1(0x1000,V);}
                     break;
        case 0xa800:
                     if(!(gorfus&0x80) && (V&0xE0)) VRAM_BANK1(0x1400,V&7);
                     else{VROM_BANK1(0x1400,V);}
                     break;
        case 0xb000:
                     if(!(gorfus&0x80) && (V&0xE0)) VRAM_BANK1(0x1800,V&7);
                     else{VROM_BANK1(0x1800,V);}
                     break;
        case 0xb800:
                     if(!(gorfus&0x80) && (V&0xE0)) VRAM_BANK1(0x1c00,V&7);
                     else{VROM_BANK1(0x1c00,V);}
                     break;
        case 0xc000:if(V>=0xE0)
                     {
                     vnapage[0]=VRAM+0x2000+((V&1)<<11);
                     VPAL2[0]=((V&1)<<1)|0x8000;
                     }
                    else
                    {
                     V&=vmask1;
                     vnapage[0]=VROM+(V<<10);
                     VPAL2[0]=V|0x8800;
                    }
                    break;
        case 0xc800:if(V>=0xE0)
                     {
                     vnapage[1]=VRAM+0x2000+((V&1)<<11);
                     VPAL2[1]=((V&1)<<1)|0x8000;
                     }
                    else
                     {
                    V&=vmask1;vnapage[1]=VROM+(V<<10);
                    VPAL2[1]=V|0x8800;
                     }
                    break;
        case 0xD000:if(V>=0xE0)
                     {
                     vnapage[2]=VRAM+0x2000+((V&1)<<11);
                     VPAL2[2]=((V&1)<<1)|0x8000;
                     }
                    else
                    {
                    V&=vmask1;vnapage[2]=VROM+(V<<10);
                    VPAL2[2]=V|0x8800;
                    }
                    break;
        case 0xD800:if(V>=0xE0)
                     {
                     vnapage[3]=VRAM+0x2000+((V&1)<<11);
                     VPAL2[3]=((V&1)<<1)|0x8000;
                     }
                    else
                    {
                    V&=vmask1;
                    vnapage[3]=VROM+(V<<10);
                    VPAL2[3]=V|0x8800;
                    }
                    break;

        case 0xE000:
        ROM_BANK8(0x8000,V);
        break;
        case 0xE800:
         ROM_BANK8(0xA000,V);
         break;
        case 0xF000:
         ROM_BANK8(0xC000,V);
         break;
        }
}

static int P,V;
static byte PlayIndex[8];
static unsigned long freq;
static byte duff;
static int duff2;
static long envelope;
static long vco;
static char lengo;

int NamcoSound(int32 *Wave)
{
      for(P=0;P<8;P++)
      {
       if((MapperExRAM[0x44+(P<<3)]&0xE0) && (MapperExRAM[0x47+(P<<3)]&0xF))
       {
        vco=vcount[P];
        freq=MapperExRAM[0x40+(P<<3)];
        freq|=MapperExRAM[0x42+(P<<3)]<<8;
        freq|=(MapperExRAM[0x44+(P<<3)]&3)<<16;
        if(!freq) continue;
        
        inc=(long double)(SndRate<<15)/(((long double)freq*(440*
         (2-((MapperExRAM[0x44+(P<<3)]>>4)&1)))/(long double)15467));
//        inc=(long double)(SndRate<<15)/(
//        (freq+(((MapperExRAM[0x44+(P<<3)]>>4)&1)*440))/(long double)27
//        );


        envelope=((MapperExRAM[0x47+(P<<3)]&0xF)<<18)/15;
        duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])>>1)&0x3F];
        if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
         duff>>=4;
        duff&=0xF;
        duff2=((duff-8)*envelope)>>16;

        lengo=((8-((MapperExRAM[0x44+(P<<3)]>>2)&3)))<<2;

        for(V=0;V<256 OVERSAMPLE;V++)
        {
         if(vco>=inc)
         {
          PlayIndex[P]++;
          if(PlayIndex[P]>=lengo)
           PlayIndex[P]=0;
          vco-=inc;
          duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&0x3F)>>1];
          if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
           duff>>=4;
          duff&=0xF;
          duff2=((duff-8)*envelope)>>16;
         }
          Wave[V>>4]+=duff2;
          vco+=0x8000;
        }
        vcount[P]=vco;
       }
      }
  return 1;
}

int aaNamcoSound(int32 *Wave)
{
      int P,V;
      static byte PlayIndex[8];
      unsigned long freq;
      for(P=0;P<8;P++)
      {
       if((MapperExRAM[0x44+(P<<3)]&0xE0) && (MapperExRAM[0x47+(P<<3)]&0xF))
       {
        byte duff;
        int duff2;
        long envelope;
        long vco;
        vco=vcount[P];
        freq=MapperExRAM[0x40+(P<<3)];
        freq|=MapperExRAM[0x42+(P<<3)]<<8;
        freq|=(MapperExRAM[0x44+(P<<3)]&3)<<16;
        if(!freq) continue;
        inc=(long double)(SndRate<<15)/(((long double)freq*(220*
         (2+( ((MapperExRAM[0x44+(P<<3)]>>4)&1))))/(long double)15467));
        envelope=((MapperExRAM[0x47+(P<<3)]&0xF)<<18)/15;
        duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&0x3F)>>1];
        if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
         duff>>=4;
        duff&=0xF;
        duff2=((duff-8)*envelope)>>16;
        for(V=0;V<256 OVERSAMPLE;V++)
        {
         if(vco>=inc)
         {
          PlayIndex[P]++;
          if(PlayIndex[P]>=((8-((MapperExRAM[0x44+(P<<3)]>>2)&3)))<<2)
           PlayIndex[P]=0;
          vco-=inc;
          duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&0x3F)>>1];
          if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
           duff>>=4;
          duff&=0xF;
          duff2=((duff-8)*envelope)>>17;
         }
          Wave[V>>4]+=duff2;
          vco+=0x8000;
        }
        vcount[P]=vco;
       }
      }
  return 1;
}


int zNamcoSound(int32 *Wave)
{
      int P,V;
      static byte PlayIndex[8];
      unsigned long freq;
//      for(P=0;P<=((MapperExRAM[0x7F]>>4)&7);P++)
      for(P=0;P<8;P++)
//      for(P=((MapperExRAM[0x7F]>>4)&7);P>=0;P--)
      {
       if((MapperExRAM[0x44+(P<<3)]&0xE0) && (MapperExRAM[0x47+(P<<3)]&0xF))
//       if((MapperExRAM[0x44+(P<<3)]&0x1C) && (MapperExRAM[0x47+(P<<3)]&0xF))
       {
        byte duff;
        int duff2;
        long envelope;
        long vco;
        vco=vcount[P];
        freq=MapperExRAM[0x40+(P<<3)];
        freq|=MapperExRAM[0x42+(P<<3)]<<8;
        freq|=(MapperExRAM[0x44+(P<<3)]&3)<<16;
        if(!freq) continue;

        //#define NTSC_CPU 1789772.7272727272727272
        //#define PAL_CPU  1773447.2
        //if(PAL)
        //else

        inc=(long double)(SndRate<<15)/
        (((long double)21477270*freq)/((long double)
         0x40000*
         (((MapperExRAM[0x7F]>>4)&7)+1)*
         ((8-((MapperExRAM[0x44+(P<<3)]>>2)&7))<<2)*
         45));


        //inc=(long double)(SndRate<<15)/(((long double)freq*(440*
        // (2-((MapperExRAM[0x44+(P<<3)]>>4)&1)))/(long double)15467));

        envelope=((MapperExRAM[0x47+(P<<3)]&0xF)<<18)/15;
        duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&0x3F)>>1];
        if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
         duff>>=4;
        duff&=0xF;
        duff2=((duff-8)*envelope)>>16;
        for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
        {
         if(vco>=inc)
         {
          PlayIndex[P]++;
          //if(PlayIndex[P]>=((8-((MapperExRAM[0x44+(P<<3)]>>2)&(7))))<<2)
          if(PlayIndex[P]>=((8-((MapperExRAM[0x44+(P<<3)]>>2)&(3))))<<2)
           PlayIndex[P]=0;
          vco-=inc;
          duff=MapperExRAM[((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&0x3F)>>1];
          if((MapperExRAM[0x46+(P<<3)]+PlayIndex[P])&1)
           duff>>=4;
          duff&=0xF;
          duff2=((duff-8)*envelope)>>17;
         }
          Wave[V>>4]+=duff2;
          vco+=0x8000;
        }
        vcount[P]=vco;
       }
      }
  return 0;//1;
}

void Mapper19_init(void)
{
        VROM_BANK8(vmask);
        SetWriteHandler(0x8000,0xffff,(void *)Mapper19_write);
        SetWriteHandler(0x4020,0x5fff,(void *)Mapper19_write);
        SetReadHandler(0x4800,0x5fff,(void *)Namco_Read);
        MapIRQHook=(void *)NamcoIRQHook;
}

//M21
#define K4buf mapbyte2
#define K4IRQ mapbyte1[1]
#define K4sel mapbyte1[0]


void Mapper21_write(uint16 A,uint8 V)
{
A|=((A>>5)&0xF);

if((A&0xF000)==0xA000)
  ROM_BANK8(0xA000,V);
else if((A&0xF000)==0x8000)
 {
        if(K4sel&2)
         ROM_BANK8(0xC000,V);
        else
         ROM_BANK8(0x8000,V);
 }
else switch(A&0xF006)
 {
 case 0x9000:
             switch(V&0x3)
             {
             case 0:MIRROR_SET(0);break;
             case 1:MIRROR_SET(1);break;
             case 2:onemir(0);break;
             case 3:onemir(2);break;
             }
             break;
 case 0x9006:
 case 0x9004:
 case 0x9002:if((K4sel&2)!=(V&2))
             {
             byte swa;
             swa=PRGBankList[0];
             ROM_BANK8(0x8000,PRGBankList[2]);
             ROM_BANK8(0xc000,swa);
             }
             K4sel=V;
             break;
   case 0xb000:K4buf[0]&=0xF0;K4buf[0]|=V&0x0F;VROM_BANK1(0x000,(K4buf[0]));break;
   case 0xb002:K4buf[0]&=0x0F;K4buf[0]|=V<<4;VROM_BANK1(0x000,(K4buf[0]));break;

   case 0xb004:K4buf[1]&=0xF0;K4buf[1]|=V&0x0F;VROM_BANK1(0x400,(K4buf[1]));break;
   case 0xb006:K4buf[1]&=0x0F;K4buf[1]|=V<<4;VROM_BANK1(0x400,(K4buf[1]));break;

   case 0xc000:K4buf[2]&=0xF0;K4buf[2]|=V&0x0F;VROM_BANK1(0x800,(K4buf[2]));break;
   case 0xc002:K4buf[2]&=0x0F;K4buf[2]|=V<<4;VROM_BANK1(0x800,(K4buf[2]));break;

   case 0xc004:K4buf[3]&=0xF0;K4buf[3]|=V&0x0F;VROM_BANK1(0xc00,(K4buf[3]));break;
   case 0xc006:K4buf[3]&=0x0F;K4buf[3]|=V<<4;VROM_BANK1(0xc00,(K4buf[3]));break;

   case 0xd000:K4buf[4]&=0xF0;K4buf[4]|=V&0x0F;VROM_BANK1(0x1000,(K4buf[4]));break;
   case 0xd002:K4buf[4]&=0x0F;K4buf[4]|=V<<4;VROM_BANK1(0x1000,(K4buf[4]));break;

   case 0xd004:K4buf[5]&=0xF0;K4buf[5]|=V&0x0F;VROM_BANK1(0x1400,(K4buf[5]));break;
   case 0xd006:K4buf[5]&=0x0F;K4buf[5]|=V<<4;VROM_BANK1(0x1400,(K4buf[5]));break;

   case 0xe000:K4buf[6]&=0xF0;K4buf[6]|=V&0x0F;VROM_BANK1(0x1800,(K4buf[6]));break;
   case 0xe002:K4buf[6]&=0x0F;K4buf[6]|=V<<4;VROM_BANK1(0x1800,(K4buf[6]));break;

   case 0xe004:K4buf[7]&=0xF0;K4buf[7]|=V&0x0F;VROM_BANK1(0x1c00,(K4buf[7]));break;
   case 0xe006:K4buf[7]&=0x0F;K4buf[7]|=V<<4;VROM_BANK1(0x1c00,(K4buf[7]));break;
   case 0xf000:IRQLatch&=0xF0;IRQLatch|=V&0xF;break;
   case 0xf002:IRQLatch&=0x0F;IRQLatch|=V<<4;break;
   case 0xf004:IRQCount=IRQLatch;
               IRQa=V&2;K4IRQ=V&1;break;
   case 0xf006:IRQa=K4IRQ;break;
 }
}
static void KonamiIRQHook(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=342)
    {
     doagainbub:count-=342;IRQCount++;
     if(IRQCount&0x100) {count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=342) goto doagainbub;
    }
 }
}

void Mapper21_init(void)
{
        SetWriteHandler(0x8000,0xffff,(void *)Mapper21_write);
        MapIRQHook=(void *)KonamiIRQHook;
}

//M22
#define K4buf mapbyte2

void Mapper22_write(uint16 A,uint8 V)
{
        if(A<=0xAFFF)
         {
          switch(A&0xF000)
          {
          case 0x8000:ROM_BANK8(0x8000,V);break;
          case 0xa000:ROM_BANK8(0xA000,V);break;
          case 0x9000:switch(V&3){
                      case 0x00:MIRROR_SET2(1);break;
                      case 0x01:MIRROR_SET2(0);break;
                      case 0x02:onemir(0);break;
                      case 0x03:onemir(2);break;
                      }
                      break;
          }
         }
        else
         {
          switch(A&0xF003){
           case 0xb000:K4buf[0]&=0xF0;K4buf[0]|=V&0x0F;VROM_BANK1(0x000,((K4buf[0]>>1)));break;
           case 0xb002:K4buf[0]&=0x0F;K4buf[0]|=V<<4;VROM_BANK1(0x000,((K4buf[0]>>1)));break;
           case 0xb001:K4buf[1]&=0xF0;K4buf[1]|=V&0x0F;VROM_BANK1(0x400,((K4buf[1]>>1)));break;
           case 0xb003:K4buf[1]&=0x0F;K4buf[1]|=V<<4;VROM_BANK1(0x400,((K4buf[1]>>1)));break;
           case 0xc000:K4buf[2]&=0xF0;K4buf[2]|=V&0x0F;VROM_BANK1(0x800,((K4buf[2]>>1)));break;
           case 0xc002:K4buf[2]&=0x0F;K4buf[2]|=V<<4;VROM_BANK1(0x800,((K4buf[2]>>1)));break;
           case 0xc001:K4buf[3]&=0xF0;K4buf[3]|=V&0x0F;VROM_BANK1(0xc00,((K4buf[3]>>1)));break;
           case 0xc003:K4buf[3]&=0x0F;K4buf[3]|=V<<4;VROM_BANK1(0xc00,((K4buf[3]>>1)));break;
           case 0xd000:K4buf[4]&=0xF0;K4buf[4]|=V&0x0F;VROM_BANK1(0x1000,((K4buf[4]>>1)));break;
           case 0xd002:K4buf[4]&=0x0F;K4buf[4]|=V<<4;VROM_BANK1(0x1000,((K4buf[4]>>1)));break;
           case 0xd001:K4buf[5]&=0xF0;K4buf[5]|=V&0x0F;VROM_BANK1(0x1400,((K4buf[5]>>1)));break;
           case 0xd003:K4buf[5]&=0x0F;K4buf[5]|=V<<4;VROM_BANK1(0x1400,((K4buf[5]>>1)));break;
           case 0xe000:K4buf[6]&=0xF0;K4buf[6]|=V&0x0F;VROM_BANK1(0x1800,((K4buf[6]>>1)));break;
           case 0xe002:K4buf[6]&=0x0F;K4buf[6]|=V<<4;VROM_BANK1(0x1800,((K4buf[6]>>1)));break;
           case 0xe001:K4buf[7]&=0xF0;K4buf[7]|=V&0x0F;VROM_BANK1(0x1c00,((K4buf[7]>>1)));break;
           case 0xe003:K4buf[7]&=0x0F;K4buf[7]|=V<<4;VROM_BANK1(0x1c00,((K4buf[7]>>1)));break;
         }
        }
}


void Mapper22_init(void)
{
	SetWriteHandler(0x8000,0xffff,(void *)Mapper22_write);
}

//M23
#define K4buf mapbyte2
#define K4IRQ mapbyte1[1]
#define K4sel mapbyte1[0]


void Mapper23_write(uint16 A,uint8 V)
{
 if((A&0xF000)==0x8000)
        {
        if(K4sel&2)
         ROM_BANK8(0xC000,V);
        else
         ROM_BANK8(0x8000,V);
        }
else if((A&0xF000)==0xA000) ROM_BANK8(0xA000,V);
else
{
A|=((A>>2)&0x3)|((A>>4)&0x3)|((A>>6)&0x3);
switch(A&0xF003)
  {

case 0xf000:IRQlow&=~1;IRQLatch&=0xF0;IRQLatch|=V&0xF;break;
case 0xf001:IRQlow&=~1;IRQLatch&=0x0F;IRQLatch|=V<<4;break;
case 0xf002:IRQlow&=~1;IRQCount=IRQLatch;IRQa=V&2;K4IRQ=V&1;break;
case 0xf003:IRQlow&=~1;IRQa=K4IRQ;break;
  case 0x9001:
  case 0x9002:
  case 0x9003:
             if((K4sel&2)!=(V&2))
             {
             byte swa;
             swa=PRGBankList[0];
             ROM_BANK8(0x8000,PRGBankList[2]);
             ROM_BANK8(0xc000,swa);
             }
             K4sel=V;
             break;

  case 0x9000:
     switch(V&0x3)
        {
             case 0:MIRROR_SET(0);break;
             case 1:MIRROR_SET(1);break;
             case 2:onemir(0);break;
             case 3:onemir(2);break;
        }
        break;
   case 0xb000:K4buf[0]&=0xF0;K4buf[0]|=V&0x0F;
VROM_BANK1(0x000,(K4buf[0]));break;
   case 0xb001:K4buf[0]&=0x0F;K4buf[0]|=V<<4;
VROM_BANK1(0x000,(K4buf[0]));break;
   case 0xb002:K4buf[1]&=0xF0;K4buf[1]|=V&0x0F;
VROM_BANK1(0x400,(K4buf[1]));break;
   case 0xb003:K4buf[1]&=0x0F;K4buf[1]|=V<<4;
VROM_BANK1(0x400,(K4buf[1]));break;
   case 0xc000:K4buf[2]&=0xF0;K4buf[2]|=V&0x0F;
VROM_BANK1(0x800,(K4buf[2]));break;
   case 0xc001:K4buf[2]&=0x0F;K4buf[2]|=V<<4;
VROM_BANK1(0x800,(K4buf[2]));break;
   case 0xc002:K4buf[3]&=0xF0;K4buf[3]|=V&0x0F;
VROM_BANK1(0xc00,(K4buf[3]));break;
   case 0xc003:K4buf[3]&=0x0F;K4buf[3]|=V<<4;
VROM_BANK1(0xc00,(K4buf[3]));break;
   case 0xd000:K4buf[4]&=0xF0;K4buf[4]|=V&0x0F;
VROM_BANK1(0x1000,(K4buf[4]));break;
   case 0xd001:K4buf[4]&=0x0F;K4buf[4]|=V<<4;
VROM_BANK1(0x1000,(K4buf[4]));break;
   case 0xd002:K4buf[5]&=0xF0;K4buf[5]|=V&0x0F;
VROM_BANK1(0x1400,(K4buf[5]));break;
   case 0xd003:K4buf[5]&=0x0F;K4buf[5]|=V<<4;
VROM_BANK1(0x1400,(K4buf[5]));break;
   case 0xe000:K4buf[6]&=0xF0;K4buf[6]|=V&0x0F;
VROM_BANK1(0x1800,(K4buf[6]));break;
   case 0xe001:K4buf[6]&=0x0F;K4buf[6]|=V<<4;
VROM_BANK1(0x1800,(K4buf[6]));break;
   case 0xe002:K4buf[7]&=0xF0;K4buf[7]|=V&0x0F;
VROM_BANK1(0x1c00,(K4buf[7]));break;
   case 0xe003:K4buf[7]&=0x0F;K4buf[7]|=V<<4;
VROM_BANK1(0x1c00,(K4buf[7]));break;
  }
 }
}

void KonamiIRQHook2(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=342)
    {
     doagainbub:count-=342;IRQCount++;
     if(IRQCount&0x100) {IRQlow|=1;count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=342) goto doagainbub;
    }
 }
}

void Mapper23_init(void)
{
        SetWriteHandler(0x8000,0xffff,(void *)Mapper23_write);
        MapIRQHook=(void *)KonamiIRQHook2;
}

//M24
static int32 inc;
void Mapper24_write(uint16 A,uint8 V)
{
        switch (A&0xF003){
        case 0x8000:V&=pmask16;ROM_BANK16(0x8000,V);break;
        case 0x9000:VPSG[0]=V;break;
        case 0x9001:VPSG[2]=V;break;
        case 0x9002:VPSG[3]=V;break;
        case 0xa000:VPSG[4]=V;break;
        case 0xa001:VPSG[6]=V;break;
        case 0xa002:VPSG[7]=V;break;
        case 0xb000:VPSG2[0]=V;break;
        case 0xb001:VPSG2[1]=V;break;
        case 0xb002:VPSG2[2]=V;break;
        case 0xB003:
        switch(V&0xF)
         {
         case 0x0:MIRROR_SET2(1);break;
         case 0x4:MIRROR_SET2(0);break;
         case 0x8:onemir(0);break;
         case 0xC:onemir(2);break;
         }
        break;
        case 0xC000:ROM_BANK8(0xC000,V);break;
        case 0xD000:VROM_BANK1(0x0000,V);break;
        case 0xD001:VROM_BANK1(0x0400,V);break;
        case 0xD002:VROM_BANK1(0x0800,V);break;
        case 0xD003:VROM_BANK1(0x0c00,V);break;
        case 0xE000:VROM_BANK1(0x1000,V);break;
        case 0xE001:VROM_BANK1(0x1400,V);break;
        case 0xE002:VROM_BANK1(0x1800,V);break;
        case 0xE003:VROM_BANK1(0x1c00,V);break;
        case 0xF000:IRQLatch=V;break;
        case 0xF001:IRQa=V&2;
                    vrctemp=V&1;
                    if(V&2) {IRQCount=IRQLatch;}
                    break;
        case 0xf002:IRQa=vrctemp;break;
        case 0xF003:break;
  }
}
/*
static void KonamiIRQHook(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=341)
    {
     doagainbub:count-=341;IRQCount++;
     if(IRQCount&0x100) {count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=341) goto doagainbub;
    }
 }
}
*/
int VRC6Sound(int32 *Wave)
{
    uint8 amp;
    int32 freq;
    int V;
    if(VPSG[0x3]&0x80)
    {
     unsigned long dcycs;
     amp=VPSG[0]&15;
     freq=(((VPSG[0x2]|((VPSG[0x3]&15)<<8))+1));
     inc=(long double)((unsigned long)((SndRate OVERSAMPLE)<<12))/
((long double)PSG_base/freq);
     switch(VPSG[0]&0x70)
     {
      default:
      case 0x00:dcycs=inc>>4;break;
      case 0x10:dcycs=inc>>3;break;
      case 0x20:dcycs=(inc*3)>>4;break;
      case 0x30:dcycs=inc>>2;break;
      case 0x40:dcycs=(inc*5)>>4;break;
      case 0x50:dcycs=(inc*6)>>4;break;
      case 0x60:dcycs=(inc*7)>>4;break;
      case 0x70:dcycs=inc>>1;break;
     }
             for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
              {
               if(vcount[0]>=dcycs)
                 Wave[V>>4]-=amp;
               else
                 Wave[V>>4]+=amp;
               vcount[0]+=0x1000;
               if(vcount[0]>=inc) vcount[0]-=inc;
               }
    }
    if(VPSG[0x7]&0x80)
    {
     unsigned long dcycs;
     amp=VPSG[4]&15;
     freq=(((VPSG[0x6]|((VPSG[0x7]&15)<<8))+1));
     inc=(long double)((unsigned long)((SndRate OVERSAMPLE)<<12))/((long double)PSG_base/freq);
     switch(VPSG[4]&0x70)
     {
      default:
      case 0x00:dcycs=inc>>4;break;
      case 0x10:dcycs=inc>>3;break;
      case 0x20:dcycs=(inc*3)>>4;break;
      case 0x30:dcycs=inc>>2;break;
      case 0x40:dcycs=(inc*5)>>4;break;
      case 0x50:dcycs=(inc*6)>>4;break;
      case 0x60:dcycs=(inc*7)>>4;break;
      case 0x70:dcycs=inc>>1;break;
     }
             for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
              {
               if(vcount[1]>=dcycs)
                 Wave[V>>4]-=amp;
               else
                 Wave[V>>4]+=amp;
               vcount[1]+=0x1000;
               if(vcount[1]>=inc) vcount[1]-=inc;
               }
    }

   if(VPSG2[2]&0x80)
   {
    static long long saw1phaseacc=0;
    unsigned long freq3;
    static byte b3=0;
    static long phaseacc=0;
    static long duff;
    freq3=(VPSG2[1]+((VPSG2[2]&15)<<8)+1);
    duff=(((phaseacc>>3)&0x1f)-15);
    for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
    {
     saw1phaseacc-=nesincsizeLL;
     if(saw1phaseacc<=0)
     {
      long long t;
      rea:
      t=freq3;
      t<<=50;	// 49 + 1
      saw1phaseacc+=t;
      phaseacc+=VPSG2[0]&0x3f;
      b3++;
      if(b3==7)
       {
       b3=0;
       phaseacc=0;
       }
       duff=(((phaseacc>>3)&0x1f)-15);
      if(saw1phaseacc<=0) goto rea;
      }
     Wave[V>>4]+=duff;
    }
   }
 return 0;
}

void Mapper24_init(void)
{
        SetWriteHandler(0x8000,0xffff,(void *)Mapper24_write);
        MapIRQHook=(void *)KonamiIRQHook;
	MapExpSound=(void *)VRC6Sound;
}

//M25
#define K4buf mapbyte2
#define K4IRQ mapbyte1[1]
#define K4sel mapbyte1[0]

void Mapper25_write(uint16 A,uint8 V)
{

if((A&0xF000)==0xA000)
  ROM_BANK8(0xA000,V);
else if((A&0xF000)==0x8000)
 {
        if(K4sel&2)
         ROM_BANK8(0xC000,V);
        else
         ROM_BANK8(0x8000,V);
 }
else switch(A&0xF00F)
 {
 case 0x9000:
             switch(V&0x3)
             {
             case 0:MIRROR_SET(0);break;
             case 1:MIRROR_SET(1);break;
             case 2:onemir(0);break;
             case 3:onemir(2);break;
             }
             break;
 case 0x9004:
 case 0x9001:if((K4sel&2)!=(V&2))
             {
             byte swa;
             swa=PRGBankList[0];
             ROM_BANK8(0x8000,PRGBankList[2]);
             ROM_BANK8(0xc000,swa);
             }
             K4sel=V;
             break;
case 0xb000:K4buf[0]&=0xF0;K4buf[0]|=V&0x0f;VROM_BANK1(0x0,K4buf[0]);break;
case 0xb008:
case 0xb002:K4buf[0]&=0x0F;K4buf[0]=K4buf[0]|(V<<4);VROM_BANK1(0x0,K4buf[0]);
break;
case 0xb004:
case 0xb001:K4buf[1]&=0xF0;K4buf[1]|=V&0x0f;VROM_BANK1(0x400,K4buf[1]);break;
case 0xb00c:
case 0xb003:K4buf[1]&=0x0F;K4buf[1]=K4buf[1]|(V<<4);VROM_BANK1(0x400,K4buf[1]);
break;
case 0xc000:K4buf[2]&=0xF0;K4buf[2]|=V&0x0f;VROM_BANK1(0x800,K4buf[2]);break;
case 0xc008:
case 0xc002:K4buf[2]&=0x0F;K4buf[2]=K4buf[2]|(V<<4);VROM_BANK1(0x800,K4buf[2]);
break;
case 0xc004:
case 0xc001:K4buf[3]&=0xF0;K4buf[3]|=V&0x0f;VROM_BANK1(0xc00,K4buf[3]);break;
case 0xc00c:
case 0xc003:K4buf[3]&=0x0F;K4buf[3]=K4buf[3]|(V<<4);VROM_BANK1(0xc00,K4buf[3]);
break;
case 0xd000:K4buf[4]&=0xF0;K4buf[4]|=V&0x0f;VROM_BANK1(0x1000,K4buf[4]);break;
case 0xd008:
case 0xd002:K4buf[4]&=0x0F;K4buf[4]=K4buf[4]|(V<<4);VROM_BANK1(0x1000,K4buf[4]);break;
case 0xd004:
case 0xd001:K4buf[5]&=0xF0;K4buf[5]|=V&0x0f;VROM_BANK1(0x1400,K4buf[5]);break;
case 0xd00c:
case 0xd003:K4buf[5]&=0x0F;K4buf[5]=K4buf[5]|(V<<4);VROM_BANK1(0x1400,K4buf[5]);break;

case 0xe000:K4buf[6]&=0xF0;K4buf[6]|=V&0x0f;VROM_BANK1(0x1800,K4buf[6]);break;
case 0xe008:
case 0xe002:K4buf[6]&=0x0F;K4buf[6]=K4buf[6]|(V<<4);VROM_BANK1(0x1800,K4buf[6]);break;
case 0xe004:
case 0xe001:K4buf[7]&=0xF0;K4buf[7]|=V&0x0f;VROM_BANK1(0x1c00,K4buf[7]);break;
case 0xe00c:
case 0xe003:K4buf[7]&=0x0F;K4buf[7]=K4buf[7]|(V<<4);VROM_BANK1(0x1c00,K4buf[7]);break;
case 0xf000:IRQLatch&=0xF0;IRQLatch|=V&0xF;break;
case 0xf008:
case 0xf002:IRQLatch&=0x0F;IRQLatch|=V<<4;break;
case 0xf004:
case 0xf001:IRQCount=IRQLatch;IRQa=V&2;K4IRQ=V&1;break;
case 0xf00c:
case 0xf003:IRQa=K4IRQ;break;
 }
}
/*
static void KonamiIRQHook(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=342)
    {
     doagainbub:count-=342;IRQCount++;
     if(IRQCount&0x100) {count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=342) goto doagainbub;
    }
 }
}
*/
void Mapper25_init(void)
{
        SetWriteHandler(0x8000,0xffff,(void *)Mapper25_write);
        MapIRQHook=(void *)KonamiIRQHook;
}

//M26
void Mapper26_write(uint16 A,uint8 V)
{
        switch (A){
        case 0x8000:V&=pmask16;ROM_BANK16(0x8000,V);break;
        case 0x9000:VPSG[0]=V;break;
        case 0x9002:VPSG[2]=V;break;
        case 0x9001:VPSG[3]=V;break;
        case 0xa000:VPSG[4]=V;break;
        case 0xa002:VPSG[6]=V;break;
        case 0xa001:VPSG[7]=V;break;
        case 0xb000:VPSG2[0]=V;break;
        case 0xb002:VPSG2[1]=V;break;
        case 0xb001:VPSG2[2]=V;break;

        case 0xB003:
        switch(V&0xF)
         {
         case 0x0:MIRROR_SET2(1);break;
         case 0x4:MIRROR_SET2(0);break;
         case 0x8:onemir(0);break;
         case 0xC:onemir(2);break;
         }
        break;
        case 0xC000:ROM_BANK8(0xC000,V);break;
        case 0xD000:VROM_BANK1(0x0000,V);break;
        case 0xD001:VROM_BANK1(0x0800,V);break;
        case 0xD002:VROM_BANK1(0x0400,V);break;
        case 0xD003:VROM_BANK1(0x0c00,V);break;
        case 0xE000:VROM_BANK1(0x1000,V);break;
        case 0xE001:VROM_BANK1(0x1800,V);break;
        case 0xE002:VROM_BANK1(0x1400,V);break;
        case 0xE003:VROM_BANK1(0x1c00,V);break;
        case 0xF000:IRQLatch=V;break;
        case 0xF002:IRQa&=1;
                    IRQa|=V&2;
                    vrctemp=V&1;
                    if(V&2) {IRQCount=IRQLatch;}
                    break;
        case 0xf001:IRQa&=2;IRQa|=vrctemp;break;
        case 0xF003:break;
  }
}
/*
static void KonamiIRQHook(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=341)
    {
     doagainbub:count-=341;IRQCount++;
     if(IRQCount&0x100) {count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=341) goto doagainbub;
    }
 }
}
*/
void Mapper26_init(void)
{
        SetWriteHandler(0x8000,0xffff,(void *)Mapper26_write);
        MapIRQHook=(void *)KonamiIRQHook;
	MapExpSound=(void *)VRC6Sound;
}

//M32
#define IREMCon mapbyte1[0]

void Mapper32_write(uint16 A,uint8 V)
{
switch(A>>12)
 {
 case 0x8:
          if(IREMCon) ROM_BANK8(0xc000,V);
          else ROM_BANK8(0x8000,V);
          break;
 case 0x9:MIRROR_SET2(V&1);
          IREMCon=(V>>1)&1;
          MIRROR_SET(V&1);
          break;
 case 0xa:ROM_BANK8(0xA000,V);
          break;
 }

if((A&0xF000)==0xb000)
 {
 switch(A&0x000f)
  {
  case 0:VROM_BANK1(0x000,V);break;
  case 1:VROM_BANK1(0x400,V);break;
  case 2:VROM_BANK1(0x800,V);break;
  case 3:VROM_BANK1(0xc00,V);break;
  case 4:VROM_BANK1(0x1000,V);break;
  case 5:VROM_BANK1(0x1400,V);break;
  case 6:VROM_BANK1(0x1800,V);break;
  case 7:VROM_BANK1(0x1c00,V);break;
  }
 }
}
void Mapper32_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper32_write);
}

//M33
void Mapper33_write(uint16 A,uint8 V)
{
        switch(A){
        case 0x8000:if(!mapbyte1[0])
                     MIRROR_SET((V>>6)&1);
                     ROM_BANK8(0x8000,V);
                    break;
        case 0x8001:ROM_BANK8(0xA000,V); break;
        case 0x8002:VROM_BANK2(0x0000,V);break;
        case 0x8003:VROM_BANK2(0x0800,V);break;
        case 0xA000:VROM_BANK1(0x1000,V); break;
        case 0xA001:VROM_BANK1(0x1400,V); break;
        case 0xA002:VROM_BANK1(0x1800,V); break;
        case 0xA003:VROM_BANK1(0x1C00,V); break;
	case 0xc000:IRQCount=V;break;
	case 0xc001:IRQa=V&1;break;
        case 0xe000:mapbyte1[0]=1;MIRROR_SET((V>>6)&1);break;
        }
}

static void heho(void)
{
if(IRQa)
 {
  if(scanline<=240 && (ScreenON || SpriteON))
  {
   IRQCount++;
   if(IRQCount==0x100) {TriggerIRQ();IRQa=0;}
  }
 }
}
void Mapper33_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper33_write);
MapHBIRQHook=(void *)heho;
}

//M34
void Mapper34_write(uint16 A,uint8 V)
{
switch(A)
 {
 case 0x7FFD:ROM_BANK32(0x8000,V);break;
 case 0x7FFE:VROM_BANK4(0x0000,V);break;
 case 0x7fff:VROM_BANK4(0x1000,V);break;
 }
if(A>=0x8000)
 ROM_BANK32(0x8000,V);
}

void Mapper34_init(void)
{
  SetWriteHandler(0x7ffd,0xffff,(void *)Mapper34_write);
}

//M40
byte Mapper40_WRAM(word A)
{
 return Page[A>>13][A];
}

void Mapper40_write(word A, byte V)
{
switch(A&0xe000)
 {
  case 0x8000:IRQa=0;IRQCount=0;break;
  case 0xa000:IRQa=1;break;
  case 0xe000:ROM_BANK8(0xc000,V&7);break;
 }
}
static void Mapper40_hb(void)
{
 if(IRQa)
 {
        if(IRQCount<100) IRQCount++;
        if(IRQCount==36)
        {
        IRQa=0;
        TriggerIRQ();
        }
 }
}

void Mapper40_init(void)
{
  ROM_BANK8(0x6000,(pmask8-1));
  ROM_BANK8(0x8000,(pmask8-3));
  ROM_BANK8(0xa000,(pmask8-2));
  SetWriteHandler(0x8000,0xffff,(void *)Mapper40_write);
  SetReadHandler(0x6000,0x7fff,(void *)Mapper40_WRAM);
  MapHBIRQHook=(void *)Mapper40_hb;
}

//M41
#define calreg mapbyte1[0]
#define calchr mapbyte1[1]

void Mapper41_write(uint16 A,uint8 V)
{
 if(A<0x8000)
 {
 ROM_BANK32(0x8000,A&7);
 MIRROR_SET((A>>5)&1);
 calreg=A;
 calchr&=0x3;
 calchr|=(A>>1)&0xC;
 VROM_BANK8(calchr);
 }
 else if(calreg&0x4)
 {
 calchr&=0xC;
 calchr|=A&3;
 VROM_BANK8(calchr);
 }
}

void Mapper41_init(void)
{
 ROM_BANK32(0x8000,0);
 SetWriteHandler(0x8000,0xffff,(void *)Mapper41_write);
 SetWriteHandler(0x6000,0x67ff,(void *)Mapper41_write);
}

//M42
byte Mapper42_WRAM(word A)
{
 return Page[A>>13][A];
}

void Mapper42_write(word A, byte V)
{
switch(A&0xe003)
 {
  case 0xe000:mapbyte1[0]=V;ROM_BANK8(0x6000,V&0xF);break;
  case 0xe001:MIRROR_SET((V>>3)&1);break;
  case 0xe002:IRQa=V&2;if(!IRQa) IRQCount=0;break;
 }
}
static void Mapper42_hb(void)
{
 if(IRQa)
 {
        if(IRQCount<215) IRQCount++;
        if(IRQCount==215)
        {
        IRQa=0;
        TriggerIRQ();
        }
 }
}
void Mapper42_StateRestore(int version)
{
    ROM_BANK8(0x6000,mapbyte1[0]&0xF);
}


void Mapper42_init(void)
{
  ROM_BANK8(0x6000,0);
  ROM_BANK32(0x8000,pmask32);
  SetWriteHandler(0xe000,0xffff,(void *)Mapper42_write);
  SetReadHandler(0x6000,0x7fff,(void *)Mapper42_WRAM);
  MapHBIRQHook=(void *)Mapper42_hb;
  MapStateRestore=(void *)Mapper42_StateRestore;
}

//M43
void Mapper43_write(uint16 A,uint8 V)
{
  uint32 m;
  int z;

  if(A&0x400)
   onemir(0);
  else
   MIRROR_SET((A>>13)&1);
  m=A&0x1f;

  z=(A>>8)&3;

  switch(pmask8)
  {
   default:
   case 0xFF:
             if(z&2)
              m|=0x20;
             break;
   case 0x1FF:
             m|=z<<5;
             break;
  }

   if(A&0x800)
   {
    ROM_BANK16(0x8000,(m<<1)|((A&0x1000)>>12));
    ROM_BANK16(0xC000,(m<<1)|((A&0x1000)>>12));
   }
   else
    ROM_BANK32(0x8000,m);
}

void Mapper43_init(void)
{
 ROM_BANK32(0x8000,0);
 SetWriteHandler(0x8000,0xffff,(void *)Mapper43_write);
}

//M44
#define M44g mapbyte3[0]

static inline void VROM_BANK1MOD1(uint32 A,uint32 V) 
{
        if(M44g>=6)
        {
         V&=0xFF;
         V|=(M44g&6)<<7;
        }
        else
        {
         V&=0x7F;
         V|=M44g<<7;
        }
        VROM_BANK1(A,V);
}

static inline void ROM_BANK8MOD1(unsigned short A, byte V)
{

        if(M44g>=6)
        {
         V&=0x1f;
         V|=(M44g&6)<<4;
        }
        else
        {
         V&=0xF;
         V|=M44g<<4;
        }
        ROM_BANK8(A,V);  
}

void Mapper44_write(uint16 A,uint8 V)
{
        switch(A&0xE001){
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {uint32 swa;swa=PRGBankList[0];ROM_BANK8(0x8000,PRGBankList[2]);
          ROM_BANK8(0xc000,swa);}
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            uint32 swa;
            swa=CHRBankList[4];
            VROM_BANK1(0x1000,CHRBankList[0]);
            VROM_BANK1(0x0000,swa);
            swa=CHRBankList[5];
            VROM_BANK1(0x1400,CHRBankList[1]);
            VROM_BANK1(0x0400,swa);
            swa=CHRBankList[6];
            VROM_BANK1(0x1800,CHRBankList[2]);
            VROM_BANK1(0x0800,swa);
            swa=CHRBankList[7];
            VROM_BANK1(0x1c00,CHRBankList[3]);
            VROM_BANK1(0x0c00,swa);
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0: V&=0xFE;VROM_BANK1MOD1((cbase^0x1000),V);VROM_BANK1MOD1((cbase^0x1400),V+1);break;
                case 1: V&=0xFE;VROM_BANK1MOD1((cbase^0x1800),V);VROM_BANK1MOD1((cbase^0x1c00),V+1);break;
                case 2: VROM_BANK1MOD1(cbase^0x000,V); break;
                case 3: VROM_BANK1MOD1(cbase^0x400,V); break;
                case 4: VROM_BANK1MOD1(cbase^0x800,V); break;
                case 5: VROM_BANK1MOD1(cbase^0xC00,V); break;
                case 6: if (MMC3_cmd&0x40) ROM_BANK8MOD1(0xC000,V);
                        else ROM_BANK8MOD1(0x8000,V);
                        break;
                case 7: ROM_BANK8MOD1(0xA000,V);
                        break;
               }
               break;

        case 0xA000:
        MIRROR_SET(V&1);
        break;
        case 0xA001:
                    {
                    int x;
                    V&=7;
                    M44g=V;
                    for(x=0;x<4;x++)
                     ROM_BANK8MOD1(0x8000+(x*8192),PRGBankList[x]);
                    if(V>=6)
                     ROM_BANK16(0xc000,pmask16);
                    for(x=0;x<8;x++)
                     VROM_BANK1MOD1((x*1024),CHRBankList[x]);
                    }
                    break;

	#include "mmc3irq.h"
 }
}

void Mapper44_init(void)
{
 ROM_BANK16(0xc000,7);
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper44_write);
 MapHBIRQHook=(void *)MMC3_hb;
}

//M45
#define MQW mapbyte4
#define MQP mapbyte4[5]


static int atable[16]={0,0,0,0,0,0,0,0,1,3,7,0xF,0x1F,0x3F,0x7F,0xFF};

static inline void VROM_BANK1MOD2(uint32 A,uint32 V)
{
 V&=atable[MQW[2]&0xF];
 V|=MQW[0];
 V+=(MQW[2]&0x10)<<4;
 VROM_BANK1(A,V);

}

static inline void ROM_BANK8MOD2(unsigned short A, byte V)
{
 V&=(MQW[3]&0x3F)^0xFF;
 V&=0x3F;
 V|=MQW[1];
 ROM_BANK8(A,V);
}


void Mapper45_q(uint16 A, uint8 V)
{
 int x;

 MQW[MQP]=V;
 MQP=(MQP+1)&3;

 for(x=0;x<4;x++)
  ROM_BANK8MOD2(0x8000+x*8192,mapbyte2[x]);
 for(x=0;x<8;x++)
  VROM_BANK1MOD2(0x0000+x*1024,mapbyte3[x]);

}


void Mapper45_write(uint16 A,uint8 V)
{
        switch(A&0xE001){
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {
          byte swa;
          swa=PRGBankList[0];
          ROM_BANK8(0x8000,PRGBankList[2]);
          ROM_BANK8(0xc000,swa);
          swa=mapbyte2[0];
          mapbyte2[0]=mapbyte2[2];
          mapbyte2[2]=swa;
         }
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            int x;
            uint32 swa;
            swa=CHRBankList[4];
            VROM_BANK1(0x1000,CHRBankList[0]);
            VROM_BANK1(0x0000,swa);
            swa=CHRBankList[5];
            VROM_BANK1(0x1400,CHRBankList[1]);
            VROM_BANK1(0x0400,swa);
            swa=CHRBankList[6];
            VROM_BANK1(0x1800,CHRBankList[2]);
            VROM_BANK1(0x0800,swa);
            swa=CHRBankList[7];
            VROM_BANK1(0x1c00,CHRBankList[3]);
            VROM_BANK1(0x0c00,swa);
                
            for(x=0;x<4;x++)
            {
             swa=mapbyte3[4+x];
             mapbyte3[4+x]=mapbyte3[x];
             mapbyte3[x]=swa;
            }
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0: V&=0xFE;mapbyte3[(cbase>>10)^0x4]=V;mapbyte3[(cbase>>10)^0x5]=V+1;VROM_BANK1MOD2((cbase^0x1000),V);VROM_BANK1MOD2((cbase^0x1400),V+1);break;
                case 1: V&=0xFE;mapbyte3[(cbase>>10)^0x6]=V;mapbyte3[(cbase>>10)^0x7]=V+1;VROM_BANK1MOD2((cbase^0x1800),V);VROM_BANK1MOD2((cbase^0x1c00),V+1);break;
                case 2: VROM_BANK1MOD2(cbase^0x000,V);mapbyte3[(cbase>>10)]=V;break;
                case 3: VROM_BANK1MOD2(cbase^0x400,V);mapbyte3[(cbase>>10)^1]=V;break;
                case 4: VROM_BANK1MOD2(cbase^0x800,V);mapbyte3[(cbase>>10)^2]=V;break;
                case 5: VROM_BANK1MOD2(cbase^0xC00,V);mapbyte3[(cbase>>10)^3]=V;break;
                case 6: 
                        if (MMC3_cmd&0x40) {mapbyte2[2]=V&0x3f;ROM_BANK8MOD2(0xC000,V);}
                        else {mapbyte2[0]=V&0x3f;ROM_BANK8MOD2(0x8000,V);}
                        break;
                case 7: mapbyte2[1]=V&0x3f;
                        ROM_BANK8MOD2(0xA000,V);
                        break;
               }
               break;

        case 0xA000:
        MIRROR_SET(V&1);
        break;

        case 0xc000:IRQLatch=V;IRQlow&=~1;
                    if(resetmode==1)
                     {IRQCount=IRQLatch;}
                    break;
        case 0xc001:resetmode=1;IRQlow&=~1;
                    IRQCount=IRQLatch;
                    break;
        case 0xE000:IRQa=0;IRQlow&=~1;
                    if(resetmode==1)
                     IRQCount=IRQLatch;
                    break;
        case 0xE001:IRQa=1;IRQlow&=~1;
                    if(resetmode==1)
                     IRQCount=IRQLatch;
                    break;



 }
}

void Mapper45_init(void)
{
 int x;
 for(x=0;x<8;x++)
  mapbyte3[x]=x;
 mapbyte2[0]=0;
 mapbyte2[1]=1;
 mapbyte2[2]=pmask8-1;
 mapbyte2[3]=pmask8;

 SetWriteHandler(0x6000,0x6000,(void *)Mapper45_q);
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper45_write);
 MapHBIRQHook=(void *)MMC3_hb;
}

//M46
#define A64reg  mapbyte1[0]
#define A64wr   mapbyte1[1]

void Mapper46_writel(uint16 A, uint8 V)
{
  A64reg=V;
  ROM_BANK32(0x8000,(A64wr&1)+((A64reg&0xF)<<1));
  VROM_BANK8(((A64wr>>4)&7)+((A64reg&0xF0)>>1));
}

void Mapper46_write(uint16 A,uint8 V)
{
  A64wr=V;
  ROM_BANK32(0x8000,(V&1)+((A64reg&0xF)<<1));
  VROM_BANK8(((V>>4)&7)+((A64reg&0xF0)>>1));
}

void Mapper46_init(void)
{
 MIRROR_SET(0);
 ROM_BANK32(0x8000,0);
 SetWriteHandler(0x8000,0xffff,(void *)Mapper46_write);
 SetWriteHandler(0x6000,0x7fff,(void *)Mapper46_writel);
}

//M47
static void Map47boink(uint16 A, uint8 V)
{
 int x;
 mapbyte2[0]=V&1;
 for(x=0;x<8;x++)
  VROM_BANK1(x*1024,(CHRBankList[x]&0x7F)|(mapbyte2[0]<<7));
 for(x=0;x<4;x++)
  ROM_BANK8(0x8000+x*8192,(PRGBankList[x]&0xF)|(mapbyte2[0]<<4));
}
void Mapper47_write(uint16 A,uint8 V)
{        
        switch(A&0xE001)
        {
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {byte swa;swa=PRGBankList[0];ROM_BANK8(0x8000,PRGBankList[2]);
          ROM_BANK8(0xc000,swa);}
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            byte swa;
            swa=CHRBankList[4];
            VROM_BANK1(0x1000,CHRBankList[0]);
            VROM_BANK1(0x0000,swa);
            swa=CHRBankList[5];
            VROM_BANK1(0x1400,CHRBankList[1]);
            VROM_BANK1(0x0400,swa);
            swa=CHRBankList[6];
            VROM_BANK1(0x1800,CHRBankList[2]);
            VROM_BANK1(0x0800,swa);
            swa=CHRBankList[7];
            VROM_BANK1(0x1c00,CHRBankList[3]);
            VROM_BANK1(0x0c00,swa);
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0: V>>=1;VROM_BANK2((cbase^0x1000),(V&0x3f)|(mapbyte2[0]<<6));break;
                case 1: V>>=1;VROM_BANK2((cbase^0x1800),(V&0x3f)|(mapbyte2[0]<<6));break;
                case 2: VROM_BANK1(cbase^0x000,(V&0x7f)|(mapbyte2[0]<<7)); break;
                case 3: VROM_BANK1(cbase^0x400,(V&0x7f)|(mapbyte2[0]<<7)); break;
                case 4: VROM_BANK1(cbase^0x800,(V&0x7f)|(mapbyte2[0]<<7)); break;
                case 5: VROM_BANK1(cbase^0xC00,(V&0x7f)|(mapbyte2[0]<<7)); break;
                case 6: if (MMC3_cmd&0x40) ROM_BANK8(0xC000,(V&0xF)|(mapbyte2[0]<<4));
                        else ROM_BANK8(0x8000,(V&0xF)|(mapbyte2[0]<<4));
                        break;
                case 7: ROM_BANK8(0xA000,(V&0xF)|(mapbyte2[0]<<4));
                        break;
               }
               break;

        case 0xA000:
        MIRROR_SET(V&1);
        break;
        case 0xA001:break;
	#include "mmc3irq.h"
 }
}

void Mapper47_init(void)
{
 ROM_BANK16(0xC000,0x7);
 SetWriteHandler(0x6000,0x6000,(void *)Map47boink);
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper47_write);
 MapHBIRQHook=(void *)MMC3_hb;
}

//M49
static inline void M49PRG(void)
{
   if(mapbyte4[1]&1)
   {
    int t;
    t=mapbyte4[1]&0xC0;
    t>>=2;
    if (MMC3_cmd&0x40) 
		       {ROM_BANK8(0x8000,(pmask8&0xFE)+t);
			ROM_BANK8(0xC000,(mapbyte3[6]&0xF)+t);}
                       else 
	 {
         ROM_BANK8(0xC000,(pmask8&0xE)+t);
	 ROM_BANK8(0xe000,(pmask8&0xF)+t);
         ROM_BANK8(0x8000,(mapbyte3[6]&0xF)+t);
    	}
    ROM_BANK8(0xA000,(mapbyte3[7]&0xF)+t);
   }
  else
   ROM_BANK32(0x8000,(mapbyte4[1]>>4)&7);
}
static inline void M49CHR(void)
{
   int t;
   
   t=mapbyte4[1]&0xC0;
   t<<=1;  
   VROM_BANK2((cbase^0x1000),(mapbyte3[0]+t)>>1);
   VROM_BANK2((cbase^0x1800),(mapbyte3[1]+t)>>1);
   VROM_BANK1(cbase^0x000,mapbyte3[2]+t); 
   VROM_BANK1(cbase^0x400,mapbyte3[3]+t); 
   VROM_BANK1(cbase^0x800,mapbyte3[4]+t); 
   VROM_BANK1(cbase^0xC00,mapbyte3[5]+t);
}

void Mapper49_write(uint16 A,uint8 V)
{
        switch(A&0xE001){
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
	  M49PRG();

        if(VROM_size)
	{
 	 cbase=((V^0x80)&0x80)<<5;
         if((V&0x80) != (MMC3_cmd&0x80))
	   M49CHR();
	}
        MMC3_cmd = V;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07)
		{
		default: mapbyte3[MMC3_cmd&0x7]=V;M49CHR();break;
		case 6: case 7: mapbyte3[MMC3_cmd&0x7]=V;M49PRG();break;
                }
                break;

        case 0xA000:
        MIRROR_SET(V&1);
        break;
        case 0xA001:
		    mapbyte4[0]=V&0x80;
                    break;
	#include "mmc3irq.h"
 }
}
void M49low(uint16 A, uint8 V)
{
 if(mapbyte4[0]&0x80)
 {
  mapbyte4[1]=V;
  M49PRG();
  M49CHR();
 }
}
void Mapper49_init(void)
{
 mapbyte3[7]=1;
 M49PRG();
 M49CHR();
 SetWriteHandler(0x6000,0x7FFF,(void *)M49low);
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper49_write);
 MapHBIRQHook=(void *)MMC3_hb;
}

//M64
void Mapper64_write(uint16 A,uint8 V)
{
 switch(A&0xF003)
 {
        case 0xa000:MIRROR_SET(V&1);break;
        case 0x8000:
         MMC3_cmd = V;
         if(MMC3_cmd&0x80) cbase=0x1000;
         else cbase=0x000;
        break;
	#include "mmc3irq.h"

        case 0x8001:
                switch(MMC3_cmd&15){
                case 0: VROM_BANK1(cbase^0x0000,V);VROM_BANK1(cbase^0x0400,V+1);break;
                case 1: VROM_BANK1(cbase^0x0800,V);VROM_BANK1(cbase^0x0C00,V+1);break;
                case 2: VROM_BANK1(cbase^0x1000,V); break;
                case 3: VROM_BANK1(cbase^0x1400,V); break;
                case 4: VROM_BANK1(cbase^0x1800,V); break;
                case 5: VROM_BANK1(cbase^0x1C00,V); break;
                case 6:
                        if (MMC3_cmd&0x40) ROM_BANK8(0xa000,V);
                        else ROM_BANK8(0x8000,V);
                        break;
                case 7:
                        if (MMC3_cmd&0x40) ROM_BANK8(0xC000,V);
                        else ROM_BANK8(0xA000,V);
                        break;
                case 8: VROM_BANK1(cbase^0x0400,V);break;
                case 9: VROM_BANK1(cbase^0x0c00,V);break;
                case 15:
                        if (MMC3_cmd&0x40) ROM_BANK8(0x8000,V);
                        else ROM_BANK8(0xC000,V);
                        break;
                default: break;
               }
               break;
  }	
}

void Mapper64_init(void)
{
 MapHBIRQHook=(void *)MMC3_hb;
 SetWriteHandler(0x8000,0xffff,(void *)Mapper64_write);
}

//M65
void IREMIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount-=a;
   if(IRQCount<=0-4)
   {
    TriggerIRQ();
    IRQa=0;
    IRQCount=0xFFFF;
   }
  }
}

void Mapper65_write(uint16 A,uint8 V)
{
switch(A)
{
case 0x8000:ROM_BANK8(0x8000,V);break;
case 0x9000:MIRROR_SET2((V>>6)&1);break;
case 0x9003:IRQa=V&0x80;break;
case 0x9004:IRQCount=IRQLatch;break;
case 0x9005:          IRQLatch&=0x00FF;
                      IRQLatch|=V<<8;
                      break;
case 0x9006:          IRQLatch&=0xFF00;IRQLatch|=V;
                      break;
case 0xB000:VROM_BANK1(0x0000,V);break;
case 0xB001:VROM_BANK1(0x0400,V);break;
case 0xB002:VROM_BANK1(0x0800,V);break;
case 0xB003:VROM_BANK1(0x0C00,V);break;
case 0xB004:VROM_BANK1(0x1000,V);break;
case 0xB005:VROM_BANK1(0x1400,V);break;
case 0xB006:VROM_BANK1(0x1800,V);break;
case 0xB007:VROM_BANK1(0x1C00,V);break;
case 0xa000:ROM_BANK8(0xA000,V);break;
case 0xC000:ROM_BANK8(0xC000,V);break;
 }
}

void Mapper65_init(void)
{
 MapIRQHook=(void *)IREMIRQHook;
 SetWriteHandler(0x8000,0xffff,(void *)Mapper65_write);
}

//M66
void Mapper66_write(uint16 A,uint8 V)
{
 VROM_BANK8(V&0xF);
 ROM_BANK32(0x8000,(V>>4));
}

void Mapper66_init(void)
{
 ROM_BANK32(0x8000,0);
 SetWriteHandler(0x6000,0xffff,(void *)Mapper66_write);
}

//M67
#define suntoggle mapbyte1[0]

void Mapper67_write(uint16 A,uint8 V)
{
switch(A&0xF800)
 {
//case 0x8000:V&=vmask1;VROM_BANK1(0x000,(V));break;
case 0x8800:VROM_BANK1(0x000,(V<<1));VROM_BANK1(0x400,(V<<1)+1);break;
case 0x9800:VROM_BANK1(0x800,(V<<1));VROM_BANK1(0xc00,(V<<1)+1);break;
case 0xa800:VROM_BANK1(0x1000,(V<<1));VROM_BANK1(0x1400,(V<<1)+1);break;
case 0xb800:VROM_BANK1(0x1800,(V<<1));VROM_BANK1(0x1c00,(V<<1)+1);break;
case 0xc800:
case 0xc000:if(!suntoggle)
            {IRQCount&=0xFF;IRQCount|=V<<8;}
            else{IRQCount&=0xFF00;IRQCount|=V;}
            suntoggle^=1;
            break;
case 0xd800:suntoggle=0;IRQa=V&0x10;break;

case 0xe800:    switch(V&3)
                {
                case 0:MIRROR_SET2(1);break;
                case 1:MIRROR_SET2(0);break;
                case 2:onemir(0);break;
                case 3:onemir(2);break;
                }
                break;
case 0xf800:V&=pmask16;ROM_BANK16(0x8000,V);break;
 }
}
static void SunIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount-=a;
   if(IRQCount<=0)
   {TriggerIRQ();IRQa=0;IRQCount=0xFFFF;}
  }
}
void Mapper67_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper67_write);
MapIRQHook=(void *)SunIRQHook;
}

//M68
#define boogaa mapbyte1[0]
#define boogaa2 mapbyte1[1]

void Mapper68_write(uint16 A,uint8 V)
{
switch(A&0xF000)
 {

 case 0x8000: VROM_BANK2(0x0000,V);break;
 case 0x9000: VROM_BANK2(0x0800,V);break;
 case 0xA000: VROM_BANK2(0x1000,V);break;
 case 0xB000: VROM_BANK2(0x1800,V);break;
 case 0xc000:
              if(VROM_size)
              {
              V|=128;
              V&=vmask1;
              vnapage[0]=VROM+(V<<10);
              VPAL2[0]=V|0x8800;
              boogaa=V;
              }
              break;
 case 0xd000:
              if(VROM_size)
              {
              V|=128;
              V&=vmask1;
              vnapage[2]=VROM+(V<<10);
              VPAL2[2]=V|0x8800;
              }
              boogaa2=V;
              break;

 case 0xe000:
              if(!(V&0x10))
              {
               switch(V&3)
                {
                case 0:MIRROR_SET2(1);break;
                case 1:MIRROR_SET2(0);break;
                case 2:onemir(0);break;
                case 3:onemir(2);break;
                }

              }
              else if(VROM_size)
              {
                vnapage[0]=VROM+(boogaa<<10);
                vnapage[1]=VROM+(boogaa2<<10);
                vnapage[2]=VROM+(boogaa2<<10);
                vnapage[3]=VROM+(boogaa<<10);
                VPAL2[0]=boogaa|0x8800;
                VPAL2[1]=boogaa2|0x8800;
                VPAL2[2]=boogaa2|0x8800;
                VPAL2[3]=boogaa|0x8800;
              }
              break;
 case 0xf000: ROM_BANK16(0x8000,V);break;
 }
}

void Mapper68_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper68_write);
}

//M69
#define sunselect mapbyte1[0]
#define sungah    mapbyte1[1]
#define sunindex  mapbyte1[2]

static int32 inc;
void SUN5BWRAM(register word A, register byte V)
{
Page[3][A]=V;
}

byte SUN5AWRAM(register word A)
{
if(sungah&0x40 && (!(sungah&0x80)))
 return 0xAF;                   // I *should* return what's on the bus,
                                // since $6000-$7fff is in an open bus state
 return Page[A>>13][A];
}


void Mapper69_write(uint16 A,uint8 V)
{
switch(A&0xE000)
 {
 case 0xC000:sunindex=V%14;break;
 case 0xE000:MapExpSound=(void *)AYSound;
             if(sunindex==0xD)
             {
              byte tab[16]={15,15,15,15,0,0,0,0,15,15,15,15,0,0,0,0};
              MapperExRAM[0x20]=tab[V&15];
             }
             else if(sunindex==0x6) znreg=0xFFFF;
             MapperExRAM[sunindex]=V;
             break;
 case 0x8000:sunselect=V;break;
 case 0xa000:
             switch(sunselect&0x0f)
             {
             case 0:VROM_BANK1(0x000,V);break;
             case 1:VROM_BANK1(0x400,V);break;
             case 2:VROM_BANK1(0x800,V);break;
             case 3:VROM_BANK1(0xc00,V);break;
             case 4:VROM_BANK1(0x1000,V);break;
             case 5:VROM_BANK1(0x1400,V);break;
             case 6:VROM_BANK1(0x1800,V);break;
             case 7:VROM_BANK1(0x1c00,V);break;
             case 8:
                        sungah=V;
                        if(V&0x40)
                        {
                         if(V&0x80) // Select WRAM
                         {
                          Page[3]=WRAM-0x6000;
                         }
                         else       //
                         {
                          Page[3]=nothing-0x6000;
                         }
                        }
                        else ROM_BANK8(0x6000,V);break;
             case 9:ROM_BANK8(0x8000,V);break;
             case 0xa:ROM_BANK8(0xa000,V);break;
             case 0xb:ROM_BANK8(0xc000,V);break;
             case 0xc:
                    switch(V&3)
                    {
                    case 0:MIRROR_SET2(1);break;
                    case 1:MIRROR_SET2(0);break;
                    case 2:onemir(0);break;
                    case 3:onemir(2);break;
                    }
             break;
             case 0xd:IRQa=V;break;
             case 0xe:IRQCount&=0xFF00;IRQCount|=V;break;
             case 0xf:IRQCount&=0x00FF;IRQCount|=V<<8;break;
             }
             break;
 }
}

int AYSound(int32 *Wave)
{
    int x,V;
    uint32 freq;
    unsigned char amp;

    for(x=0;x<3;x++)
    {
     if(!(MapperExRAM[0x7]&(1<<x)))
     {
      long vcoo;

      freq=(MapperExRAM[x<<1]|((MapperExRAM[(x<<1)+1]&15)<<8))+1;
      inc=(long double)((unsigned long)((SndRate OVERSAMPLE)<<12))/
        ((long double)PSG_base/freq);
      if(MapperExRAM[0x8+x]&0x10) amp=MapperExRAM[0x20]&15;
                           else   amp=MapperExRAM[0x8+x]&15;
              amp-=amp>>1;
              vcoo=vcount[x];
             if(amp)
              for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
               {
                if(vcoo>=inc>>1)
                  Wave[V>>4]-=amp;
                else
                  Wave[V>>4]+=amp;
                vcoo+=0x1000;
                if(vcoo>=inc) vcoo-=inc;
                }
              vcount[x]=vcoo;
     }
    }

        amp=0;
        for(V=0;V<3;V++)
         {
          if(!(MapperExRAM[0x7]&(8<<V)))
          { if(MapperExRAM[0x8+V]&0x10) amp+=MapperExRAM[0x20]&15;
                                else  amp+=MapperExRAM[0x8+V]&15;
          }
         }
     amp-=amp>>1;
     if(amp)
       {
        freq=PSG_base/(MapperExRAM[0x6]+1);
        if(freq>44100)
         inc=((freq<<11)/(SndRate OVERSAMPLE))<<4;
        else
         inc=(freq<<15)/(SndRate OVERSAMPLE);

         for(V=0;V<SND_BUFSIZE OVERSAMPLE;V++)
          {
             static int mixer;

             if(vcount[3]>=32768)
             {
               unsigned char feedback;
               mixer=0;
               if(znreg&1) mixer+=amp;
               else mixer-=amp;
               feedback=((znreg>>13)&1)^((znreg>>14)&1);
               znreg=(znreg<<1)+(feedback);
               vcount[3]-=32768;
             }
             Wave[V>>4]+=mixer;
             vcount[3]+=inc;
           }
       }
        #ifdef moo
        vcount[4]+=cycles_per_update;
        if(vcount[4]>=((MapperExRAM[0xC]|(MapperExRAM[0xB]<<8))<<8))
        {
        vcount[4]-=(MapperExRAM[0xC]|(MapperExRAM[0xB]<<8))<<8;
        }
        #endif

 return 0;
}
/*
static void SunIRQHook(int a)
{
  if(IRQa)
  {
   IRQCount-=a;
   if(IRQCount<=0)
   {TriggerIRQ();IRQa=0;IRQCount=0xFFFF;}
  }
}
*/
void Mapper69_StateRestore(int version)
{
   if(version>=19)
   {
     if(mapbyte1[1]&0x40)
     {
     if(mapbyte1[1]&0x80) // Select WRAM
      Page[3]=WRAM-0x6000;
     else       //
      Page[3]=nothing-0x6000;
     }
    else ROM_BANK8(0x6000,(mapbyte1[1]&pmask8));
   }
   else
    mapbyte1[1]=0xC0;
}

void Mapper69_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper69_write);
SetWriteHandler(0x6000,0x7fff,(void *)SUN5BWRAM);
SetReadHandler(0x6000,0x7fff,(void *)SUN5AWRAM);
MapIRQHook=(void *)SunIRQHook;
MapStateRestore=(void *)Mapper69_StateRestore;
}

//M70
void Mapper70_write(uint16 A,uint8 V)
{
ROM_BANK16(0x8000,V>>4);
VROM_BANK8(V&0xF);
MIRROR_SET((V>>3)&1);
}

void Mapper70_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper70_write);

}

//M71
void Mapper71_write(uint16 A,uint8 V)
{
switch(A&0xF000)
 {
 case 0xF000:
 case 0xE000:
 case 0xD000:
 case 0xC000:ROM_BANK16(0x8000,V);break;
 case 0x9000:onemir((V>>3)&2);break;
 }
}

void Mapper71_init(void)
{
SetWriteHandler(0x4020,0xffff,(void *)Mapper71_write);
}

//M73
void Mapper73_write(uint16 A,uint8 V)
{
switch(A&0xF000)
 {
 case 0x8000:IRQCount&=0xFFF0;IRQCount|=(V&0xF);break;
 case 0x9000:IRQCount&=0xFF0F;IRQCount|=(V&0xF)<<4;break;
 case 0xa000:IRQCount&=0xF0FF;IRQCount|=(V&0xF)<<8;break;
 case 0xb000:IRQCount&=0x0FFF;IRQCount|=(V&0xF)<<12;break;
 case 0xc000:IRQa=V&2;break;
 case 0xf000:ROM_BANK16(0x8000,V);break;
 }
}
static void Mapper73_hb(void)
{
 if(IRQa)
 {
        if(IRQCount>=0xFFFF)
                {
                IRQCount&=0xFFFF;
                IRQa=0;
                TriggerIRQ();
                }
                else
                 IRQCount+=(M.IPeriod+85)/3;
 }
}

void Mapper73_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper73_write);
MapHBIRQHook=(void *)Mapper73_hb;
}

//M75
#define map75sel mapbyte1[0]
#define map75ar  mapbyte2

void Mapper75_write(uint16 A,uint8 V)
{
switch(A&0xF000)
 {
 case 0x8000:ROM_BANK8(0x8000,V);break;
 case 0x9000:
             VROM_BANK4(0x0000,map75ar[0]|((V&2)<<3));
             VROM_BANK4(0x1000,map75ar[1]|((V&4)<<2));
             map75sel=V;MIRROR_SET(V&1);break;
 case 0xa000:ROM_BANK8(0xa000,V);break;
 case 0xc000:ROM_BANK8(0xc000,V);break;
 case 0xe000:V&=0xF;map75ar[0]=V;V|=(map75sel&2)<<3;VROM_BANK4(0x0000,V);break;
 case 0xf000:V&=0xF;map75ar[1]=V;V|=(map75sel&4)<<2;VROM_BANK4(0x1000,V);break;
 }
}

void Mapper75_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper75_write);
}

//M76
void Mapper76_write(uint16 A,uint8 V)
{
        switch(A&0xE001){
        case 0x8000:
         MMC3_cmd = V;
         break;
        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 2: VROM_BANK2(0x000,V);break;
                case 3: VROM_BANK2(0x800,V);break;
                case 4: VROM_BANK2(0x1000,V);break;
                case 5: VROM_BANK2(0x1800,V);break;
                case 6:
                        if (MMC3_cmd&0x40) ROM_BANK8(0xC000,V);
                        else ROM_BANK8(0x8000,V);
                        break;
                case 7: ROM_BANK8(0xA000,V);
                        break;
               }
               break;
        case 0xA000:
        MIRROR_SET(V&1);
        break;
 }
}

void Mapper76_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper76_write);
}

//M78
void Mapper78_write(uint16 A,uint8 V)
{
ROM_BANK16(0x8000,V);
VROM_BANK8(V>>4);
}

void Mapper78_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper78_write);
}

//M79
void Mapper79_write(uint16 A,uint8 V)
{
 if(A<0x8000 && ((A^0x4100)==0))
 {
 ROM_BANK32(0x8000,(V>>3)&1);
 }
VROM_BANK8(V);
}

void Mapper79_init(void)
{
SetWriteHandler(0x8000,0xffff,(void *)Mapper79_write);
SetWriteHandler(0x4020,0x5fff,(void *)Mapper79_write);
}

//M80
void Mapper80_write(uint16 A,uint8 V)
{
switch(A)
 {
  case 0x7ef0: VROM_BANK1(0x000,V);VROM_BANK1(0x400,(V+1));break;
  case 0x7ef1: VROM_BANK1(0x800,V);VROM_BANK1(0xC00,(V+1));break;

  case 0x7ef2: VROM_BANK1(0x1000,V);break;
  case 0x7ef3: VROM_BANK1(0x1400,V);break;
  case 0x7ef4: VROM_BANK1(0x1800,V);break;
  case 0x7ef5: VROM_BANK1(0x1c00,V);break;
  case 0x7efa:
  case 0x7efb: ROM_BANK8(0x8000,V);break;
  case 0x7efd:
  case 0x7efc: ROM_BANK8(0xA000,V);break;
  case 0x7efe:
  case 0x7eff: ROM_BANK8(0xC000,V);break;
 }
}

void Mapper80_init(void)
{
SetWriteHandler(0x4020,0x7fff,(void *)Mapper80_write);
}


//M87
void Mapper87_write(uint16 A,uint8 V)
{
VROM_BANK8(V>>1);
}

void Mapper87_init(void)
{
  SetWriteHandler(0x6000,0xffff,(void *)Mapper87_write);
}

//M90
#define tkcom1 mapbyte1[1]
#define tkcom2 mapbyte1[2]

#define tklist1 mapbyte2
#define tklist2 mapbyte3
#define tklist3 mapbyte4

byte tekker=0x80;

byte tekread(word A)
{
 return tekker;
}
static void tekprom(void)
{
 switch(tkcom1&3)
  {
   case 1:              // 16 KB
          ROM_BANK16(0x8000,tklist1[0]);
          ROM_BANK16(0xC000,tklist1[2]);
          break;

   case 2:              //2 = 8 KB ??
   case 3:
          ROM_BANK8(0x8000,tklist1[0]);
          ROM_BANK8(0xa000,tklist1[1]);
          ROM_BANK8(0xc000,tklist1[2]);
          ROM_BANK8(0xe000,tklist1[3]);
          break;
  }
}
static void tekvrom(void)
{
 switch(tkcom1&0x18)
  {
   case 0x00:      // 8KB
           VROM_BANK8((tklist1[4]|(tklist2[4]<<8)));
   break;
   case 0x08:      // 4KB
          VROM_BANK4(0x0000,(tklist1[4]|(tklist2[4]<<8)));
          VROM_BANK4(0x1000,(tklist2[0]|(tklist3[0]<<8)));
   break;
   case 0x10:      // 2KB
          VROM_BANK2(0x0000,(tklist1[4]|(tklist2[4]<<8)));
          VROM_BANK2(0x0800,(tklist1[6]|(tklist2[6]<<8)));
          VROM_BANK2(0x1000,(tklist2[0]|(tklist3[0]<<8)));
          VROM_BANK2(0x0800,(tklist2[2]|(tklist3[2]<<8)));
   break;
   case 0x18:      // 1KB
           VROM_BANK1(0x0000,(tklist1[4]|(tklist2[4]<<8)));
           VROM_BANK1(0x0400,(tklist1[5]|(tklist2[5]<<8)));
           VROM_BANK1(0x0800,(tklist1[6]|(tklist2[6]<<8)));
           VROM_BANK1(0x0c00,(tklist1[7]|(tklist2[7]<<8)));
           VROM_BANK1(0x1000,(tklist2[0]|(tklist3[0]<<8)));
           VROM_BANK1(0x1400,(tklist2[1]|(tklist3[1]<<8)));
           VROM_BANK1(0x1800,(tklist2[2]|(tklist3[2]<<8)));
           VROM_BANK1(0x1c00,(tklist2[3]|(tklist3[3]<<8)));
   break;
 }
}

void Mapper90_write(uint16 A,uint8 V)
{
switch(A&0xF007)
 {
   case 0x8000:tklist1[0]=V;tekprom();break;
   case 0x8001:tklist1[1]=V;tekprom();break;
   case 0x8002:tklist1[2]=V;tekprom();break;
   case 0x8003:tklist1[3]=V;tekprom();break;
   case 0x9000:tklist1[4]=V;tekvrom();break;
   case 0x9001:tklist1[5]=V;tekvrom();break;
   case 0x9002:tklist1[6]=V;tekvrom();break;
   case 0x9003:tklist1[7]=V;tekvrom();break;
   case 0x9004:tklist2[0]=V;tekvrom();break;
   case 0x9005:tklist2[1]=V;tekvrom();break;
   case 0x9006:tklist2[2]=V;tekvrom();break;
   case 0x9007:tklist2[3]=V;tekvrom();break;
   case 0xa000:tklist2[4]=V;tekvrom();break;
   case 0xa001:tklist2[5]=V;tekvrom();break;
   case 0xa002:tklist2[6]=V;tekvrom();break;
   case 0xa003:tklist2[7]=V;tekvrom();break;
   case 0xa004:tklist3[0]=V;tekvrom();break;
   case 0xa005:tklist3[1]=V;tekvrom();break;
   case 0xa006:tklist3[2]=V;tekvrom();break;
   case 0xa007:tklist3[3]=V;tekvrom();break;
   case 0xb000:tklist3[4]=V;break;
   case 0xb001:tklist3[5]=V;break;
   case 0xb002:tklist3[6]=V;break;
   case 0xb003:tklist3[7]=V;break;
   case 0xc004:
   case 0xc000:IRQLatch=V;break;

   case 0xc005:
   case 0xc001:IRQlow&=~1;
               IRQCount=V;break;
   case 0xc006:
   case 0xc002:IRQlow&=~1;
               IRQa=0;
               IRQCount=IRQLatch;
               break;
   case 0xc007:
   case 0xc003:IRQa=1;break;

   case 0xd000:tkcom1=V;break;
   case 0xd001:switch(V&3){
                  case 0x00:MIRROR_SET2(1);break;
                  case 0x01:MIRROR_SET2(0);break;
                  case 0x02:onemir(0);break;
                  case 0x03:onemir(2);break;
               }
	       break;
   break;
 }
}
static void Mapper90_hb(void)
{
 if(IRQa)
 {
        if(scanline<241 && (SpriteON || ScreenON) && IRQCount) 
	{
	 IRQCount--;
         if(!IRQCount)
          {
	  IRQlow|=1;
          IRQCount=IRQLatch;
          }
        }
 }
}

void Mapper90_init(void)
{
  tekker^=0x80;
  SetWriteHandler(0x8000,0xffff,(void *)Mapper90_write);
  SetReadHandler(0x5000,0x5000,(void *)tekread);
  MapHBIRQHook=(void *)Mapper90_hb;
}

//M93
void Mapper93_write(uint16 A,uint8 V)
{
ROM_BANK16(0x8000,V>>4);
MIRROR_SET(V&1);
}

void Mapper93_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper93_write);
}

//M94
void Mapper94_write(uint16 A,uint8 V)
{
ROM_BANK16(0x8000,V>>2);
}

void Mapper94_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper94_write);
}

//M95
#define dbarray mapbyte1
void dragonbust_ppu(uint32 A)
{
 static int last=-1;
 static byte z;
 A>>=13;

 z=dbarray[A];

 if(z!=last)
 {
  onemir(z);
  last=z;
 }
}


void Mapper95_write(uint16 A,uint8 V)
{
        switch(A&0xF001){

        case 0x8000:
        MMC3_cmd = V;
        break;

        case 0x8001:
                switch(MMC3_cmd&7){
                case 0: dbarray[0]=dbarray[1]=(V&0x20)>>4;onemir((V&0x20)>>4);V>>=1;VROM_BANK2(0x0000,V);break;
                case 1: dbarray[2]=dbarray[3]=(V&0x20)>>4;onemir((V&0x20)>>4);V>>=1;V&=vmask2;VROM_BANK2(0x0800,V);break;
                case 2: dbarray[4]=(V&0x20)>>4;onemir((V&0x20)>>4);VROM_BANK1(0x1000,V); break;
                case 3: dbarray[5]=(V&0x20)>>4;onemir((V&0x20)>>4);VROM_BANK1(0x1400,V); break;
                case 4: dbarray[6]=(V&0x20)>>4;onemir((V&0x20)>>4);VROM_BANK1(0x1800,V); break;
                case 5: dbarray[7]=(V&0x20)>>4;onemir((V&0x20)>>4);VROM_BANK1(0x1C00,V); break;
                case 6:
                        ROM_BANK8(0x8000,V);
                        break;
                case 7:
                        ROM_BANK8(0xA000,V);
                        break;
                }
                break;
}
}

void Mapper95_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper95_write);
  PPU_hook=(void *)dragonbust_ppu;
}

//M96
void Mapper96_write(uint16 A,uint8 V)
{
ROM_BANK32(0x8000,V);
}

void Mapper96_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper96_write);
}

//M97
void Mapper97_write(uint16 A,uint8 V)
{
ROM_BANK16(0xC000,V&15);
switch(V>>6)
 {
 case 0:break;
 case 1:MIRROR_SET2(0);break;
 case 2:MIRROR_SET2(1);break;
 case 3:break;
 }
}

void Mapper97_init(void)
{
  ROM_BANK16(0x8000,pmask16);
  SetWriteHandler(0x8000,0xffff,(void *)Mapper97_write);
}

//M99
static void (*oldmorko)(uint16 A, uint8 V);
static void morko(uint16 A, uint8 V)
{
 VROM_BANK8((V>>2)&1);
 oldmorko(A,V);
}

void Mapper99_init(void)
{
 oldmorko=(void *)GetWriteHandler(0x4016);
 SetWriteHandler(0x4016,0x4016,(void *)morko);
}

//M112
void Mapper112_write(uint16 A,uint8 V)
{
switch(A)
{
 case 0xe000:MIRROR_SET(V&1);break;
 case 0x8000:mapbyte1[0]=V;break;
 case 0xa000:switch(mapbyte1[0])
            {
            case 0:ROM_BANK8(0x8000,V);break;
            case 1:ROM_BANK8(0xA000,V);break;
                case 2: V&=0xFE;VROM_BANK1(0,V);
                        VROM_BANK1(0x400,(V+1));break;
                case 3: V&=0xFE;VROM_BANK1(0x800,V);
                        VROM_BANK1(0xC00,(V+1));break;
            case 4:VROM_BANK1(0x1000,V);break;
            case 5:VROM_BANK1(0x1400,V);break;
            case 6:VROM_BANK1(0x1800,V);break;
            case 7:VROM_BANK1(0x1c00,V);break;
            }
            break;
 }
}

void Mapper112_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper112_write);
}

//M113
/*      I'm getting the feeling this is another "jam two different bank
        switching hardwares into one mapper".
*/        

/* HES 4-in-1 */
void Mapper113_write(uint16 A,uint8 V)
{
        ROM_BANK32(0x8000,(V>>3)&7);
        VROM_BANK8(V&7);
}

      
/*      Deathbots */
void Mapper113_writeh(uint16 A,uint8 V)
{
        ROM_BANK32(0x8000,V&0xF);
}


void Mapper113_init(void)
{
 ROM_BANK32(0x8000,0);
 SetWriteHandler(0x4020,0x7fff,(void *)Mapper113_write);
 SetWriteHandler(0x8000,0xffff,(void *)Mapper113_writeh);
}

//M117
void Mapper117_write(uint16 A,uint8 V)
{
 switch(A)
 {
  case 0xc003:IRQCount=V;break;
  case 0xc001:IRQa=V;break;
  case 0xa000:VROM_BANK1(0x0000,V);break;
  case 0xa001:VROM_BANK1(0x0400,V);break;
  case 0xa002:VROM_BANK1(0x0800,V);break;
  case 0xa003:VROM_BANK1(0x0c00,V);break;
  case 0xa004:VROM_BANK1(0x1000,V);break;
  case 0xa005:VROM_BANK1(0x1400,V);break;
  case 0xa006:VROM_BANK1(0x1800,V);break;
  case 0xa007:VROM_BANK1(0x1c00,V);break;
  case 0x8000:ROM_BANK8(0x8000,V);break;
  case 0x8001:ROM_BANK8(0xa000,V);break;
  case 0x8002:ROM_BANK8(0xc000,V);break;
  case 0x8003:ROM_BANK8(0xe000,V);break;
 }
}

static void Mapper117_hb(void)
{
 if(IRQa)
 {
        if(IRQCount<=0)
        {
         IRQa=0;
         TriggerIRQ();
        }
        else
        {
         if(scanline<240 && (ScreenON || SpriteON)) IRQCount--;
        }
 }
}

void Mapper117_init(void)
{
  MapHBIRQHook=(void *)Mapper117_hb;
  SetWriteHandler(0x8000,0xffff,(void *)Mapper117_write);
}

//M118
#define TKSMIR mapbyte3
#define PPUCHRBus mapbyte2[0]
static void TKSPPU(uint32 A)
{
 static int last=-1;
 static byte z;

 A>>=13;
 PPUCHRBus=A;
 z=TKSMIR[A];

 if(z!=last)
 {
 // tksmir(z);
 //MIRROR_SET(z>>1);
  onemir(z);
  last=z;
 }
}

static inline void tksmir(byte v)
{
onemir(TKSMIR[PPUCHRBus]);
}


void Mapper118_write(uint16 A,uint8 V)
{
        switch(A&0xE001){

        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {byte swa;swa=PRGBankList[0];ROM_BANK8(0x8000,PRGBankList[2]);
          ROM_BANK8(0xc000,swa);}
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            byte swa;
            swa=CHRBankList[4];
            VROM_BANK1(0x1000,CHRBankList[0]);
            VROM_BANK1(0x0000,swa);
            swa=TKSMIR[4];
            TKSMIR[4]=TKSMIR[0];
            TKSMIR[0]=swa;

            swa=CHRBankList[5];
            VROM_BANK1(0x1400,CHRBankList[1]);
            VROM_BANK1(0x0400,swa);
            swa=TKSMIR[5];
            TKSMIR[1]=TKSMIR[1];
            TKSMIR[1]=swa;

            swa=CHRBankList[6];
            VROM_BANK1(0x1800,CHRBankList[2]);
            VROM_BANK1(0x0800,swa);
            swa=TKSMIR[6];
            TKSMIR[6]=TKSMIR[2];
            TKSMIR[2]=swa;

            swa=CHRBankList[7];
            VROM_BANK1(0x1c00,CHRBankList[3]);
            VROM_BANK1(0x0c00,swa);
            swa=TKSMIR[7];
            TKSMIR[7]=TKSMIR[3];
            TKSMIR[3]=swa;
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0:TKSMIR[(cbase>>10)^4]=TKSMIR[(cbase>>10)^5]=(V&0x80)>>6;tksmir((V&0x80)>>6);V&=0xFE;VROM_BANK1(cbase^0x1000,V);VROM_BANK1(cbase^0x1400,(V+1));break;
                case 1:TKSMIR[(cbase>>10)^6]=TKSMIR[(cbase>>10)^7]=(V&0x80)>>6;tksmir((V&0x80)>>6);V&=0xFE;VROM_BANK1(cbase^0x1800,V);VROM_BANK1(cbase^0x1C00,(V+1));break;
                case 2:TKSMIR[(cbase>>10)]=(V&0x80)>>6;tksmir((V&0x80)>>6);VROM_BANK1(cbase^0x000,V); break;
                case 3:TKSMIR[(cbase>>10)^0x1]=(V&0x80)>>6;tksmir((V&0x80)>>6);VROM_BANK1(cbase^0x400,V); break;
                case 4:TKSMIR[(cbase>>10)^0x2]=(V&0x80)>>6;tksmir((V&0x80)>>6);VROM_BANK1(cbase^0x800,V); break;
                case 5:TKSMIR[(cbase>>10)^0x3]=(V&0x80)>>6;tksmir((V&0x80)>>6);VROM_BANK1(cbase^0xC00,V); break;
                case 6:
                        if (MMC3_cmd&0x40) ROM_BANK8(0xC000,V);
                        else ROM_BANK8(0x8000,V);
                        break;
                case 7: ROM_BANK8(0xA000,V);
                        break;
               }
               break;
	#include "mmc3irq.h"
 }
}

void Mapper118_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper118_write);
  MapHBIRQHook=(void *)MMC3_hb;
  PPU_hook=(void *)TKSPPU;
}

//M119
void Mapper119_write(uint16 A,uint8 V)
{
	        switch(A&0xE001){
        case 0x8000:
         if((V&0x40) != (MMC3_cmd&0x40))
         {
            byte swa;
            swa=PRGBankList[0];
            ROM_BANK8(0x8000,PRGBankList[2]);
            ROM_BANK8(0xc000,swa);
         }
        if(VROM_size)
         if((V&0x80) != (MMC3_cmd&0x80))
         {
            byte swa,swa2,x;
            for(x=0;x<4;x++)
            {
             swa=CHRBankList[4+x];
             swa2=VPAL[4+x];
             if(VPAL[x])
              {VRAM_BANK1(0x1000,CHRBankList[x]&7);}
             else
              {VROM_BANK1(0x1000,CHRBankList[x]&vmask1);}
             if(swa2)
              {VRAM_BANK1(0x0000,swa&7);}
             else
              {VROM_BANK1(0x0000,swa&vmask1);}
            }
         }
        MMC3_cmd = V;
        cbase=((V^0x80)&0x80)<<5;
        break;

        case 0x8001:
                switch(MMC3_cmd&0x07){
                case 0: V&=0xFE;
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0x1000,V);VRAM_BANK1(cbase^0x1400,(V+1));}
                        else
                         {VROM_BANK1(cbase^0x1000,V);VROM_BANK1(cbase^0x1400,(V+1));}
                        break;
                case 1: V&=0xFE;
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0x1800,V);VRAM_BANK1(cbase^0x1C00,(V+1));}
                        else
                         {VROM_BANK1(cbase^0x1800,V);VROM_BANK1(cbase^0x1C00,(V+1));}
                        break;
                case 2:
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0x000,V);}
                        else
                         {VROM_BANK1(cbase^0x000,V);}
                        break;
                case 3:
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0x400,V);}
                        else
                         {VROM_BANK1(cbase^0x400,V);}
                        break;
                case 4:
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0x800,V);}
                        else
                         {VROM_BANK1(cbase^0x800,V);}
                        break;
                case 5:
                        if(V&0x40)
                         {V&=7;VRAM_BANK1(cbase^0xc00,V);}
                        else
                         {VROM_BANK1(cbase^0xc00,V);}
                        break;
                case 6:
                        if (MMC3_cmd&0x40) ROM_BANK8(0xC000,V);
                        else ROM_BANK8(0x8000,V);
                        break;
                case 7: ROM_BANK8(0xA000,V);
                        break;
               }
               break;
        case 0xA000:
                MIRROR_SET(V&1);
                break;
	#include "mmc3irq.h"
 }
}

void Mapper119_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper119_write);
  MapHBIRQHook=(void *)MMC3_hb;
}

//M151
void Mapper151_write(uint16 A,uint8 V)
{
switch(A&0xF000)
 {
 case 0x8000:ROM_BANK8(0x8000,V);break;
 case 0xA000:ROM_BANK8(0xA000,V);break;
 case 0xC000:ROM_BANK8(0xC000,V);break;
 case 0xe000:VROM_BANK4(0x000,V);break;
 case 0xf000:VROM_BANK4(0x1000,V);break;
 }
}

void Mapper151_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper151_write);
}

//M180
void Mapper180_write(uint16 A,uint8 V)
{
ROM_BANK16(0xC000,V);
}

void Mapper180_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper180_write);
}

//M182
void Mapper182_write(uint16 A,uint8 V)
{
  switch(A&0xf003)
  {
   case 0xe003:IRQCount=V;IRQa=1;break;
   case 0x8001:MIRROR_SET(V&1);break;
   case 0xA000:mapbyte1[0]=V;break;
   case 0xC000:
               switch(mapbyte1[0]&7)
               {
                case 0:VROM_BANK2(0x0000,V>>1);break;
                case 1:VROM_BANK1(0x1400,V);break;
                case 2:VROM_BANK2(0x0800,V>>1);break;
                case 3:VROM_BANK1(0x1c00,V);break;
                case 4:ROM_BANK8(0x8000,V);break;
                case 5:ROM_BANK8(0xA000,V);break;
                case 6:VROM_BANK1(0x1000,V);break;
                case 7:VROM_BANK1(0x1800,V);break;
               }
               break;


  }
}

void blop(void)
{
 if(scanline<241 && (ScreenON || SpriteON) && IRQa)
  {
   if(IRQCount)
   {
    IRQCount--;
    if(!IRQCount)
    {
     IRQa=0;
     TriggerIRQ();
    }
   }
  }
}
void Mapper182_init(void)
{
 SetWriteHandler(0x8000,0xFFFF,(void *)Mapper182_write);
 MapHBIRQHook=(void *)blop;
}

//M184
void Mapper184_write(uint16 A,uint8 V)
{
VROM_BANK4(0x0000,V);
VROM_BANK4(0x1000,(V>>4));
}

void Mapper184_init(void)
{
  SetWriteHandler(0x6000,0xffff,(void *)Mapper184_write);
}

//M225
#define reg1 mapbyte1[0]
#define reg2 mapbyte1[1]
#define reg3 mapbyte1[2]
#define reg4 mapbyte1[3]

byte A110in1read(word A)
{
switch(A&0x3)
 {
  case 0:return reg1;break;
  case 1:return reg2;break;
  case 2:return reg3;break;
  case 3:return reg4;break;
 }
return 0xF;
}
void A110in1regwr(word A, byte V)
{
switch(A&0x3)
 {
  case 0:reg1=V&0xF;break;
  case 1:reg2=V&0xF;break;
  case 2:reg3=V&0xF;break;
  case 3:reg4=V&0xF;break;
 }
}

void Mapper225_write(uint16 A,uint8 V)
{
 int banks=0;

 MIRROR_SET((A>>13)&1);
 if(A&0x4000)
  banks=1;
 else
  banks=0;

  VROM_BANK8(((A&0x003f)+(banks<<6)));
 if(A&0x1000)
  {
   if(A&0x40)
    {
     ROM_BANK16(0x8000,((((((A>>7)&0x1F)+(banks<<5)))<<1)+1));
     ROM_BANK16(0xC000,((((((A>>7)&0x1F)+(banks<<5)))<<1)+1));
    }
    else
    {
     ROM_BANK16(0x8000,(((((A>>7)&0x1F)+(banks<<5)))<<1));
     ROM_BANK16(0xC000,(((((A>>7)&0x1F)+(banks<<5)))<<1));
    }
  }
  else
  {
    ROM_BANK32(0x8000,((((A>>7)&0x1F)+(banks<<5))));
  }
}

void Mapper225_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper225_write);
  SetReadHandler(0x5800,0x5fff,(void *)A110in1read);
  SetWriteHandler(0x5800,0x5fff,(void *)A110in1regwr);
}

//M226
void Mapper226_write(uint16 A,uint8 V)
{
 MIRROR_SET((A>>13)&1);
 VROM_BANK8(A&0x7F);
 if(A&0x1000)
  {
   if(A&0x40)
    {
     ROM_BANK16(0x8000,(((A>>7))<<1)+1);
     ROM_BANK16(0xC000,(((A>>7))<<1)+1);
    }
    else
    {
     ROM_BANK16(0x8000,(((A>>7))<<1));
     ROM_BANK16(0xC000,(((A>>7))<<1));
    }
  }
  else
  {
   ROM_BANK32(0x8000,A>>7);
  }
}

void Mapper226_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper226_write);
}

//M228
void Mapper228_write(uint16 A,uint8 V)
{
MIRROR_SET((A>>13)&1);

VROM_BANK8(((V&3)|((A&0xF)<<2)));

if((A>>5)&1) // Page size is 16 KB
 {
  if((A>>6)&1)  // High 16 KB mirror
   {
     if(((A>>11)&3)==3)
      {
      ROM_BANK16(0x8000,(((((A>>7)&0xF)|0x20)<<1)+1));
      ROM_BANK16(0xC000,(((((A>>7)&0xF)|0x20)<<1)+1));
      }
     else
      {
      ROM_BANK16(0x8000,(((((A>>7)&0xF)|((A>>7)&0x30))<<1)+1));
      ROM_BANK16(0xC000,(((((A>>7)&0xF)|((A>>7)&0x30))<<1)+1));
      }
   }
   else         // Low 16 KB mirror
   {
     if(((A>>11)&3)==3)
      {
      ROM_BANK16(0x8000,((((A>>7)&0xF)|0x20)<<1));
      ROM_BANK16(0xC000,((((A>>7)&0xF)|0x20)<<1));
      }
     else
      {
      ROM_BANK16(0x8000,((((A>>7)&0xF)|((A>>7)&0x30))<<1));
      ROM_BANK16(0xC000,((((A>>7)&0xF)|((A>>7)&0x30))<<1));
      }
   }

 }
else         // Page size is 32 KB
 {
     if(((A>>11)&3)==3)
      {
      ROM_BANK32(0x8000,((((A>>7)&0x0f)|0x20)));
      }
      else
      {
      ROM_BANK32(0x8000,((((A>>7)&0x0f)|((A>>7)&0x30))));
      }
 }
}

void Mapper228_init(void)
{
  ROM_BANK32(0x8000,0);
  SetWriteHandler(0x8000,0xffff,(void *)Mapper228_write);
}

//M229
void Mapper229_write(uint16 A,uint8 V)
{
if(A>=0x8000)
{
MIRROR_SET((A>>5)&1);
if(!(A&0x1e))
 {
 ROM_BANK32(0x8000,0);
 }
else
 {
 ROM_BANK16(0x8000,A&0x1f);
 ROM_BANK16(0xC000,A&0x1f);
 }
 VROM_BANK8((A&vmask));
}

}

void Mapper229_init(void)
{
  SetWriteHandler(0x8000,0xffff,(void *)Mapper229_write);
}

//M240
void Mapper240_write(uint16 A,uint8 V)
{
 if(A<0x8000)
 {
  ROM_BANK32(0x8000,V>>4);
  VROM_BANK8(V&0xF);
 }
}

void Mapper240_init(void)
{
  SetWriteHandler(0x4020,0x5fff,(void *)Mapper240_write);
  SetWriteHandler(0x8000,0xffff,(void *)Mapper240_write);
}

//M246
void Mapper246_write(uint16 A,uint8 V)
{
 switch(A&0xF007)
 {
 case 0x6000:ROM_BANK8(0x8000,V);break;
 case 0x6001:ROM_BANK8(0xA000,V);break;
 case 0x6002:ROM_BANK8(0xC000,V);break;
 case 0x6003:ROM_BANK8(0xE000,V);break;
 case 0x6004:VROM_BANK2(0x0000,V);break;
 case 0x6005:VROM_BANK2(0x0800,V);break;
 case 0x6006:VROM_BANK2(0x1000,V);break;
 case 0x6007:VROM_BANK2(0x1800,V);break;
 }
}

void Mapper246_init(void)
{
  SetWriteHandler(0x4020,0x67ff,(void *)Mapper246_write);
  SetWriteHandler(0x8000,0xffff,(void *)Mapper246_write);
}

//End of mappers

//fmopl.c
/*
**
** File: fmopl.c -- software implementation of FM sound generator
**
** Copyright (C) 1999 Tatsuyuki Satoh , MultiArcadeMachineEmurator development
**
** Version 0.36f
**
*/

/*
	preliminary :
	Problem :
	note:
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include "fmopl.h"
#define INLINE inline

//#include "m6502.h"
//#include "svga.h"
#ifndef PI
#define PI 3.14159265358979323846
#endif
/* -------------------- preliminary define section --------------------- */
/* attack/decay rate time rate */
#define OPL_ARRATE     141280  /* RATE 4 =  2826.24ms @ 3.6MHz */
#define OPL_DRRATE    1956000  /* RATE 4 = 39280.64ms @ 3.6MHz */

#define DELTAT_MIXING_LEVEL (1) /* DELTA-T ADPCM MIXING LEVEL */

#define FREQ_BITS 24			/* frequency turn          */

/* counter bits = 20 , octerve 7 */
#define FREQ_RATE   (1<<(FREQ_BITS-20))
#define TL_BITS    (FREQ_BITS+2)

/* final output shift , limit minimum and maximum */
#define OPL_OUTSB   (TL_BITS+3-16)		/* OPL output final shift 16bit */
#define OPL_MAXOUT (0x7fff<<OPL_OUTSB<<3)
#define OPL_MINOUT (-0x8000<<OPL_OUTSB<<3)

/* -------------------- quality selection --------------------- */

/* sinwave entries */
/* used static memory = SIN_ENT * 4 (byte) */
#define SIN_ENT 2048

/* output level entries (envelope,sinwave) */
/* envelope counter lower bits */
#define ENV_BITS 16
/* envelope output entries */
#define EG_ENT   2048
/* used dynamic memory = EG_ENT*4*4(byte)or EG_ENT*6*4(byte) */
/* used static  memory = EG_ENT*4 (byte)                     */

#define EG_OFF   ((2*EG_ENT)<<ENV_BITS)  /* OFF          */
#define EG_DED   EG_OFF
#define EG_DST   (EG_ENT<<ENV_BITS)      /* DECAY  START */
#define EG_AED   EG_DST
#define EG_AST   0                       /* ATTACK START */

#define EG_STEP (96.0/EG_ENT) /* OPL is 0.1875 dB step  */

/* LFO table entries */
#define VIB_ENT 512
#define VIB_SHIFT (32-9)
#define AMS_ENT 512
#define AMS_SHIFT (32-9)

#define VIB_RATE 256

/* -------------------- local defines , macros --------------------- */

/* register number to channel number , slot offset */
#define SLOT1 0
#define SLOT2 1

/* envelope phase */
#define ENV_MOD_RR  0x00
#define ENV_MOD_DR  0x01
#define ENV_MOD_AR  0x02

/* -------------------- tables --------------------- */
static const int slot_array[32]=
{
	 0, 2, 4, 1, 3, 5,-1,-1,
	 6, 8,10, 7, 9,11,-1,-1,
	12,14,16,13,15,17,-1,-1,
	-1,-1,-1,-1,-1,-1,-1,-1
};

/* key scale level */
#define ML (0.1875*2/EG_STEP)
static const UINT32 KSL_TABLE[8*16]=
{
	/* OCT 0 */
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	/* OCT 1 */
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 0.750*ML, 1.125*ML, 1.500*ML,
	 1.875*ML, 2.250*ML, 2.625*ML, 3.000*ML,
	/* OCT 2 */
	 0.000*ML, 0.000*ML, 0.000*ML, 0.000*ML,
	 0.000*ML, 1.125*ML, 1.875*ML, 2.625*ML,
	 3.000*ML, 3.750*ML, 4.125*ML, 4.500*ML,
	 4.875*ML, 5.250*ML, 5.625*ML, 6.000*ML,
	/* OCT 3 */
	 0.000*ML, 0.000*ML, 0.000*ML, 1.875*ML,
	 3.000*ML, 4.125*ML, 4.875*ML, 5.625*ML,
	 6.000*ML, 6.750*ML, 7.125*ML, 7.500*ML,
	 7.875*ML, 8.250*ML, 8.625*ML, 9.000*ML,
	/* OCT 4 */
	 0.000*ML, 0.000*ML, 3.000*ML, 4.875*ML,
	 6.000*ML, 7.125*ML, 7.875*ML, 8.625*ML,
	 9.000*ML, 9.750*ML,10.125*ML,10.500*ML,
	10.875*ML,11.250*ML,11.625*ML,12.000*ML,
	/* OCT 5 */
	 0.000*ML, 3.000*ML, 6.000*ML, 7.875*ML,
	 9.000*ML,10.125*ML,10.875*ML,11.625*ML,
	12.000*ML,12.750*ML,13.125*ML,13.500*ML,
	13.875*ML,14.250*ML,14.625*ML,15.000*ML,
	/* OCT 6 */
	 0.000*ML, 6.000*ML, 9.000*ML,10.875*ML,
	12.000*ML,13.125*ML,13.875*ML,14.625*ML,
	15.000*ML,15.750*ML,16.125*ML,16.500*ML,
	16.875*ML,17.250*ML,17.625*ML,18.000*ML,
	/* OCT 7 */
	 0.000*ML, 9.000*ML,12.000*ML,13.875*ML,
	15.000*ML,16.125*ML,16.875*ML,17.625*ML,
	18.000*ML,18.750*ML,19.125*ML,19.500*ML,
	19.875*ML,20.250*ML,20.625*ML,21.000*ML
};
#undef ML

/* sustain lebel table (3db per step) */
/* 0 - 15: 0, 3, 6, 9,12,15,18,21,24,27,30,33,36,39,42,93 (dB)*/
#define SC(db) (db*((3/EG_STEP)*(1<<ENV_BITS)))+EG_DST
static const INT32 SL_TABLE[16]={
 SC( 0),SC( 1),SC( 2),SC(3 ),SC(4 ),SC(5 ),SC(6 ),SC( 7),
 SC( 8),SC( 9),SC(10),SC(11),SC(12),SC(13),SC(14),SC(31)
};
#undef SC

#define TL_MAX (EG_ENT*2) /* limit(tl + ksr + envelope) + sinwave */
/* TotalLevel : 48 24 12  6  3 1.5 0.75 (dB) */
/* TL_TABLE[ 0      to TL_MAX          ] : plus  section */
/* TL_TABLE[ TL_MAX to TL_MAX+TL_MAX-1 ] : minus section */
static INT32 *TL_TABLE;

/* pointers to TL_TABLE with sinwave output offset */
static INT32 **SIN_TABLE;

/* LFO table */
static INT32 *AMS_TABLE;
static INT32 *VIB_TABLE;

/* envelope output curve table */
/* attack + decay + OFF */
static INT32 ENV_CURVE[2*EG_ENT+1];

/* multiple table */
#define ML 2
static const UINT32 MUL_TABLE[16]= {
/* 1/2, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15 */
   0.50*ML, 1.00*ML, 2.00*ML, 3.00*ML, 4.00*ML, 5.00*ML, 6.00*ML, 7.00*ML,
   8.00*ML, 9.00*ML,10.00*ML,10.00*ML,12.00*ML,12.00*ML,15.00*ML,15.00*ML
};
#undef ML

/* dummy attack / decay rate ( when rate == 0 ) */
static INT32 RATE_0[16]=
{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

/* -------------------- static state --------------------- */

/* lock level of common table */
static int num_lock = 0;

/* work table */
static void *cur_chip = NULL;	/* current chip point */
/* currenct chip state */
/* static FMSAMPLE  *bufL,*bufR; */
static OPL_CH *S_CH;
static OPL_CH *E_CH;
OPL_SLOT *SLOT7_1,*SLOT7_2,*SLOT8_1,*SLOT8_2;

static INT32 outd[1];
static INT32 ams;
static INT32 vib;
INT32  *ams_table;
INT32  *vib_table;
static INT32 amsIncr;
static INT32 vibIncr;
static INT32 feedback2;		/* connect for SLOT 2 */

/* log output level */
#define LOG_ERR  3      /* ERROR       */
#define LOG_WAR  2      /* WARNING     */
#define LOG_INF  1      /* INFORMATION */

#define LOG_LEVEL LOG_INF

#define LOG(n,x) if( (n)>=LOG_LEVEL ) logerror x

/* --------------------- subroutines  --------------------- */

INLINE int Limit( int val, int max, int min ) {
	if ( val > max )
		val = max;
	else if ( val < min )
		val = min;

	return val;
}

/* status set and IRQ handling */
INLINE void OPL_STATUS_SET(FM_OPL *OPL,int flag)
{
	/* set status flag */
	OPL->status |= flag;
	if(!(OPL->status & 0x80))
	{
		if(OPL->status & OPL->statusmask)
		{	/* IRQ on */
			OPL->status |= 0x80;
			/* callback user interrupt handler (IRQ is OFF to ON) */
			if(OPL->IRQHandler) (OPL->IRQHandler)(OPL->IRQParam,1);
		}
	}
}

/* status reset and IRQ handling */
INLINE void OPL_STATUS_RESET(FM_OPL *OPL,int flag)
{
	/* reset status flag */
	OPL->status &=~flag;
	if((OPL->status & 0x80))
	{
		if (!(OPL->status & OPL->statusmask) )
		{
			OPL->status &= 0x7f;
			/* callback user interrupt handler (IRQ is ON to OFF) */
			if(OPL->IRQHandler) (OPL->IRQHandler)(OPL->IRQParam,0);
		}
	}
}

/* IRQ mask set */
INLINE void OPL_STATUSMASK_SET(FM_OPL *OPL,int flag)
{
	OPL->statusmask = flag;
	/* IRQ handling check */
	OPL_STATUS_SET(OPL,0);
	OPL_STATUS_RESET(OPL,0);
}

/* ----- key on  ----- */
INLINE void OPL_KEYON(OPL_SLOT *SLOT)
{
	/* sin wave restart */
	SLOT->Cnt = 0;
	/* set attack */
	SLOT->evm = ENV_MOD_AR;
	SLOT->evs = SLOT->evsa;
	SLOT->evc = EG_AST;
	SLOT->eve = EG_AED;
}
/* ----- key off ----- */
INLINE void OPL_KEYOFF(OPL_SLOT *SLOT)
{
	if( SLOT->evm > ENV_MOD_RR)
	{
		/* set envelope counter from envleope output */
		SLOT->evm = ENV_MOD_RR;
		if( !(SLOT->evc&EG_DST) )
			//SLOT->evc = (ENV_CURVE[SLOT->evc>>ENV_BITS]<<ENV_BITS) + EG_DST;
			SLOT->evc = EG_DST;
		SLOT->eve = EG_DED;
		SLOT->evs = SLOT->evsr;
	}
}

/* ---------- calcrate Envelope Generator & Phase Generator ---------- */
/* return : envelope output */
INLINE UINT32 OPL_CALC_SLOT( OPL_SLOT *SLOT )
{
	/* calcrate envelope generator */
	if( (SLOT->evc+=SLOT->evs) >= SLOT->eve )
	{
		switch( SLOT->evm ){
		case ENV_MOD_AR: /* ATTACK -> DECAY1 */
			/* next DR */
			SLOT->evm = ENV_MOD_DR;
			SLOT->evc = EG_DST;
			SLOT->eve = SLOT->SL;
			SLOT->evs = SLOT->evsd;
			break;
		case ENV_MOD_DR: /* DECAY -> SL or RR */
			SLOT->evc = SLOT->SL;
			SLOT->eve = EG_DED;
			if(SLOT->eg_typ)
			{
				SLOT->evs = 0;
			}
			else
			{
				SLOT->evm = ENV_MOD_RR;
				SLOT->evs = SLOT->evsr;
			}
			break;
		case ENV_MOD_RR: /* RR -> OFF */
			SLOT->evc = EG_OFF;
			SLOT->eve = EG_OFF+1;
			SLOT->evs = 0;
			break;
		}
	}
//	slot->tll
	/* calcrate envelope */
	return SLOT->TLL+ENV_CURVE[(SLOT->evc)>>ENV_BITS]+(SLOT->ams ? ams : 0);
}

/* set algorythm connection */
static void set_algorythm( OPL_CH *CH)
{
	INT32 *carrier = &outd[0];
	CH->connect1 = CH->CON ? carrier : &feedback2;
	CH->connect2 = carrier;
}

/* ---------- frequency counter for operater update ---------- */
INLINE void CALC_FCSLOT(OPL_CH *CH,OPL_SLOT *SLOT)
{
	int ksr;

	/* frequency step counter */
	SLOT->Incr = CH->fc * SLOT->mul;
	ksr = CH->kcode >> SLOT->KSR;

	if( SLOT->ksr != ksr )
	{
		SLOT->ksr = ksr;
		/* attack , decay rate recalcration */
		SLOT->evsa = SLOT->AR[ksr];
		SLOT->evsd = SLOT->DR[ksr];
		SLOT->evsr = SLOT->RR[ksr];
	}
	SLOT->TLL = SLOT->TL + (CH->ksl_base>>SLOT->ksl);
}

/* set multi,am,vib,EG-TYP,KSR,mul */
INLINE void set_mul(FM_OPL *OPL,int slot,int v)
{
        OPL_CH   *CH   = &OPL->P_CH[slot>>1];
	OPL_SLOT *SLOT = &CH->SLOT[slot&1];

	SLOT->mul    = MUL_TABLE[v&0x0f];
	SLOT->KSR    = (v&0x10) ? 0 : 2;
	SLOT->eg_typ = (v&0x20)>>5;
	SLOT->vib    = (v&0x40);
	SLOT->ams    = (v&0x80);
	CALC_FCSLOT(CH,SLOT);
}

INLINE void set_ksl_tl(FM_OPL *OPL,int slot,int v)
{
	unsigned char boing;
        OPL_CH   *CH   = &OPL->P_CH[slot>>1];
	OPL_SLOT *SLOT = &CH->SLOT[slot&1];
	int ksl = v>>6; /* 0 / 1.5 / 3 / 6 db/OCT */

	SLOT->ksl = ksl ? 3-ksl : 31;
	boing=v&0x3f;
	SLOT->TL  = (boing&0x3f)*(0.75/EG_STEP); /* 0.75db step */
	if( !(OPL->mode&0x80) )
	{	/* not CSM latch total level */
		SLOT->TLL = (SLOT->TL) + (CH->ksl_base>>SLOT->ksl);
	}
}

/* set attack rate & decay rate  */
INLINE void set_ar_dr(FM_OPL *OPL,int slot,int v)
{
        OPL_CH   *CH   = &OPL->P_CH[slot>>1];
	OPL_SLOT *SLOT = &CH->SLOT[slot&1];
	int ar = v>>4;
	int dr = v&0x0f;

	SLOT->AR = ar ? &OPL->AR_TABLE[ar<<2] : RATE_0;
	SLOT->evsa = SLOT->AR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_AR ) SLOT->evs = SLOT->evsa;

	SLOT->DR = dr ? &OPL->DR_TABLE[dr<<2] : RATE_0;
	SLOT->evsd = SLOT->DR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_DR ) SLOT->evs = SLOT->evsd;
}

/* set sustain level & release rate */
INLINE void set_sl_rr(FM_OPL *OPL,int slot,int v)
{
        OPL_CH   *CH   = &OPL->P_CH[slot>>1];
	OPL_SLOT *SLOT = &CH->SLOT[slot&1];
	int sl = v>>4;
	int rr = v & 0x0f;

	SLOT->SL = SL_TABLE[sl];
	if( SLOT->evm == ENV_MOD_DR ) SLOT->eve = SLOT->SL;
	SLOT->RR = &OPL->DR_TABLE[rr<<2];
	SLOT->evsr = SLOT->RR[SLOT->ksr];
	if( SLOT->evm == ENV_MOD_RR ) SLOT->evs = SLOT->evsr;
}
/* operator output calcrator */
#define OP_OUT(slot,env,con)   slot->wavetable[((slot->Cnt+con)/(0x1000000/SIN_ENT))&(SIN_ENT-1)][env]
/* ---------- calcrate one of channel ---------- */
INLINE void OPL_CALC_CH( OPL_CH *CH )
{
	UINT32 env_out;
	OPL_SLOT *SLOT;

	feedback2 = 0;
	/* SLOT 1 */
	SLOT = &CH->SLOT[SLOT1];
	env_out=OPL_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
	{
		/* PG */
		if(SLOT->vib) SLOT->Cnt += (SLOT->Incr*vib/VIB_RATE);
		else          SLOT->Cnt += SLOT->Incr;
		/* connectoion */
		if(CH->FB)
		{
			int feedback1 = (CH->op1_out[0]+CH->op1_out[1])>>CH->FB;
			CH->op1_out[1] = CH->op1_out[0];
			*CH->connect1 += CH->op1_out[0] = OP_OUT(SLOT,env_out,feedback1);
		}
		else
		{
			*CH->connect1 += OP_OUT(SLOT,env_out,0);
		}
	}else
	{
		CH->op1_out[1] = CH->op1_out[0];
		CH->op1_out[0] = 0;
	}
	/* SLOT 2 */
	SLOT = &CH->SLOT[SLOT2];
	env_out=OPL_CALC_SLOT(SLOT);
	if( env_out < EG_ENT-1 )
	{
		/* PG */
		if(SLOT->vib) SLOT->Cnt += (SLOT->Incr*vib/VIB_RATE);
		else          SLOT->Cnt += SLOT->Incr;
		/* connectoion */
		outd[0] += OP_OUT(SLOT,env_out, feedback2);
	}
}

/* ----------- initialize time tabls ----------- */
static void init_timetables( FM_OPL *OPL , int ARRATE , int DRRATE )
{
	int i;
	double rate;

	/* make attack rate & decay rate tables */
	for (i = 0;i < 4;i++) OPL->AR_TABLE[i] = OPL->DR_TABLE[i] = 0;
	for (i = 4;i <= 60;i++){
		rate  = OPL->freqbase;						/* frequency rate */
		if( i < 60 ) rate *= 1.0+(i&3)*0.25;		/* b0-1 : x1 , x1.25 , x1.5 , x1.75 */
		rate *= 1<<((i>>2)-1);						/* b2-5 : shift bit */
		rate *= (double)(EG_ENT<<ENV_BITS);
		OPL->AR_TABLE[i] = rate / ARRATE;
		OPL->DR_TABLE[i] = rate / DRRATE;
	}
	for (i = 60;i < 76;i++)
	{
		OPL->AR_TABLE[i] = EG_AED-1;
		OPL->DR_TABLE[i] = OPL->DR_TABLE[60];
	}
}

/* ---------- generic table initialize ---------- */
static int OPLOpenTable( void )
{
	int s,t;
	double rate;
	int i,j;
	double pom;

	/* allocate dynamic tables */
	if( (TL_TABLE = malloc(TL_MAX*2*sizeof(INT32))) == NULL)
		return 0;
	if( (SIN_TABLE = malloc(SIN_ENT*4 *sizeof(INT32 *))) == NULL)
	{
		free(TL_TABLE);
		return 0;
	}
	if( (AMS_TABLE = malloc(AMS_ENT*2 *sizeof(INT32))) == NULL)
	{
		free(TL_TABLE);
		free(SIN_TABLE);
		return 0;
	}
	if( (VIB_TABLE = malloc(VIB_ENT*2 *sizeof(INT32))) == NULL)
	{
		free(TL_TABLE);
		free(SIN_TABLE);
		free(AMS_TABLE);
		return 0;
	}
	/* make total level table */
	for (t = 0;t < EG_ENT-1 ;t++){
		rate = ((1<<TL_BITS)-1)/pow(10,EG_STEP*t/20);	/* dB -> voltage */
		TL_TABLE[       t] =  (int)rate;
		TL_TABLE[TL_MAX+t] = -TL_TABLE[t];
/*		LOG(LOG_INF,("TotalLevel(%3d) = %x\n",t,TL_TABLE[t]));*/
	}
	/* fill volume off area */
	for ( t = EG_ENT-1; t < TL_MAX ;t++){
		TL_TABLE[t] = TL_TABLE[TL_MAX+t] = 0;
	}

	/* make sinwave table (total level offet) */
	/* degree 0 = degree 180                   = off */
        SIN_TABLE[0] = SIN_TABLE[SIN_ENT>>1]         = &TL_TABLE[EG_ENT-1];
	for (s = 1;s <= SIN_ENT/4;s++){
		pom = sin(2*PI*s/SIN_ENT); /* sin     */
		pom = 20*log10(1/pom);	   /* decibel */
		j = pom / EG_STEP;         /* TL_TABLE steps */

        /* degree 0   -  90    , degree 180 -  90 : plus section */
                SIN_TABLE[          s] = SIN_TABLE[(SIN_ENT>>1)-s] = &TL_TABLE[j];
        /* degree 180 - 270    , degree 360 - 270 : minus section */
                SIN_TABLE[SIN_ENT/2+s] = SIN_TABLE[SIN_ENT  -s] = &TL_TABLE[TL_MAX+j];
/*		LOG(LOG_INF,("sin(%3d) = %f:%f db\n",s,pom,(double)j * EG_STEP));*/
	}
	for (s = 0;s < SIN_ENT;s++)
	{
                SIN_TABLE[SIN_ENT*1+s] = s<(SIN_ENT>>1) ? SIN_TABLE[s] : &TL_TABLE[EG_ENT];
                SIN_TABLE[SIN_ENT*2+s] = SIN_TABLE[s % (SIN_ENT>>1)];
		SIN_TABLE[SIN_ENT*3+s] = (s/(SIN_ENT/4))&1 ? &TL_TABLE[EG_ENT] : SIN_TABLE[SIN_ENT*2+s];
	}

	/* envelope counter -> envelope output table */
	for (i=0; i<EG_ENT; i++)
	{
		/* ATTACK curve */
		pom = pow( ((double)(EG_ENT-1-i)/EG_ENT) , 8 ) * EG_ENT;
		/* if( pom >= EG_ENT ) pom = EG_ENT-1; */
		ENV_CURVE[i] = (int)pom;
		/* DECAY ,RELEASE curve */
		ENV_CURVE[(EG_DST>>ENV_BITS)+i]= i;
	}
	/* off */
	ENV_CURVE[EG_OFF>>ENV_BITS]= EG_ENT-1;
	/* make LFO ams table */
	for (i=0; i<AMS_ENT; i++)
	{
		pom = (1.0+sin(2*PI*i/AMS_ENT))/2; /* sin */
		AMS_TABLE[i]         = (1.0/EG_STEP)*pom; /* 1dB   */
		AMS_TABLE[AMS_ENT+i] = (4.8/EG_STEP)*pom; /* 4.8dB */
	}
	/* make LFO vibrate table */
	for (i=0; i<VIB_ENT; i++)
	{
		/* 100cent = 1seminote = 6% ?? */
		pom = (double)VIB_RATE*0.06*sin(2*PI*i/VIB_ENT); /* +-100sect step */
		VIB_TABLE[i]         = VIB_RATE + (pom*0.07); /* +- 7cent */
		VIB_TABLE[VIB_ENT+i] = VIB_RATE + (pom*0.14); /* +-14cent */
		/* LOG(LOG_INF,("vib %d=%d\n",i,VIB_TABLE[VIB_ENT+i])); */
	}
	return 1;
}


static void OPLCloseTable( void )
{
	free(TL_TABLE);
	free(SIN_TABLE);
	free(AMS_TABLE);
	free(VIB_TABLE);
}

/* CSM Key Controll */
INLINE void CSMKeyControll(OPL_CH *CH)
{
	OPL_SLOT *slot1 = &CH->SLOT[SLOT1];
	OPL_SLOT *slot2 = &CH->SLOT[SLOT2];
	/* all key off */
	OPL_KEYOFF(slot1);
	OPL_KEYOFF(slot2);
	/* total level latch */
	slot1->TLL = slot1->TL + (CH->ksl_base>>slot1->ksl);
	slot1->TLL = slot1->TL + (CH->ksl_base>>slot1->ksl);
	/* key on */
	CH->op1_out[0] = CH->op1_out[1] = 0;
	OPL_KEYON(slot1);
	OPL_KEYON(slot2);
}

/* ---------- opl initialize ---------- */
static void OPL_initalize(FM_OPL *OPL)
{
	int fn;

	/* frequency base */
	OPL->freqbase = (OPL->rate) ? ((double)OPL->clock / OPL->rate) / 72  : 0;
	/* Timer base time */
	OPL->TimerBase = 1.0/((double)OPL->clock / 72.0 );
	/* make time tables */
	init_timetables( OPL , OPL_ARRATE , OPL_DRRATE );
	/* make fnumber -> increment counter table */
	for( fn=0 ; fn < 1024 ; fn++ )
	{
		OPL->FN_TABLE[fn] = OPL->freqbase * fn * FREQ_RATE * (1<<7) / 2;
	}
	/* LFO freq.table */
	OPL->amsIncr = OPL->rate ? (double)AMS_ENT*(1<<AMS_SHIFT) / OPL->rate * 3.7 * ((double)OPL->clock/3600000) : 0;
	OPL->vibIncr = OPL->rate ? (double)VIB_ENT*(1<<VIB_SHIFT) / OPL->rate * 6.4 * ((double)OPL->clock/3600000) : 0;
}

/* ---------- write a OPL registers ---------- */
static void OPLWriteReg(FM_OPL *OPL, byte r, byte v)
{
	OPL_CH *CH;
	int slot;
	int block_fnum;

	switch(r&0xe0)
	{
	case 0x00: /* 00-1f:controll */
		switch(r&0x1f)
		{
		case 0x01:
			/* wave selector enable */
			if(OPL->type&OPL_TYPE_WAVESEL)
			{
				OPL->wavesel = v&0x20;
				if(!OPL->wavesel)
				{
					/* preset compatible mode */
					int c;
					for(c=0;c<OPL->max_ch;c++)
					{
						OPL->P_CH[c].SLOT[SLOT1].wavetable = &SIN_TABLE[0];
						OPL->P_CH[c].SLOT[SLOT2].wavetable = &SIN_TABLE[0];
					}
				}
			}
			return;
		case 0x02:	/* Timer 1 */
			OPL->T[0] = (256-v)*4;
			break;
		case 0x03:	/* Timer 2 */
			OPL->T[1] = (256-v)*16;
			return;
		case 0x04:	/* IRQ clear / mask and Timer enable */
			if(v&0x80)
			{	/* IRQ flag clear */
				OPL_STATUS_RESET(OPL,0x7f);
			}
			else
			{	/* set IRQ mask ,timer enable*/
				UINT8 st1 = v&1;
				UINT8 st2 = (v>>1)&1;
				/* IRQRST,T1MSK,t2MSK,EOSMSK,BRMSK,x,ST2,ST1 */
				OPL_STATUS_RESET(OPL,v&0x78);
				OPL_STATUSMASK_SET(OPL,((~v)&0x78)|0x01);
				/* timer 2 */
				if(OPL->st[1] != st2)
				{
					double interval = st2 ? (double)OPL->T[1]*OPL->TimerBase : 0.0;
					OPL->st[1] = st2;
					if (OPL->TimerHandler) (OPL->TimerHandler)(OPL->TimerParam+1,interval);
				}
				/* timer 1 */
				if(OPL->st[0] != st1)
				{
					double interval = st1 ? (double)OPL->T[0]*OPL->TimerBase : 0.0;
					OPL->st[0] = st1;
					if (OPL->TimerHandler) (OPL->TimerHandler)(OPL->TimerParam+0,interval);
				}
			}
			return;
		}
		break;
	case 0x20:	/* am,vib,ksr,eg type,mul */
		slot = slot_array[r&0x1f];
		if(slot == -1) return;
		set_mul(OPL,slot,v);
		return;
	case 0x40:
		slot = slot_array[r&0x1f];
		if(slot == -1) return;
//		if(r==0x40 || r==0x41 || r==0x42 || r==0x48 || r==0x49 || r==0x4a) 
		set_ksl_tl(OPL,slot,v);
		return;
	case 0x60:
		slot = slot_array[r&0x1f];
		if(slot == -1) return;
		set_ar_dr(OPL,slot,v);
		return;
	case 0x80:
		slot = slot_array[r&0x1f];
		if(slot == -1) return;
		set_sl_rr(OPL,slot,v);
		return;
	case 0xa0:
		switch(r)
		{
		case 0xbd:
			/* amsep,vibdep,r,bd,sd,tom,tc,hh */
			{
			OPL->ams_table = &AMS_TABLE[v&0x80 ? AMS_ENT : 0];
			OPL->vib_table = &VIB_TABLE[v&0x40 ? VIB_ENT : 0];
			}
			return;
		}
		/* keyon,block,fnum */
		if( (r&0x0f) > 8) return;
		CH = &OPL->P_CH[r&0x0f];
		if(!(r&0x10))
		{	/* a0-a8 */
			block_fnum  = (CH->block_fnum&0x1f00) | v;
		}
		else
		{	/* b0-b8 */
			int keyon = (v>>5)&1;
			block_fnum = ((v&0x1f)<<8) | (CH->block_fnum&0xff);
			if(CH->keyon != keyon)
			{
				if( (CH->keyon=keyon) )
				{
					CH->op1_out[0] = CH->op1_out[1] = 0;
					OPL_KEYON(&CH->SLOT[SLOT1]);
					OPL_KEYON(&CH->SLOT[SLOT2]);
				}
				else
				{
					OPL_KEYOFF(&CH->SLOT[SLOT1]);
					OPL_KEYOFF(&CH->SLOT[SLOT2]);
				}
			}
		}
		/* update */
		if(CH->block_fnum != block_fnum)
		{
			int blockRv = 7-(block_fnum>>10);
			int fnum   = block_fnum&0x3ff;
			CH->block_fnum = block_fnum;
			//printf("KSL:  %d\n",KSL_TABLE[0x19]);
			CH->ksl_base = KSL_TABLE[block_fnum>>6];
			CH->fc = OPL->FN_TABLE[fnum]>>blockRv;
			CH->kcode = CH->block_fnum>>9;
			if( (OPL->mode&0x40) && CH->block_fnum&0x100) CH->kcode |=1;
			CALC_FCSLOT(CH,&CH->SLOT[SLOT1]);
			CALC_FCSLOT(CH,&CH->SLOT[SLOT2]);
		}
		return;
	case 0xc0:
		/* FB,C */
		if( (r&0x0f) > 8) return;
		CH = &OPL->P_CH[r&0x0f];
		{
		int feedback = (v>>1)&7;
		CH->FB   = feedback ? (8+1) - feedback : 0;
                CH->CON = v&1;
		set_algorythm(CH);
		}
		return;
	case 0xe0: /* wave type */
		slot = slot_array[r&0x1f];
		if(slot == -1) return;
                CH = &OPL->P_CH[slot>>1];
		if(OPL->wavesel)
		{
			/* LOG(LOG_INF,("OPL SLOT %d wave select %d\n",slot,v&3)); */
			CH->SLOT[slot&1].wavetable = &SIN_TABLE[(v&0x03)*SIN_ENT];
		}
		return;
	}
}

/* lock/unlock for common table */
static int OPL_LockTable(void)
{
	num_lock++;
	if(num_lock>1) return 0;
	/* first time */
	cur_chip = NULL;
	/* allocate total level table (128kb space) */
	if( !OPLOpenTable() )
	{
		num_lock--;
		return -1;
	}
	return 0;
}

static void OPL_UnLockTable(void)
{
	if(num_lock) num_lock--;
	if(num_lock) return;
	/* last time */
	cur_chip = NULL;
	OPLCloseTable();
}

#if (BUILD_YM3812 || BUILD_YM3526)
/*******************************************************************************/
/*		YM3812 local section                                                   */
/*******************************************************************************/

/* ---------- update one of chip ----------- */
void YM3812UpdateOne(FM_OPL *OPL, INT32 *buffer, int length)
{
    int i;
	int data;
	INT32 *buf = buffer;
	UINT32 amsCnt  = OPL->amsCnt;
	UINT32 vibCnt  = OPL->vibCnt;
	OPL_CH *CH,*R_CH;

	if( (void *)OPL != cur_chip ){
		cur_chip = (void *)OPL;
		/* channel pointers */
		S_CH = OPL->P_CH;
		E_CH = &S_CH[9];
		/* LFO state */
		amsIncr = OPL->amsIncr;
		vibIncr = OPL->vibIncr;
		ams_table = OPL->ams_table;
		vib_table = OPL->vib_table;
	}
	R_CH = E_CH;
    for( i=0; i < length ; i++ )
	{
		/*            channel A         channel B         channel C      */
		/* LFO */
		ams = ams_table[(amsCnt+=amsIncr)>>AMS_SHIFT];
		vib = vib_table[(vibCnt+=vibIncr)>>VIB_SHIFT];
		outd[0] = 0;
		/* FM part */
		for(CH=S_CH ; CH < R_CH ; CH++)
			{OPL_CALC_CH(CH);}
		/* limit check */
		data = Limit( outd[0] , OPL_MAXOUT, OPL_MINOUT );
		/* store to sound buffer */
                buf[i] += outd[0] >> OPL_OUTSB>>3;
	}

	OPL->amsCnt = amsCnt;
	OPL->vibCnt = vibCnt;
}
#endif /* (BUILD_YM3812 || BUILD_YM3526) */

#if BUILD_Y8950

void Y8950UpdateOne(FM_OPL *OPL, INT16 *buffer, int length)
{
    int i;
	INT32 outmoo;
	int data;
	FMSAMPLE *buf = buffer;
	UINT32 amsCnt  = OPL->amsCnt;
	UINT32 vibCnt  = OPL->vibCnt;
	OPL_CH *CH,*R_CH;
	YM_DELTAT *DELTAT = OPL->deltat;

	/* setup DELTA-T unit */
	YM_DELTAT_DECODE_PRESET(DELTAT);

	if( (void *)OPL != cur_chip ){
		cur_chip = (void *)OPL;
		/* channel pointers */
		S_CH = OPL->P_CH;
		E_CH = &S_CH[9];
		/* LFO state */
		amsIncr = OPL->amsIncr;
		vibIncr = OPL->vibIncr;
		ams_table = OPL->ams_table;
		vib_table = OPL->vib_table;
	}
	R_CH = E_CH;
    for( i=0; i < length ; i++ )
	{
		int snarf;
		/*            channel A         channel B         channel C      */
		/* LFO */
		ams = ams_table[(amsCnt+=amsIncr)>>AMS_SHIFT];
		vib = vib_table[(vibCnt+=vibIncr)>>VIB_SHIFT];
		outd[0] = 0;
		/* deltaT ADPCM */
		if( DELTAT->flag )
			YM_DELTAT_ADPCM_CALC(DELTAT);
		/* FM part */
		for(CH=S_CH ; CH < R_CH ; CH++)
			{outd[0]=0;OPL_CALC_CH(CH);outd[0]/=hippy[x];outmoo+=outd[0];}
		/* limit check */
		data = Limit( outmoo , OPL_MAXOUT, OPL_MINOUT );
		/* store to sound buffer */
		buf[i] = data >> OPL_OUTSB;
	}
	OPL->amsCnt = amsCnt;
	OPL->vibCnt = vibCnt;
	/* deltaT START flag */
	if( !DELTAT->flag )
		OPL->status &= 0xfe;
}
#endif

/* ---------- reset one of chip ---------- */
void OPLResetChip(FM_OPL *OPL)
{
	int c,s;
	int i;

	/* reset chip */
	OPL->mode   = 0;	/* normal mode */
	OPL_STATUS_RESET(OPL,0x7f);
	/* reset with register write */
	OPLWriteReg(OPL,0x01,0); /* wabesel disable */
	OPLWriteReg(OPL,0x02,0); /* Timer1 */
	OPLWriteReg(OPL,0x03,0); /* Timer2 */
	OPLWriteReg(OPL,0x04,0); /* IRQ mask clear */
	for(i = 0xff ; i >= 0x20 ; i-- ) OPLWriteReg(OPL,i,0);
	/* reset OPerator paramater */
	for( c = 0 ; c < OPL->max_ch ; c++ )
	{
		OPL_CH *CH = &OPL->P_CH[c];
		/* OPL->P_CH[c].PAN = OPN_CENTER; */
		for(s = 0 ; s < 2 ; s++ )
		{
			/* wave table */
			CH->SLOT[s].wavetable = &SIN_TABLE[0];
			/* CH->SLOT[s].evm = ENV_MOD_RR; */
			CH->SLOT[s].evc = EG_OFF;
			CH->SLOT[s].eve = EG_OFF+1;
			CH->SLOT[s].evs = 0;
		}
	}
#if BUILD_Y8950
	if(OPL->type&OPL_TYPE_ADPCM)
	{
		YM_DELTAT *DELTAT = OPL->deltat;

		DELTAT->freqbase = OPL->freqbase;
		DELTAT->output_pointer = outd;
		DELTAT->portshift = 5;
		DELTAT->output_range = DELTAT_MIXING_LEVEL<<TL_BITS;
		YM_DELTAT_ADPCM_Reset(DELTAT,0);
	}
#endif
}

/* ----------  Create one of vietual YM3812 ----------       */
/* 'rate'  is sampling rate and 'bufsiz' is the size of the  */
FM_OPL *OPLCreate(int type, int clock, int rate)
{
	char *ptr;
	FM_OPL *OPL;
	int state_size;
	int max_ch = 9; /* normaly 9 channels */

	if( OPL_LockTable() ==-1) return NULL;
	/* allocate OPL state space */
	state_size  = sizeof(FM_OPL);
	state_size += sizeof(OPL_CH)*max_ch;
#if BUILD_Y8950
	if(type&OPL_TYPE_ADPCM) state_size+= sizeof(YM_DELTAT);
#endif
	/* allocate memory block */
	ptr = malloc(state_size);
	if(ptr==NULL) return NULL;
	/* clear */
	memset(ptr,0,state_size);
	OPL        = (FM_OPL *)ptr; ptr+=sizeof(FM_OPL);
	OPL->P_CH  = (OPL_CH *)ptr; ptr+=sizeof(OPL_CH)*max_ch;
#if BUILD_Y8950
	if(type&OPL_TYPE_ADPCM) OPL->deltat = (YM_DELTAT *)ptr; ptr+=sizeof(YM_DELTAT);
#endif
	/* set channel state pointer */
	OPL->type  = type;
	OPL->clock = clock;
	OPL->rate  = rate;
	OPL->max_ch = max_ch;
	/* init grobal tables */
	OPL_initalize(OPL);
	/* reset chip */
	OPLResetChip(OPL);
	return OPL;
}

/* ----------  Destroy one of vietual YM3812 ----------       */
void OPLDestroy(FM_OPL *OPL)
{
	OPL_UnLockTable();
	free(OPL);
}

/* ----------  Option handlers ----------       */

void OPLSetTimerHandler(FM_OPL *OPL,OPL_TIMERHANDLER TimerHandler,int channelOffset)
{
	OPL->TimerHandler   = TimerHandler;
	OPL->TimerParam = channelOffset;
}
void OPLSetIRQHandler(FM_OPL *OPL,OPL_IRQHANDLER IRQHandler,int param)
{
	OPL->IRQHandler     = IRQHandler;
	OPL->IRQParam = param;
}
void OPLSetUpdateHandler(FM_OPL *OPL,OPL_UPDATEHANDLER UpdateHandler,int param)
{
	OPL->UpdateHandler = UpdateHandler;
	OPL->UpdateParam = param;
}
/* ---------- YM3812 I/O interface ---------- */
int OPLWrite(FM_OPL *OPL,int a,int v)
{
	if( !(a&1) )
	{	/* address port */
		OPL->address = v & 0xff;
	}
	else
	{	/* data port */
		if(OPL->UpdateHandler) OPL->UpdateHandler(OPL->UpdateParam,0);
		OPLWriteReg(OPL,OPL->address,v);
	}
	return OPL->status>>7;
}


int OPLTimerOver(FM_OPL *OPL,int c)
{
	if( c )
	{	/* Timer B */
		OPL_STATUS_SET(OPL,0x20);
	}
	else
	{	/* Timer A */
		OPL_STATUS_SET(OPL,0x40);
		/* CSM mode key,TL controll */
		if( OPL->mode & 0x80 )
		{	/* CSM mode total level latch and auto key on */
			int ch;
			if(OPL->UpdateHandler) OPL->UpdateHandler(OPL->UpdateParam,0);
			for(ch=0;ch<9;ch++)
				CSMKeyControll( &OPL->P_CH[ch] );
		}
	}
	/* reload timer */
	if (OPL->TimerHandler) (OPL->TimerHandler)(OPL->TimerParam+c,(double)OPL->T[c]*OPL->TimerBase);
	return OPL->status>>7;
}


//vrc7snd.c
#include "vrc7q.h"

FM_OPL *fmob=0;
static void initopl(int how);

void writeopl(byte A, byte V)
{
 MapperExRAM[A]=V;
 if(fmob>0) {OPLWrite(fmob,0,A);OPLWrite(fmob,1,V);}
}


void vrc7translate(byte A, byte V)
{
 if(!fmob) initopl(0);
 AddQueue(VRC7_dosound,A,V);
}


void LoadOPL(void)
{
 int x;
 int y;
 for(x=y=0;x<0xF6;x++)
  y|=MapperExRAM[x];
 if(y)
 { 
  initopl(1); 
  for(x=0;x<0xF6;x++)
   writeopl(x,MapperExRAM[x]);
 }
}

void UpdateOPL(int32 *d)
{
if(fmob>0) YM3812UpdateOne(fmob, d, 256);
}

void trashopl(void)
{
int x;
for(x=0x1;x<0xF6;x++)
 writeopl(x,0);
}

static void initopl(int how)
{
int x;

fmob=OPLCreate(OPL_TYPE_WAVESEL,1789772*2,SndRate);
if(!fmob ) return;

OPLResetChip(fmob);

if(!how)
{
 for(x=0x1;x<0xF6;x++)
  {writeopl(x,0);}

  writeopl(0xBD,0xC0);
  writeopl(1,0x20);      // Enable waveform type manipulation
 }
}

#define u8 uint8
#include "vrc7q.c"

//

//M85
static void VROM_BANK1VRC7(uint32 A, uint32 V)
{
 if(!VROM_size){  V&=7;CHRBankList[(A)>>10]=V;VPage[(A)>>10]=
&VRAM[(V)<<10]-(A);VPAL[(A)>>10]=1;}else{V&=vmask1;
CHRBankList[(A)>>10]=V;VPage[(A)>>10]=&VROM[(V)<<10]-(A);}
}


void vrc7translate(byte A, byte V);
void UpdateOPL(int32 *d);
void Mapper85_write(uint16 A,uint8 V)
{
static byte indox=0;
A|=(A&8)<<1;
switch(A&0xF030)
        {
        case 0x8000:ROM_BANK8(0x8000,V);break;
        case 0x8010:ROM_BANK8(0xa000,V);break;
        case 0x9000:ROM_BANK8(0xc000,V);break;
        case 0x9010:indox=V;break;
        case 0x9030:vrc7translate(indox,V);MapExpSound=(void *)VRC7Sound;break;
        case 0xa000:VROM_BANK1VRC7(0x000,V);break;
        case 0xa010:VROM_BANK1VRC7(0x400,V);break;
        case 0xb000:VROM_BANK1VRC7(0x800,V);break;
        case 0xb010:VROM_BANK1VRC7(0xc00,V);break;
        case 0xc000:VROM_BANK1VRC7(0x1000,V);break;
        case 0xc010:VROM_BANK1VRC7(0x1400,V);break;
        case 0xd000:VROM_BANK1VRC7(0x1800,V);break;
        case 0xd010:VROM_BANK1VRC7(0x1c00,V);break;
       case 0xe000:
        switch(V&3)
        {
        case 0:MIRROR_SET2(1);break;
        case 1:MIRROR_SET2(0);break;
        case 2:onemir(0);break;
        case 3:onemir(2);break;
        }
        break;
        case 0xE010:
                    IRQLatch=V;
                    break;
        case 0xF000:
                    IRQa=V&2;
                    vrctemp=V&1;
                    if(V&2) {IRQCount=IRQLatch;}
                    break;
        case 0xf010:if(vrctemp) IRQa=1;
                    else IRQa=0;
                    break;
        }
}
/*
static void KonamiIRQHook(int a)
{
  static int count=0;
  if(IRQa)
   {
    count+=(a<<1)+a;
    if(count>=342)
    {
     doagainbub:count-=342;IRQCount++;
     if(IRQCount&0x100) {count=0;TriggerIRQ();IRQCount=IRQLatch;}
     if(count>=342) goto doagainbub;
    }
 }
}
*/
void Mapper85_StateRestore(int version)
{
 LoadOPL();

}
int VRC7Sound(int32 *Wave)
{
 UpdateOPL(Wave);
 return 0;
}

void Mapper85_init(void)
{
  MapIRQHook=(void *)KonamiIRQHook;
  SetWriteHandler(0x8000,0xffff,(void *)Mapper85_write);
  MapStateRestore=(void *)Mapper85_StateRestore;
}
