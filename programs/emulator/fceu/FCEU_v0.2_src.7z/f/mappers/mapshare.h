void MMC3_hb(void);
int VRC6Sound(int32 *Wave);

#define cbase mapword1[0]
#define pbase mapword1[1]
#define resetmode mapbyte1[0]
#define MMC3_cmd mapbyte1[1]

