int iNESLoad(char *name, FILE *fp);
