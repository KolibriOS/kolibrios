#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>

#include "types.h"

#include "general.h"
#include "state.h"
#include "version.h"

char *marray[1]={"Error allocating memory!"};

char TempArray[2048];

void GetFileBase(char *f)
{
        char *tp1,*tp3;

 #if PSS_STYLE==1
     tp1=((char *)strrchr(f,'/'));
 #else
     tp1=((char *)strrchr(f,'\\'));
  #if PSS_STYLE!=3
     tp3=((char *)strrchr(f,'/'));
     if(tp1<tp3) tp1=tp3;
  #endif
 #endif
     if(!tp1) tp1=f;

     if((tp3=strrchr(f,'.'))!=NULL)
      {
      memcpy(StateFile,tp1,tp3-tp1);
      StateFile[tp3-tp1]=0;
      }
      else
       strcpy(StateFile,tp1);
}

void nullfunco(){};
