#define VERSION_NUMERIC 42
#define VERSION_STRING ".42"

#if PSS_STYLE==2

#define PSS "\\"
#define PS '\\'

#elif PSS_STYLE==1

#define PSS "/"
#define PS '/'

#elif PSS_STYLE==3

#define PSS "\\"
#define PS '\\'

#endif

#ifdef NOSTDOUT
#define puts nullfunco
#define printf nullfunco
void nullfunco();
#endif
