#SHS

@notify "Playing notes!" -S

sleep 5

PlayNote C5.raw
PlayNote D5.raw
PlayNote E5.raw
PlayNote F5.raw
PlayNote G5.raw
PlayNote A5.raw
PlayNote B5.raw
PlayNote C6.raw

exit
